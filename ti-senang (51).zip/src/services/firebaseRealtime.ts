/**
 * Firebase Realtime Database SDK Client & Real-time Synchronization
 * Kredensial:
 * - API Key: AIzaSyCnuYiWNXQlwVlBKjAZkFCS1QyUYvHe8xo
 * - Database URL: https://ti-senang-default-rtdb.asia-southeast1.firebasedatabase.app
 *
 * Struktur Node Database Utama:
 * - /misi         : Seluruh daftar misi pembelajaran dari guru
 * - /tugas_siswa  : Respon, pengerjaan, dan pengumpulan tugas siswa
 * - /portofolio   : Publikasi tugas/karya siswa yang tampil di beranda
 * - /alme_sisipan : Misi otomatis hasil analisis sistem ALME (Adaptive Learning Mission Engine)
 */

import { initializeApp, getApps, getApp } from 'firebase/app';
import {
  getDatabase,
  ref,
  onValue,
  push,
  set,
  get,
  remove,
  update,
  Database,
  Unsubscribe,
  DataSnapshot,
} from 'firebase/database';
import {
  Mission,
  PortfolioItem,
  StudentProgress,
  AlmeIndividualMission,
  TujuanPembelajaran,
  AsesmenAwalInput,
  AsesmenAkhirRecord,
  User,
  Teacher,
  Student,
  ClassRoom,
} from '../types';

export const TI_SENANG_FIREBASE_CONFIG = {
  apiKey: 'AIzaSyCnuYiWNXQlwVlBKjAZkFCS1QyUYvHe8xo',
  databaseURL: 'https://ti-senang-default-rtdb.asia-southeast1.firebasedatabase.app',
  projectId: 'ti-senang-default-rtdb',
  authDomain: 'ti-senang-default-rtdb.firebaseapp.com',
  storageBucket: 'ti-senang-default-rtdb.appspot.com',
};

// URL Folder Google Drive Direktori Tugas Siswa
export const STUDENT_DRIVE_FOLDER_URL =
  'https://drive.google.com/drive/folders/1Xc-5Y2HWvLQie3zuQZmgh9GAtX62D34h?hl=ID';

// Inisialisasi Firebase App secara aman (singleton)
export const firebaseApp =
  getApps().length === 0 ? initializeApp(TI_SENANG_FIREBASE_CONFIG) : getApp();

export const firebaseDb: Database = getDatabase(firebaseApp);

export interface PortfolioComment {
  id: string;
  authorId: string;
  authorName: string;
  authorRole: 'guru' | 'murid' | 'admin';
  text: string;
  createdAt: string;
}

export interface PortfolioAppreciation {
  hebat: number; // 👏
  keren: number; // 💡
  inspiratif: number; // 🔥
  userAppreciations?: Record<string, 'hebat' | 'keren' | 'inspiratif'>;
}

export interface StudentTaskSubmission {
  id: string;
  missionId: string;
  studentId: string;
  studentName: string;
  classId: string;
  className: string;
  status: 'SUBMITTED' | 'REVIEWED' | 'GRADED';
  score?: number;
  xpEarned?: number;
  submittedAt: string;
  driveLink?: string;
  documentationUrl?: string;
  reflection?: string;
  conclusion?: string;
  answers?: Record<string, any>;
  teacherFeedback?: string;
  content?: string;
  fileAttachment?: string;
  tpId?: string;
}

export class FirebaseRealtimeService {
  private db: Database;
  private isOnline = false;
  private listeners: Map<string, Unsubscribe> = new Map();

  constructor() {
    this.db = firebaseDb;
    this.checkConnection();
  }

  public getDatabaseInstance(): Database {
    return this.db;
  }

  public async checkConnection(): Promise<boolean> {
    try {
      const res = await fetch(`${TI_SENANG_FIREBASE_CONFIG.databaseURL}/.json?shallow=true`, {
        method: 'GET',
      });
      this.isOnline = res.ok || res.status === 401 || res.status === 403;
      return this.isOnline;
    } catch {
      this.isOnline = false;
      return false;
    }
  }

  public isConnected(): boolean {
    return this.isOnline;
  }

  // =========================================================================
  // 1. NODE /misi : PENGELOLAAN MISI GURU REAL-TIME
  // =========================================================================

  /**
   * Berlangganan (real-time listener) perubahan daftar misi di node /misi
   */
  public subscribeMissions(callback: (missions: Mission[]) => void): () => void {
    const missionsRef = ref(this.db, 'misi');
    const unsub = onValue(
      missionsRef,
      (snapshot: DataSnapshot) => {
        const val = snapshot.val();
        if (!val) {
          callback([]);
          return;
        }
        const list: Mission[] = Object.keys(val).map((key) => ({
          ...val[key],
          id: val[key].id || key,
        }));
        // Urutkan berdasarkan waktu buat (terbaru atau nomor misi)
        list.sort((a, b) => (a.coreMissionNumber || 0) - (b.coreMissionNumber || 0));
        callback(list);
      },
      (error) => {
        console.warn('[Firebase] onValue /misi warning:', error.message);
        // Fallback REST fetch jika websocket diblokir di sandbox
        this.fetchMissionsREST().then(callback);
      }
    );

    return () => unsub();
  }

  public async fetchMissionsREST(): Promise<Mission[]> {
    try {
      const res = await fetch(
        `${TI_SENANG_FIREBASE_CONFIG.databaseURL}/misi.json?key=${TI_SENANG_FIREBASE_CONFIG.apiKey}`
      );
      if (!res.ok) return [];
      const data = await res.json();
      if (!data) return [];
      return Object.keys(data).map((key) => ({ ...data[key], id: data[key].id || key }));
    } catch (e) {
      console.warn('[Firebase REST] Failed to fetch /misi:', e);
      return [];
    }
  }

  /**
   * Simpan atau update Misi di node /misi/<missionId>
   */
  public async saveMission(mission: Mission): Promise<void> {
    const missionId = mission.id;
    const missionRef = ref(this.db, `misi/${missionId}`);
    try {
      await set(missionRef, mission);
    } catch (err) {
      console.warn('[Firebase] set /misi error, running REST fallback:', err);
      // REST fallback
      await fetch(
        `${TI_SENANG_FIREBASE_CONFIG.databaseURL}/misi/${missionId}.json?key=${TI_SENANG_FIREBASE_CONFIG.apiKey}`,
        {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(mission),
        }
      );
    }
  }

  public async setMisi(missionOrId: string | any, missionData?: any): Promise<void> {
    if (typeof missionOrId === 'object' && missionOrId !== null) {
      await this.saveMission(missionOrId);
    } else {
      await this.saveMission({ id: missionOrId, ...missionData });
    }
  }

  /**
   * Hapus Misi dari node /misi/<missionId>
   */
  public async deleteMission(missionId: string): Promise<void> {
    const missionRef = ref(this.db, `misi/${missionId}`);
    try {
      await remove(missionRef);
    } catch (err) {
      console.warn('[Firebase] remove /misi error, running REST fallback:', err);
      await fetch(
        `${TI_SENANG_FIREBASE_CONFIG.databaseURL}/misi/${missionId}.json?key=${TI_SENANG_FIREBASE_CONFIG.apiKey}`,
        { method: 'DELETE' }
      );
    }
  }

  // =========================================================================
  // 2. NODE /tugas_siswa : RESPON & PENGERJAAN TUGAS SISWA
  // =========================================================================

  /**
   * Berlangganan data pengerjaan tugas siswa di node /tugas_siswa
   */
  public subscribeStudentTasks(
    callback: (tasks: StudentTaskSubmission[]) => void,
    studentId?: string
  ): () => void {
    const tasksRef = ref(this.db, 'tugas_siswa');
    const unsub = onValue(
      tasksRef,
      (snapshot: DataSnapshot) => {
        const val = snapshot.val();
        if (!val) {
          callback([]);
          return;
        }
        let list: StudentTaskSubmission[] = Object.keys(val).map((key) => ({
          ...val[key],
          id: val[key].id || key,
        }));
        if (studentId) {
          list = list.filter((t) => t.studentId === studentId);
        }
        list.sort(
          (a, b) => new Date(b.submittedAt).getTime() - new Date(a.submittedAt).getTime()
        );
        callback(list);
      },
      (error) => {
        console.warn('[Firebase] onValue /tugas_siswa warning:', error.message);
        this.fetchStudentTasksREST(studentId).then(callback);
      }
    );

    return () => unsub();
  }

  public async fetchStudentTasksREST(studentId?: string): Promise<StudentTaskSubmission[]> {
    try {
      const res = await fetch(
        `${TI_SENANG_FIREBASE_CONFIG.databaseURL}/tugas_siswa.json?key=${TI_SENANG_FIREBASE_CONFIG.apiKey}`
      );
      if (!res.ok) return [];
      const data = await res.json();
      if (!data) return [];
      let list: StudentTaskSubmission[] = Object.keys(data).map((k) => ({
        ...data[k],
        id: data[k].id || k,
      }));
      if (studentId) {
        list = list.filter((t) => t.studentId === studentId);
      }
      return list;
    } catch {
      return [];
    }
  }

  /**
   * Simpan respon/tugas siswa ke /tugas_siswa/<submissionId>
   */
  public async submitStudentTask(submission: StudentTaskSubmission): Promise<void> {
    const subRef = ref(this.db, `tugas_siswa/${submission.id}`);
    try {
      await set(subRef, submission);
    } catch (err) {
      console.warn('[Firebase] set /tugas_siswa error, fallback REST:', err);
      await fetch(
        `${TI_SENANG_FIREBASE_CONFIG.databaseURL}/tugas_siswa/${submission.id}.json?key=${TI_SENANG_FIREBASE_CONFIG.apiKey}`,
        {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(submission),
        }
      );
    }
  }

  // =========================================================================
  // 3. NODE /portofolio : PUBLIKASI KARYA DI BERANDA KELAS & GURU
  // =========================================================================

  /**
   * Berlangganan publikasi portofolio di node /portofolio
   */
  public subscribePortfolios(callback: (portfolios: PortfolioItem[]) => void): () => void {
    const pfRef = ref(this.db, 'portofolio');
    const unsub = onValue(
      pfRef,
      (snapshot: DataSnapshot) => {
        const val = snapshot.val();
        if (!val) {
          callback([]);
          return;
        }
        const list: PortfolioItem[] = Object.keys(val).map((key) => ({
          ...val[key],
          id: val[key].id || key,
        }));
        // Urutkan berdasarkan yang terbaru
        list.sort((a, b) => {
          const timeA = new Date(a.date || a.createdAt || 0).getTime();
          const timeB = new Date(b.date || b.createdAt || 0).getTime();
          return timeB - timeA;
        });
        callback(list);
      },
      (error) => {
        console.warn('[Firebase] onValue /portofolio warning:', error.message);
        this.fetchPortfoliosREST().then(callback);
      }
    );

    return () => unsub();
  }

  public async fetchPortfoliosREST(): Promise<PortfolioItem[]> {
    try {
      const res = await fetch(
        `${TI_SENANG_FIREBASE_CONFIG.databaseURL}/portofolio.json?key=${TI_SENANG_FIREBASE_CONFIG.apiKey}`
      );
      if (!res.ok) return [];
      const data = await res.json();
      if (!data) return [];
      return Object.keys(data).map((k) => ({ ...data[k], id: data[k].id || k }));
    } catch {
      return [];
    }
  }

  /**
   * Simpan / Publikasikan Portofolio ke /portofolio/<portfolioId>
   */
  public async publishPortfolio(portfolio: PortfolioItem): Promise<void> {
    const pfId = portfolio.id;
    const pfRef = ref(this.db, `portofolio/${pfId}`);
    try {
      await set(pfRef, portfolio);
    } catch (err) {
      console.warn('[Firebase] set /portofolio error, fallback REST:', err);
      await fetch(
        `${TI_SENANG_FIREBASE_CONFIG.databaseURL}/portofolio/${pfId}.json?key=${TI_SENANG_FIREBASE_CONFIG.apiKey}`,
        {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(portfolio),
        }
      );
    }
  }

  /**
   * Tambah Like pada portofolio di node /portofolio/<portfolioId>/likesCount
   */
  public async toggleLikePortfolio(
    portfolioId: string,
    userId: string,
    currentLikes = 0
  ): Promise<number> {
    const newLikes = currentLikes + 1;
    const pfRef = ref(this.db, `portofolio/${portfolioId}`);
    try {
      await update(pfRef, {
        likesCount: newLikes,
        [`likedBy/${userId}`]: true,
      });
    } catch {
      await fetch(
        `${TI_SENANG_FIREBASE_CONFIG.databaseURL}/portofolio/${portfolioId}.json?key=${TI_SENANG_FIREBASE_CONFIG.apiKey}`,
        {
          method: 'PATCH',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ likesCount: newLikes }),
        }
      );
    }
    return newLikes;
  }

  /**
   * Tambah Komentar pada portofolio di node /portofolio/<portfolioId>/comments
   */
  public async addCommentToPortfolio(
    portfolioId: string,
    comment: Omit<PortfolioComment, 'id'>
  ): Promise<PortfolioComment> {
    const commentId = `cmt-${Date.now()}`;
    const newComment: PortfolioComment = {
      ...comment,
      id: commentId,
    };

    const cmtRef = ref(this.db, `portofolio/${portfolioId}/comments/${commentId}`);
    try {
      await set(cmtRef, newComment);
    } catch {
      await fetch(
        `${TI_SENANG_FIREBASE_CONFIG.databaseURL}/portofolio/${portfolioId}/comments/${commentId}.json?key=${TI_SENANG_FIREBASE_CONFIG.apiKey}`,
        {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(newComment),
        }
      );
    }
    return newComment;
  }

  /**
   * Hapus portofolio dari /portofolio/<portfolioId>
   */
  public async deletePortfolio(portfolioId: string): Promise<void> {
    const pfRef = ref(this.db, `portofolio/${portfolioId}`);
    try {
      await remove(pfRef);
    } catch {
      await fetch(
        `${TI_SENANG_FIREBASE_CONFIG.databaseURL}/portofolio/${portfolioId}.json?key=${TI_SENANG_FIREBASE_CONFIG.apiKey}`,
        { method: 'DELETE' }
      );
    }
  }

  /**
   * Like portofolio (alias)
   */
  public async likePortfolio(portfolioId: string, userId: string): Promise<number> {
    return this.toggleLikePortfolio(portfolioId, userId);
  }

  /**
   * Tambah komentar portofolio (alias)
   */
  public async addPortfolioComment(
    portfolioId: string,
    comment: { authorName: string; text: string; id?: string; authorId?: string; authorRole?: 'guru' | 'murid' | 'admin' }
  ): Promise<PortfolioComment> {
    return this.addCommentToPortfolio(portfolioId, {
      authorId: comment.authorId || 'usr-anonymous',
      authorName: comment.authorName,
      authorRole: comment.authorRole || 'murid',
      text: comment.text,
      createdAt: new Date().toISOString(),
    });
  }

  /**
   * Kirim Apresiasi (👏 Hebat, 💡 Keren, 🔥 Inspiratif) ke /portofolio/<portfolioId>/appreciations
   */
  public async addAppreciationToPortfolio(
    portfolioId: string,
    userId: string,
    type: 'hebat' | 'keren' | 'inspiratif'
  ): Promise<void> {
    try {
      const snap = await get(ref(this.db, `portofolio/${portfolioId}/appreciations/${type}`));
      const cur = (snap.val() as number) || 0;
      await update(ref(this.db, `portofolio/${portfolioId}/appreciations`), {
        [type]: cur + 1,
        [`users/${userId}`]: type,
      });
    } catch {
      // REST fallback
      const patchData = { [type]: 1 };
      await fetch(
        `${TI_SENANG_FIREBASE_CONFIG.databaseURL}/portofolio/${portfolioId}/appreciations.json?key=${TI_SENANG_FIREBASE_CONFIG.apiKey}`,
        {
          method: 'PATCH',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(patchData),
        }
      );
    }
  }

  // =========================================================================
  // 4. NODE /alme_sisipan : MISI ADAPTIF OTOMATIS ENGINE ALME
  // =========================================================================

  /**
   * Berlangganan data Misi Sisipan ALME di node /alme_sisipan
   */
  public subscribeAlmeSisipan(
    callback: (almeMissions: AlmeIndividualMission[]) => void,
    studentId?: string
  ): () => void {
    const almeRef = ref(this.db, 'alme_sisipan');
    const unsub = onValue(
      almeRef,
      (snapshot: DataSnapshot) => {
        const val = snapshot.val();
        if (!val) {
          callback([]);
          return;
        }
        let list: AlmeIndividualMission[] = Object.keys(val).map((key) => ({
          ...val[key],
          id: val[key].id || key,
        }));
        if (studentId) {
          list = list.filter((m) => m.studentId === studentId || m.studentId === 'all');
        }
        list.sort(
          (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
        );
        callback(list);
      },
      (error) => {
        console.warn('[Firebase] onValue /alme_sisipan warning:', error.message);
        this.fetchAlmeSisipanREST(studentId).then(callback);
      }
    );

    return () => unsub();
  }

  public async fetchAlmeSisipanREST(studentId?: string): Promise<AlmeIndividualMission[]> {
    try {
      const res = await fetch(
        `${TI_SENANG_FIREBASE_CONFIG.databaseURL}/alme_sisipan.json?key=${TI_SENANG_FIREBASE_CONFIG.apiKey}`
      );
      if (!res.ok) return [];
      const data = await res.json();
      if (!data) return [];
      let list: AlmeIndividualMission[] = Object.keys(data).map((k) => ({
        ...data[k],
        id: data[k].id || k,
      }));
      if (studentId) {
        list = list.filter((m) => m.studentId === studentId || m.studentId === 'all');
      }
      return list;
    } catch {
      return [];
    }
  }

  /**
   * Menyimpan / memicu Misi Sisipan ALME otomatis ke node /alme_sisipan/<almeId>
   */
  public async triggerAlmeMission(almeMission: AlmeIndividualMission): Promise<void> {
    const almeId = almeMission.id;
    const almeRef = ref(this.db, `alme_sisipan/${almeId}`);
    try {
      await set(almeRef, almeMission);
    } catch (err) {
      console.warn('[Firebase] set /alme_sisipan error, fallback REST:', err);
      await fetch(
        `${TI_SENANG_FIREBASE_CONFIG.databaseURL}/alme_sisipan/${almeId}.json?key=${TI_SENANG_FIREBASE_CONFIG.apiKey}`,
        {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(almeMission),
        }
      );
    }
  }

  /**
   * Selesaikan Misi Sisipan ALME
   */
  public async completeAlmeMission(almeId: string): Promise<void> {
    const almeRef = ref(this.db, `alme_sisipan/${almeId}`);
    try {
      await update(almeRef, {
        status: 'COMPLETED',
        completedAt: new Date().toISOString(),
      });
    } catch {
      await fetch(
        `${TI_SENANG_FIREBASE_CONFIG.databaseURL}/alme_sisipan/${almeId}.json?key=${TI_SENANG_FIREBASE_CONFIG.apiKey}`,
        {
          method: 'PATCH',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            status: 'COMPLETED',
            completedAt: new Date().toISOString(),
          }),
        }
      );
    }
  }

  // =========================================================================
  // 5. NODE /tujuan_pembelajaran : TUJUAN PEMBELAJARAN (TP)
  // =========================================================================

  public subscribeTujuanPembelajaran(
    callback: (tpList: TujuanPembelajaran[]) => void
  ): () => void {
    const tpRef = ref(this.db, 'tujuan_pembelajaran');
    const unsub = onValue(
      tpRef,
      (snapshot: DataSnapshot) => {
        const val = snapshot.val();
        if (!val) {
          callback([]);
          return;
        }
        const list: TujuanPembelajaran[] = Object.keys(val).map((k) => ({
          ...val[k],
          id: val[k].id || k,
        }));
        callback(list);
      },
      (error) => {
        console.warn('[Firebase] onValue /tujuan_pembelajaran warning:', error.message);
        this.fetchTujuanPembelajaranREST().then(callback);
      }
    );
    return () => unsub();
  }

  public async fetchTujuanPembelajaranREST(): Promise<TujuanPembelajaran[]> {
    try {
      const res = await fetch(
        `${TI_SENANG_FIREBASE_CONFIG.databaseURL}/tujuan_pembelajaran.json?key=${TI_SENANG_FIREBASE_CONFIG.apiKey}`
      );
      if (!res.ok) return [];
      const data = await res.json();
      if (!data) return [];
      return Object.keys(data).map((k) => ({ ...data[k], id: data[k].id || k }));
    } catch {
      return [];
    }
  }

  public async saveTujuanPembelajaran(tp: TujuanPembelajaran): Promise<void> {
    const tpRef = ref(this.db, `tujuan_pembelajaran/${tp.id}`);
    try {
      await set(tpRef, tp);
    } catch (err) {
      console.warn('[Firebase] set /tujuan_pembelajaran error, fallback REST:', err);
      await fetch(
        `${TI_SENANG_FIREBASE_CONFIG.databaseURL}/tujuan_pembelajaran/${tp.id}.json?key=${TI_SENANG_FIREBASE_CONFIG.apiKey}`,
        {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(tp),
        }
      );
    }
  }

  public async deleteTujuanPembelajaran(tpId: string): Promise<void> {
    const tpRef = ref(this.db, `tujuan_pembelajaran/${tpId}`);
    try {
      await remove(tpRef);
    } catch {
      await fetch(
        `${TI_SENANG_FIREBASE_CONFIG.databaseURL}/tujuan_pembelajaran/${tpId}.json?key=${TI_SENANG_FIREBASE_CONFIG.apiKey}`,
        { method: 'DELETE' }
      );
    }
  }

  // =========================================================================
  // 6. NODE /asesmen_awal : ASESMEN AWAL DIAGNOSTIK
  // =========================================================================

  public subscribeAsesmenAwal(
    callback: (list: AsesmenAwalInput[]) => void
  ): () => void {
    const aswRef = ref(this.db, 'asesmen_awal');
    const unsub = onValue(
      aswRef,
      (snapshot: DataSnapshot) => {
        const val = snapshot.val();
        if (!val) {
          callback([]);
          return;
        }
        const list: AsesmenAwalInput[] = Object.keys(val).map((k) => ({
          ...val[k],
          id: val[k].id || k,
        }));
        callback(list);
      },
      (error) => {
        console.warn('[Firebase] onValue /asesmen_awal warning:', error.message);
        this.fetchAsesmenAwalREST().then(callback);
      }
    );
    return () => unsub();
  }

  public async fetchAsesmenAwalREST(): Promise<AsesmenAwalInput[]> {
    try {
      const res = await fetch(
        `${TI_SENANG_FIREBASE_CONFIG.databaseURL}/asesmen_awal.json?key=${TI_SENANG_FIREBASE_CONFIG.apiKey}`
      );
      if (!res.ok) return [];
      const data = await res.json();
      if (!data) return [];
      return Object.keys(data).map((k) => ({ ...data[k], id: data[k].id || k }));
    } catch {
      return [];
    }
  }

  public async saveAsesmenAwal(record: AsesmenAwalInput): Promise<void> {
    const aswRef = ref(this.db, `asesmen_awal/${record.id}`);
    try {
      await set(aswRef, record);
    } catch (err) {
      console.warn('[Firebase] set /asesmen_awal error, fallback REST:', err);
      await fetch(
        `${TI_SENANG_FIREBASE_CONFIG.databaseURL}/asesmen_awal/${record.id}.json?key=${TI_SENANG_FIREBASE_CONFIG.apiKey}`,
        {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(record),
        }
      );
    }
  }

  public async deleteAsesmenAwal(id: string): Promise<void> {
    const aswRef = ref(this.db, `asesmen_awal/${id}`);
    try {
      await remove(aswRef);
    } catch {
      await fetch(
        `${TI_SENANG_FIREBASE_CONFIG.databaseURL}/asesmen_awal/${id}.json?key=${TI_SENANG_FIREBASE_CONFIG.apiKey}`,
        { method: 'DELETE' }
      );
    }
  }

  // =========================================================================
  // 7. NODE /asesmen_akhir : ASESMEN AKHIR SUMATIF
  // =========================================================================

  public subscribeAsesmenAkhir(
    callback: (list: AsesmenAkhirRecord[]) => void
  ): () => void {
    const askRef = ref(this.db, 'asesmen_akhir');
    const unsub = onValue(
      askRef,
      (snapshot: DataSnapshot) => {
        const val = snapshot.val();
        if (!val) {
          callback([]);
          return;
        }
        const list: AsesmenAkhirRecord[] = Object.keys(val).map((k) => ({
          ...val[k],
          id: val[k].id || k,
        }));
        callback(list);
      },
      (error) => {
        console.warn('[Firebase] onValue /asesmen_akhir warning:', error.message);
        this.fetchAsesmenAkhirREST().then(callback);
      }
    );
    return () => unsub();
  }

  public async fetchAsesmenAkhirREST(): Promise<AsesmenAkhirRecord[]> {
    try {
      const res = await fetch(
        `${TI_SENANG_FIREBASE_CONFIG.databaseURL}/asesmen_akhir.json?key=${TI_SENANG_FIREBASE_CONFIG.apiKey}`
      );
      if (!res.ok) return [];
      const data = await res.json();
      if (!data) return [];
      return Object.keys(data).map((k) => ({ ...data[k], id: data[k].id || k }));
    } catch {
      return [];
    }
  }

  public async saveAsesmenAkhir(record: AsesmenAkhirRecord): Promise<void> {
    const askRef = ref(this.db, `asesmen_akhir/${record.id}`);
    try {
      await set(askRef, record);
    } catch (err) {
      console.warn('[Firebase] set /asesmen_akhir error, fallback REST:', err);
      await fetch(
        `${TI_SENANG_FIREBASE_CONFIG.databaseURL}/asesmen_akhir/${record.id}.json?key=${TI_SENANG_FIREBASE_CONFIG.apiKey}`,
        {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(record),
        }
      );
    }
  }

  public async deleteAsesmenAkhir(id: string): Promise<void> {
    const askRef = ref(this.db, `asesmen_akhir/${id}`);
    try {
      await remove(askRef);
    } catch {
      await fetch(
        `${TI_SENANG_FIREBASE_CONFIG.databaseURL}/asesmen_akhir/${id}.json?key=${TI_SENANG_FIREBASE_CONFIG.apiKey}`,
        { method: 'DELETE' }
      );
    }
  }

  // =========================================================================
  // 8. SENSOR KIT TI SENANG (5 PORT REAL-TIME DARI FIREBASE)
  // =========================================================================

  /**
   * Berlangganan (real-time listener) pembacaan sensor dari Firebase RTDB
   * Membaca node /data_esp dan /data/<kelas>/<kelompok>/sensor dan /sensor
   */
  public subscribeSensorData(
    classKey: string = 'xii_1',
    kelompokKey: string = 'kelompok_1',
    callback: (data: {
      isKitActive?: boolean;
      port1Suhu?: number;
      port2Cahaya?: number;
      port3Kelembaban?: number;
      port4Arus?: number;
      port5Gerak?: number | string;
      connectedPorts: {
        port1: boolean;
        port2: boolean;
        port3: boolean;
        port4: boolean;
        port5: boolean;
      };
      timestamp: number;
      raw?: any;
    }) => void
  ): () => void {
    const sanitizedClass = classKey.toLowerCase().replace(/[^a-z0-9_]/g, '_');
    const sanitizedGroup = kelompokKey.toLowerCase().replace(/[^a-z0-9_]/g, '_');

    // Cek di node data_esp/<kelas>/<kelompok>
    const espRef = ref(this.db, `data_esp/${sanitizedClass}/${sanitizedGroup}`);

    const parsePayload = (val: any) => {
      // 1. Cek apakah kit berstatus mati / offline / saklar mati
      const isMatiExplicit =
        !val ||
        val.status === 'mati' ||
        val.status === 'off' ||
        val.status === 'offline' ||
        val.status === 'nonaktif' ||
        val.kit_status === 'mati' ||
        val.kit_status === 'off' ||
        val.kit_status === 'offline' ||
        val.metadata?.status === 'mati' ||
        val.metadata?.status === 'off' ||
        val.metadata?.status === 'offline' ||
        val.power === false ||
        val.power === 0 ||
        val.power === 'off' ||
        val.power === 'mati' ||
        val.online === false ||
        val.connected === false ||
        val.kit === false ||
        val.kit === 'mati' ||
        val.kit === 'off' ||
        val.device === 'off' ||
        val.device === 'mati' ||
        val.active === false ||
        val.saklar === 0 ||
        val.saklar === false;

      // 2. Cek apakah timestamp data sudah kadaluarsa (heartbeat > 15 detik tidak ada update)
      const lastUpdateStr = val?.updatedAt || val?.metadata?.updatedAt;
      const lastUpdateEpoch = val?.timestamp
        ? Number(val.timestamp)
        : lastUpdateStr
        ? new Date(lastUpdateStr).getTime()
        : 0;
      const isStaleHeartbeat = lastUpdateEpoch > 0 && Date.now() - lastUpdateEpoch > 15000;

      // Jika kit mati atau tidak ada sinyal aktif, hapus data hasil sensor sehingga port terlihat tidak aktif (abu-abu)
      if (isMatiExplicit || isStaleHeartbeat) {
        callback({
          isKitActive: false,
          port1Suhu: undefined,
          port2Cahaya: undefined,
          port3Kelembaban: undefined,
          port4Arus: undefined,
          port5Gerak: undefined,
          connectedPorts: { port1: false, port2: false, port3: false, port4: false, port5: false },
          timestamp: Date.now(),
          raw: val,
        });
        return;
      }

      // Deteksi Port 1: Suhu murni (suhu_air untuk probe air/DS18B20 atau suhu/temp untuk DHT)
      let suhuVal: number | undefined = undefined;
      if (val.suhu_air !== undefined && val.suhu_air !== null && Number(val.suhu_air) !== 0 && Number(val.suhu_air) !== -127) {
        suhuVal = Number(val.suhu_air);
      } else if (val.suhu !== undefined && val.suhu !== null && Number(val.suhu) !== 0 && Number(val.suhu) !== -127) {
        suhuVal = Number(val.suhu);
      } else if (val.temp !== undefined && val.temp !== null && Number(val.temp) !== 0 && Number(val.temp) !== -127) {
        suhuVal = Number(val.temp);
      } else if (val.temperature !== undefined && val.temperature !== null && Number(val.temperature) !== 0 && Number(val.temperature) !== -127) {
        suhuVal = Number(val.temperature);
      } else if (val.suhu_air !== undefined && val.suhu_air !== null && !isNaN(Number(val.suhu_air))) {
        suhuVal = Number(val.suhu_air);
      } else if (val.suhu !== undefined && val.suhu !== null && !isNaN(Number(val.suhu))) {
        suhuVal = Number(val.suhu);
      }

      const port1Connected =
        suhuVal !== undefined &&
        suhuVal !== null &&
        !isNaN(Number(suhuVal)) &&
        Number(suhuVal) !== -127 &&
        (Number(suhuVal) !== 0 || (Number(val.suhu_air ?? 0) === 0 && Number(val.suhu ?? 0) === 0 ? false : true));

      // Deteksi Port 2: Cahaya (cahaya, light, lux, ldr) - HANYA jika sensor terhubung secara fisik (> 0)
      const rawCahaya =
        val.cahaya !== undefined
          ? val.cahaya
          : val.light !== undefined
          ? val.light
          : val.lux;
      const port2Connected =
        rawCahaya !== undefined && rawCahaya !== null && !isNaN(Number(rawCahaya)) && Number(rawCahaya) > 0;
      const cahayaVal = port2Connected ? Number(rawCahaya) : undefined;

      // Deteksi Port 3: Kelembaban Udara - HANYA jika sensor terhubung secara fisik (> 0)
      const rawKelembaban =
        val.kelembapan !== undefined
          ? val.kelembapan
          : val.kelembaban !== undefined
          ? val.kelembaban
          : val.humidity;
      const port3Connected =
        rawKelembaban !== undefined &&
        rawKelembaban !== null &&
        !isNaN(Number(rawKelembaban)) &&
        Number(rawKelembaban) > 0;
      const kelembabanVal = port3Connected ? Number(rawKelembaban) : undefined;

      // Deteksi Port 4: Arus (arus, current, amp, ampere, mA) - HANYA jika terhubung (> 0)
      const rawArus =
        val.arus !== undefined
          ? val.arus
          : val.current !== undefined
          ? val.current
          : val.ampere;
      const port4Connected =
        rawArus !== undefined && rawArus !== null && !isNaN(Number(rawArus)) && Number(rawArus) > 0;
      const arusVal = port4Connected ? Number(rawArus) : undefined;

      // Deteksi Port 5: Gerak (gerak, motion, pir, distance, jarak)
      const rawGerak =
        val.gerak !== undefined
          ? val.gerak
          : val.motion !== undefined
          ? val.motion
          : val.distance;
      const port5Connected =
        rawGerak !== undefined &&
        rawGerak !== null &&
        rawGerak !== 0 &&
        rawGerak !== false &&
        rawGerak !== '0';
      const gerakVal = port5Connected
        ? typeof rawGerak === 'number'
          ? Number(rawGerak)
          : String(rawGerak)
        : undefined;

      const hasAnySensorReading =
        port1Connected || port2Connected || port3Connected || port4Connected || port5Connected;

      if (!hasAnySensorReading) {
        callback({
          isKitActive: false,
          port1Suhu: undefined,
          port2Cahaya: undefined,
          port3Kelembaban: undefined,
          port4Arus: undefined,
          port5Gerak: undefined,
          connectedPorts: { port1: false, port2: false, port3: false, port4: false, port5: false },
          timestamp: Date.now(),
          raw: val,
        });
        return;
      }

      callback({
        isKitActive: true,
        port1Suhu: port1Connected ? Number(suhuVal) : undefined,
        port2Cahaya: port2Connected ? Number(cahayaVal) : undefined,
        port3Kelembaban: port3Connected ? Number(kelembabanVal) : undefined,
        port4Arus: port4Connected ? Number(arusVal) : undefined,
        port5Gerak: port5Connected ? (typeof gerakVal === 'number' ? Number(gerakVal) : String(gerakVal)) : undefined,
        connectedPorts: {
          port1: port1Connected,
          port2: port2Connected,
          port3: port3Connected,
          port4: port4Connected,
          port5: port5Connected,
        },
        timestamp: Date.now(),
        raw: val,
      });
    };

    let hasReceivedValidData = false;

    const unsub = onValue(
      espRef,
      (snapshot: DataSnapshot) => {
        const val = snapshot.val();
        if (val) {
          hasReceivedValidData = true;
          parsePayload(val);
        } else if (!hasReceivedValidData) {
          // Fallback fetch alternative REST
          this.fetchSensorDataREST(classKey, kelompokKey).then((altVal) => {
            if (altVal) {
              parsePayload(altVal);
            } else {
              parsePayload(null);
            }
          });
        }
      },
      () => {
        // Fallback REST fetch
        this.fetchSensorDataREST(classKey, kelompokKey).then((val) => {
          parsePayload(val);
        });
      }
    );

    // Also listen to raw path if different from sanitized
    let unsubRaw: (() => void) | undefined;
    if (classKey !== sanitizedClass || kelompokKey !== sanitizedGroup) {
      try {
        const rawRef = ref(this.db, `data_esp/${classKey}/${kelompokKey}`);
        unsubRaw = onValue(rawRef, (snapshot: DataSnapshot) => {
          const val = snapshot.val();
          if (val) {
            hasReceivedValidData = true;
            parsePayload(val);
          }
        });
      } catch {
        // Ignore path syntax exceptions for raw keys
      }
    }

    return () => {
      unsub();
      if (unsubRaw) unsubRaw();
    };
  }

  public async fetchSensorDataREST(
    classKey: string = 'xii_1',
    kelompokKey: string = 'kelompok_1'
  ): Promise<any> {
    try {
      const sanitizedClass = classKey.toLowerCase().replace(/[^a-z0-9_]/g, '_');
      const sanitizedGroup = kelompokKey.toLowerCase().replace(/[^a-z0-9_]/g, '_');

      // 1. Coba path sanitized (e.g. data_esp/xii_1/kelompok_1)
      const res = await fetch(
        `${TI_SENANG_FIREBASE_CONFIG.databaseURL}/data_esp/${sanitizedClass}/${sanitizedGroup}.json?key=${TI_SENANG_FIREBASE_CONFIG.apiKey}`
      );
      if (res.ok) {
        const val = await res.json();
        if (val) return val;
      }

      // 2. Coba path raw jika berbeda (e.g. data_esp/XII-1/Kelompok 1)
      if (classKey !== sanitizedClass || kelompokKey !== sanitizedGroup) {
        const resRaw = await fetch(
          `${TI_SENANG_FIREBASE_CONFIG.databaseURL}/data_esp/${encodeURIComponent(classKey)}/${encodeURIComponent(kelompokKey)}.json?key=${TI_SENANG_FIREBASE_CONFIG.apiKey}`
        );
        if (resRaw.ok) {
          const valRaw = await resRaw.json();
          if (valRaw) return valRaw;
        }
      }

      return null;
    } catch {
      return null;
    }
  }

  // =========================================================================
  // 9. DATA KELOMPOK EKSPERIMEN (PATH: data / kelas / kelompok / data_eksperimen)
  // =========================================================================

  /**
   * Mengambil data eksperimen kelompok dari Firebase:
   * Path: /data/<kelas>/<kelompok>/data_eksperimen
   */
  public async fetchDataKelompok(
    kelas: string = 'XII-1',
    kelompok: string = 'Kelompok 1'
  ): Promise<any> {
    const sanitizedClass = kelas.toLowerCase().replace(/[^a-z0-9_]/g, '_');
    const sanitizedGroup = kelompok.toLowerCase().replace(/[^a-z0-9_]/g, '_');

    try {
      // 1. Coba ambil dari /data/<kelas>/<kelompok>/data_eksperimen
      const res = await fetch(
        `${TI_SENANG_FIREBASE_CONFIG.databaseURL}/data/${sanitizedClass}/${sanitizedGroup}/data_eksperimen.json?key=${TI_SENANG_FIREBASE_CONFIG.apiKey}`
      );
      if (res.ok) {
        const val = await res.json();
        if (val) return val;
      }

      // 2. Fallback cek di /data_kelompok/<kelas>/<kelompok>
      const resAlt = await fetch(
        `${TI_SENANG_FIREBASE_CONFIG.databaseURL}/data_kelompok/${sanitizedClass}/${sanitizedGroup}.json?key=${TI_SENANG_FIREBASE_CONFIG.apiKey}`
      );
      if (resAlt.ok) {
        const valAlt = await resAlt.json();
        if (valAlt) return valAlt;
      }

      return null;
    } catch (err) {
      console.warn('[Firebase RTDB] Gagal fetch data kelompok:', err);
      return null;
    }
  }

  /**
   * Menyimpan data eksperimen kelompok ke Firebase RTDB:
   * Path: /data/<kelas>/<kelompok>/data_eksperimen
   */
  public async saveDataKelompok(
    kelas: string = 'XII-1',
    kelompok: string = 'Kelompok 1',
    dataEksperimen: any
  ): Promise<void> {
    const sanitizedClass = kelas.toLowerCase().replace(/[^a-z0-9_]/g, '_');
    const sanitizedGroup = kelompok.toLowerCase().replace(/[^a-z0-9_]/g, '_');

    const groupRef = ref(
      this.db,
      `data/${sanitizedClass}/${sanitizedGroup}/data_eksperimen`
    );

    const payload = {
      kelas,
      kelompok,
      updatedAt: new Date().toISOString(),
      rows: dataEksperimen.rows || dataEksperimen,
      metadata: dataEksperimen.metadata || {
        source: 'Kit TI SENANG Lab',
        recordedCount: (dataEksperimen.rows || dataEksperimen)?.length || 0,
      },
    };

    try {
      await set(groupRef, payload);
    } catch {
      await fetch(
        `${TI_SENANG_FIREBASE_CONFIG.databaseURL}/data/${sanitizedClass}/${sanitizedGroup}/data_eksperimen.json?key=${TI_SENANG_FIREBASE_CONFIG.apiKey}`,
        {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload),
        }
      );
    }
  }

  // =========================================================================
  // 10. SIMPAN DATABASE MISI SISWA (EKSPERIMEN & SIMULASI)
  // =========================================================================

  /**
   * Menyimpan hasil tabel eksperimen siswa ke database misi siswa di Firebase:
   * Path: /misi_siswa_eksperimen/<studentId>/<missionId>
   */
  public async saveStudentExperimentData(
    studentId: string,
    missionId: string,
    experimentPayload: {
      studentName?: string;
      className?: string;
      kelompok?: string;
      rows: any[];
      notes?: string;
      parameters?: any;
    }
  ): Promise<void> {
    const payload = {
      ...experimentPayload,
      studentId,
      missionId,
      savedAt: new Date().toISOString(),
      status: 'COMPLETED',
    };

    const expRef = ref(this.db, `misi_siswa_eksperimen/${studentId}/${missionId}`);

    try {
      await set(expRef, payload);
    } catch {
      await fetch(
        `${TI_SENANG_FIREBASE_CONFIG.databaseURL}/misi_siswa_eksperimen/${studentId}/${missionId}.json?key=${TI_SENANG_FIREBASE_CONFIG.apiKey}`,
        {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload),
        }
      );
    }
  }

  // =========================================================================
  // 11. LINK SIMULASI GURU (SIMULASI VIRTUAL)
  // =========================================================================

  /**
   * Menyimpan link simulasi virtual yang dikirimkan guru
   * Path: /simulasi_guru/<subjectId>/<classId>
   */
  public async saveTeacherSimulationLink(
    subjectId: string,
    classId: string,
    data: {
      title: string;
      url: string;
      guide?: string;
      subjectName?: string;
      teacherName?: string;
    }
  ): Promise<void> {
    const payload = {
      ...data,
      subjectId,
      classId,
      updatedAt: new Date().toISOString(),
    };

    const simRef = ref(this.db, `simulasi_guru/${subjectId}/${classId}`);
    try {
      await set(simRef, payload);
    } catch {
      await fetch(
        `${TI_SENANG_FIREBASE_CONFIG.databaseURL}/simulasi_guru/${subjectId}/${classId}.json?key=${TI_SENANG_FIREBASE_CONFIG.apiKey}`,
        {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload),
        }
      );
    }
  }

  /**
   * Mengambil link simulasi virtual guru untuk mapel & kelas tertentu
   */
  public async fetchTeacherSimulationLink(
    subjectId: string,
    classId: string = 'cls-xii-1'
  ): Promise<{ title: string; url: string; guide?: string; teacherName?: string } | null> {
    try {
      const res = await fetch(
        `${TI_SENANG_FIREBASE_CONFIG.databaseURL}/simulasi_guru/${subjectId}/${classId}.json?key=${TI_SENANG_FIREBASE_CONFIG.apiKey}`
      );
      if (res.ok) {
        const data = await res.json();
        if (data && data.url) return data;
      }

      // Cek general link untuk mapel
      const resGen = await fetch(
        `${TI_SENANG_FIREBASE_CONFIG.databaseURL}/simulasi_guru/${subjectId}.json?key=${TI_SENANG_FIREBASE_CONFIG.apiKey}`
      );
      if (resGen.ok) {
        const dataGen = await resGen.json();
        if (dataGen) {
          // Cari entry pertama yang memiliki url
          const foundKey = Object.keys(dataGen).find((k) => dataGen[k]?.url);
          if (foundKey) return dataGen[foundKey];
        }
      }

      return null;
    } catch {
      return null;
    }
  }

  // =========================================================================
  // 12. DATA ADMIN : PENGELOLAAN GURU, MURID, KELAS, AKUN & KREDENSIAL
  // =========================================================================

  /**
   * Helper untuk membersihkan key username agar aman disimpan di Firebase RTDB
   */
  private sanitizeRtdbKey(key: string): string {
    return encodeURIComponent(key.toLowerCase().trim()).replace(/\./g, '%2E');
  }

  private desanitizeRtdbKey(key: string): string {
    try {
      return decodeURIComponent(key);
    } catch {
      return key;
    }
  }

  // --- GURU (TEACHERS) ---
  public subscribeTeachers(callback: (teachers: Teacher[]) => void): () => void {
    const teachersRef = ref(this.db, 'guru');
    const unsub = onValue(
      teachersRef,
      (snapshot: DataSnapshot) => {
        const val = snapshot.val();
        if (!val) {
          callback([]);
          return;
        }
        const list: Teacher[] = Object.keys(val).map((k) => ({
          ...val[k],
          id: val[k].id || k,
        }));
        callback(list);
      },
      (error) => {
        console.warn('[Firebase] onValue /guru warning:', error.message);
        this.fetchTeachersREST().then(callback);
      }
    );
    return () => unsub();
  }

  public async fetchTeachersREST(): Promise<Teacher[]> {
    try {
      const res = await fetch(
        `${TI_SENANG_FIREBASE_CONFIG.databaseURL}/guru.json?key=${TI_SENANG_FIREBASE_CONFIG.apiKey}`
      );
      if (!res.ok) return [];
      const data = await res.json();
      if (!data) return [];
      return Object.keys(data).map((k) => ({ ...data[k], id: data[k].id || k }));
    } catch {
      return [];
    }
  }

  public async saveTeacher(teacher: Teacher): Promise<void> {
    const teacherId = teacher.id;
    const teacherRef = ref(this.db, `guru/${teacherId}`);
    try {
      await set(teacherRef, teacher);
    } catch (err) {
      console.warn('[Firebase] set /guru error, fallback REST:', err);
      await fetch(
        `${TI_SENANG_FIREBASE_CONFIG.databaseURL}/guru/${teacherId}.json?key=${TI_SENANG_FIREBASE_CONFIG.apiKey}`,
        {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(teacher),
        }
      );
    }
  }

  public async saveTeachers(teachers: Teacher[]): Promise<void> {
    const map: Record<string, Teacher> = {};
    teachers.forEach((t) => {
      map[t.id] = t;
    });
    const teachersRef = ref(this.db, 'guru');
    try {
      await set(teachersRef, map);
    } catch {
      await fetch(
        `${TI_SENANG_FIREBASE_CONFIG.databaseURL}/guru.json?key=${TI_SENANG_FIREBASE_CONFIG.apiKey}`,
        {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(map),
        }
      );
    }
  }

  public async deleteTeacher(teacherId: string): Promise<void> {
    const teacherRef = ref(this.db, `guru/${teacherId}`);
    try {
      await remove(teacherRef);
    } catch {
      await fetch(
        `${TI_SENANG_FIREBASE_CONFIG.databaseURL}/guru/${teacherId}.json?key=${TI_SENANG_FIREBASE_CONFIG.apiKey}`,
        { method: 'DELETE' }
      );
    }
  }

  // --- MURID (STUDENTS) ---
  public subscribeStudents(callback: (students: Student[]) => void): () => void {
    const studentsRef = ref(this.db, 'murid');
    const unsub = onValue(
      studentsRef,
      (snapshot: DataSnapshot) => {
        const val = snapshot.val();
        if (!val) {
          callback([]);
          return;
        }
        const list: Student[] = Object.keys(val).map((k) => ({
          ...val[k],
          id: val[k].id || k,
        }));
        callback(list);
      },
      (error) => {
        console.warn('[Firebase] onValue /murid warning:', error.message);
        this.fetchStudentsREST().then(callback);
      }
    );
    return () => unsub();
  }

  public async fetchStudentsREST(): Promise<Student[]> {
    try {
      const res = await fetch(
        `${TI_SENANG_FIREBASE_CONFIG.databaseURL}/murid.json?key=${TI_SENANG_FIREBASE_CONFIG.apiKey}`
      );
      if (!res.ok) return [];
      const data = await res.json();
      if (!data) return [];
      return Object.keys(data).map((k) => ({ ...data[k], id: data[k].id || k }));
    } catch {
      return [];
    }
  }

  public async saveStudent(student: Student): Promise<void> {
    const studentId = student.id;
    const studentRef = ref(this.db, `murid/${studentId}`);
    try {
      await set(studentRef, student);
    } catch (err) {
      console.warn('[Firebase] set /murid error, fallback REST:', err);
      await fetch(
        `${TI_SENANG_FIREBASE_CONFIG.databaseURL}/murid/${studentId}.json?key=${TI_SENANG_FIREBASE_CONFIG.apiKey}`,
        {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(student),
        }
      );
    }
  }

  public async saveStudents(students: Student[]): Promise<void> {
    const map: Record<string, Student> = {};
    students.forEach((s) => {
      map[s.id] = s;
    });
    const studentsRef = ref(this.db, 'murid');
    try {
      await set(studentsRef, map);
    } catch {
      await fetch(
        `${TI_SENANG_FIREBASE_CONFIG.databaseURL}/murid.json?key=${TI_SENANG_FIREBASE_CONFIG.apiKey}`,
        {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(map),
        }
      );
    }
  }

  public async deleteStudent(studentId: string): Promise<void> {
    const studentRef = ref(this.db, `murid/${studentId}`);
    try {
      await remove(studentRef);
    } catch {
      await fetch(
        `${TI_SENANG_FIREBASE_CONFIG.databaseURL}/murid/${studentId}.json?key=${TI_SENANG_FIREBASE_CONFIG.apiKey}`,
        { method: 'DELETE' }
      );
    }
  }

  // --- KELAS (CLASSES) ---
  public subscribeClasses(callback: (classes: ClassRoom[]) => void): () => void {
    const classesRef = ref(this.db, 'kelas');
    const unsub = onValue(
      classesRef,
      (snapshot: DataSnapshot) => {
        const val = snapshot.val();
        if (!val) {
          callback([]);
          return;
        }
        const list: ClassRoom[] = Object.keys(val).map((k) => ({
          ...val[k],
          id: val[k].id || k,
        }));
        callback(list);
      },
      (error) => {
        console.warn('[Firebase] onValue /kelas warning:', error.message);
        this.fetchClassesREST().then(callback);
      }
    );
    return () => unsub();
  }

  public async fetchClassesREST(): Promise<ClassRoom[]> {
    try {
      const res = await fetch(
        `${TI_SENANG_FIREBASE_CONFIG.databaseURL}/kelas.json?key=${TI_SENANG_FIREBASE_CONFIG.apiKey}`
      );
      if (!res.ok) return [];
      const data = await res.json();
      if (!data) return [];
      return Object.keys(data).map((k) => ({ ...data[k], id: data[k].id || k }));
    } catch {
      return [];
    }
  }

  public async saveClass(cls: ClassRoom): Promise<void> {
    const classId = cls.id;
    const classRef = ref(this.db, `kelas/${classId}`);
    try {
      await set(classRef, cls);
    } catch (err) {
      console.warn('[Firebase] set /kelas error, fallback REST:', err);
      await fetch(
        `${TI_SENANG_FIREBASE_CONFIG.databaseURL}/kelas/${classId}.json?key=${TI_SENANG_FIREBASE_CONFIG.apiKey}`,
        {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(cls),
        }
      );
    }
  }

  public async saveClasses(classes: ClassRoom[]): Promise<void> {
    const map: Record<string, ClassRoom> = {};
    classes.forEach((c) => {
      map[c.id] = c;
    });
    const classesRef = ref(this.db, 'kelas');
    try {
      await set(classesRef, map);
    } catch {
      await fetch(
        `${TI_SENANG_FIREBASE_CONFIG.databaseURL}/kelas.json?key=${TI_SENANG_FIREBASE_CONFIG.apiKey}`,
        {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(map),
        }
      );
    }
  }

  public async deleteClass(classId: string): Promise<void> {
    const classRef = ref(this.db, `kelas/${classId}`);
    try {
      await remove(classRef);
    } catch {
      await fetch(
        `${TI_SENANG_FIREBASE_CONFIG.databaseURL}/kelas/${classId}.json?key=${TI_SENANG_FIREBASE_CONFIG.apiKey}`,
        { method: 'DELETE' }
      );
    }
  }

  // --- PENGGUNA (USERS) ---
  public subscribeUsers(callback: (users: User[]) => void): () => void {
    const usersRef = ref(this.db, 'pengguna');
    const unsub = onValue(
      usersRef,
      (snapshot: DataSnapshot) => {
        const val = snapshot.val();
        if (!val) {
          callback([]);
          return;
        }
        const list: User[] = Object.keys(val).map((k) => ({
          ...val[k],
          id: val[k].id || k,
        }));
        callback(list);
      },
      (error) => {
        console.warn('[Firebase] onValue /pengguna warning:', error.message);
        this.fetchUsersREST().then(callback);
      }
    );
    return () => unsub();
  }

  public async fetchUsersREST(): Promise<User[]> {
    try {
      const res = await fetch(
        `${TI_SENANG_FIREBASE_CONFIG.databaseURL}/pengguna.json?key=${TI_SENANG_FIREBASE_CONFIG.apiKey}`
      );
      if (!res.ok) return [];
      const data = await res.json();
      if (!data) return [];
      return Object.keys(data).map((k) => ({ ...data[k], id: data[k].id || k }));
    } catch {
      return [];
    }
  }

  public async saveUser(user: User): Promise<void> {
    const userId = user.id;
    const userRef = ref(this.db, `pengguna/${userId}`);
    try {
      await set(userRef, user);
    } catch (err) {
      console.warn('[Firebase] set /pengguna error, fallback REST:', err);
      await fetch(
        `${TI_SENANG_FIREBASE_CONFIG.databaseURL}/pengguna/${userId}.json?key=${TI_SENANG_FIREBASE_CONFIG.apiKey}`,
        {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(user),
        }
      );
    }
  }

  public async saveUsers(users: User[]): Promise<void> {
    const map: Record<string, User> = {};
    users.forEach((u) => {
      map[u.id] = u;
    });
    const usersRef = ref(this.db, 'pengguna');
    try {
      await set(usersRef, map);
    } catch {
      await fetch(
        `${TI_SENANG_FIREBASE_CONFIG.databaseURL}/pengguna.json?key=${TI_SENANG_FIREBASE_CONFIG.apiKey}`,
        {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(map),
        }
      );
    }
  }

  public async deleteUser(userId: string): Promise<void> {
    const userRef = ref(this.db, `pengguna/${userId}`);
    try {
      await remove(userRef);
    } catch {
      await fetch(
        `${TI_SENANG_FIREBASE_CONFIG.databaseURL}/pengguna/${userId}.json?key=${TI_SENANG_FIREBASE_CONFIG.apiKey}`,
        { method: 'DELETE' }
      );
    }
  }

  // --- KREDENSIAL (LOGIN CREDENTIALS) ---
  public subscribeCredentials(callback: (creds: Record<string, string>) => void): () => void {
    const credsRef = ref(this.db, 'kredensial');
    const unsub = onValue(
      credsRef,
      (snapshot: DataSnapshot) => {
        const val = snapshot.val();
        if (!val) {
          callback({});
          return;
        }
        const result: Record<string, string> = {};
        Object.keys(val).forEach((k) => {
          const item = val[k];
          if (typeof item === 'string') {
            result[this.desanitizeRtdbKey(k)] = item;
          } else if (item && typeof item === 'object' && item.password) {
            const rawUser = item.username || this.desanitizeRtdbKey(k);
            result[rawUser.toLowerCase()] = item.password;
          }
        });
        callback(result);
      },
      (error) => {
        console.warn('[Firebase] onValue /kredensial warning:', error.message);
        this.fetchCredentialsREST().then(callback);
      }
    );
    return () => unsub();
  }

  public async fetchCredentialsREST(): Promise<Record<string, string>> {
    try {
      const res = await fetch(
        `${TI_SENANG_FIREBASE_CONFIG.databaseURL}/kredensial.json?key=${TI_SENANG_FIREBASE_CONFIG.apiKey}`
      );
      if (!res.ok) return {};
      const data = await res.json();
      if (!data) return {};
      const result: Record<string, string> = {};
      Object.keys(data).forEach((k) => {
        const item = data[k];
        if (typeof item === 'string') {
          result[this.desanitizeRtdbKey(k)] = item;
        } else if (item && typeof item === 'object' && item.password) {
          const rawUser = item.username || this.desanitizeRtdbKey(k);
          result[rawUser.toLowerCase()] = item.password;
        }
      });
      return result;
    } catch {
      return {};
    }
  }

  public async saveCredential(username: string, password: string): Promise<void> {
    const safeKey = this.sanitizeRtdbKey(username);
    const payload = { username: username.toLowerCase().trim(), password, updatedAt: new Date().toISOString() };
    const credRef = ref(this.db, `kredensial/${safeKey}`);
    try {
      await set(credRef, payload);
    } catch (err) {
      console.warn('[Firebase] set /kredensial error, fallback REST:', err);
      await fetch(
        `${TI_SENANG_FIREBASE_CONFIG.databaseURL}/kredensial/${safeKey}.json?key=${TI_SENANG_FIREBASE_CONFIG.apiKey}`,
        {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload),
        }
      );
    }
  }

  public async saveCredentials(creds: Record<string, string>): Promise<void> {
    const map: Record<string, { username: string; password: string; updatedAt: string }> = {};
    const now = new Date().toISOString();
    Object.keys(creds).forEach((rawUser) => {
      const safeKey = this.sanitizeRtdbKey(rawUser);
      map[safeKey] = {
        username: rawUser.toLowerCase().trim(),
        password: creds[rawUser],
        updatedAt: now,
      };
    });
    const credsRef = ref(this.db, 'kredensial');
    try {
      await set(credsRef, map);
    } catch {
      await fetch(
        `${TI_SENANG_FIREBASE_CONFIG.databaseURL}/kredensial.json?key=${TI_SENANG_FIREBASE_CONFIG.apiKey}`,
        {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(map),
        }
      );
    }
  }

  public async deleteCredential(username: string): Promise<void> {
    const safeKey = this.sanitizeRtdbKey(username);
    const credRef = ref(this.db, `kredensial/${safeKey}`);
    try {
      await remove(credRef);
    } catch {
      await fetch(
        `${TI_SENANG_FIREBASE_CONFIG.databaseURL}/kredensial/${safeKey}.json?key=${TI_SENANG_FIREBASE_CONFIG.apiKey}`,
        { method: 'DELETE' }
      );
    }
  }
}

export const firebaseRealtime = new FirebaseRealtimeService();

