import * as XLSX from 'xlsx';
import { AsesmenAwalInput, Student, User } from '../types';
import { ExportAsesmenPdfParams, ExportAsesmenAkhirPdfParams, ExportRefleksiPdfParams } from './pdfExport';

/**
 * Export Asesmen Awal Diagnostik ke format Excel (.xlsx)
 */
export function exportAsesmenToExcel(params: ExportAsesmenPdfParams): void {
  const { className, subjectName, teacherName, assessmentData } = params;

  // Header Info
  const headerData = [
    ['TI SENANG — LAPORAN ASESMEN AWAL DIAGNOSTIK MIPA'],
    ['Mata Pelajaran', subjectName],
    ['Kelas', className],
    ['Guru Pengampu', teacherName],
    ['Tanggal Unduh', new Date().toLocaleDateString('id-ID')],
    [], // Baris kosong pemisah
    ['No', 'Nama Murid', 'Nilai Asesmen Awal', 'Kesiapan Belajar', 'Catatan Guru'],
  ];

  // Baris Data Siswa
  const rows = assessmentData.map((row, idx) => [
    idx + 1,
    (row.studentName || 'Murid').replace(/\s*\([^)]*\)/g, '').trim(),
    row.diagnosticScore,
    row.readinessLevel || (row.diagnosticScore >= 85 ? 'Siap Mandiri' : row.diagnosticScore >= 70 ? 'Berkembang' : 'Perlu Pendampingan'),
    row.notes || 'Asesmen awal murid terdata di aplikasi.',
  ]);

  const worksheet = XLSX.utils.aoa_to_sheet([...headerData, ...rows]);

  // Set column widths
  worksheet['!cols'] = [
    { wch: 6 },
    { wch: 28 },
    { wch: 20 },
    { wch: 22 },
    { wch: 36 },
  ];

  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, 'Asesmen Awal');

  const fileName = `Asesmen_Awal_${className}_${subjectName.replace(/\s+/g, '_')}.xlsx`;
  XLSX.writeFile(workbook, fileName);
}

/**
 * Export Asesmen Akhir Sumatif ke format Excel (.xlsx)
 */
export function exportAsesmenAkhirToExcel(params: ExportAsesmenAkhirPdfParams): void {
  const { className, subjectName, teacherName, kktpTarget = 75, records } = params;

  const headerData = [
    ['TI SENANG — LAPORAN ASESMEN SUMATIF AKHIR MIPA'],
    ['Mata Pelajaran', subjectName],
    ['Kelas', className],
    ['Guru Pengampu', teacherName],
    ['Kriteria Ketuntasan (KKTP)', `≥ ${kktpTarget}`],
    ['Tanggal Unduh', new Date().toLocaleDateString('id-ID')],
    [],
    ['No', 'Nama Murid', 'Nilai Akhir', 'Ketuntasan KKTP', 'Predikat', 'Capaian TP (%)', 'Catatan Guru'],
  ];

  const rows = records.map((row, idx) => [
    idx + 1,
    row.studentName || 'Murid',
    row.score,
    row.kktpStatus,
    row.predikat,
    row.tpMasteryPercentage,
    row.catatan || '-',
  ]);

  const worksheet = XLSX.utils.aoa_to_sheet([...headerData, ...rows]);

  worksheet['!cols'] = [
    { wch: 6 },
    { wch: 30 },
    { wch: 14 },
    { wch: 18 },
    { wch: 20 },
    { wch: 16 },
    { wch: 35 },
  ];

  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, 'Asesmen Akhir');

  const fileName = `Asesmen_Akhir_${className}_${subjectName.replace(/\s+/g, '_')}.xlsx`;
  XLSX.writeFile(workbook, fileName);
}

/**
 * Export Refleksi & Penilaian Diri Murid ke format Excel (.xlsx)
 */
export function exportRefleksiToExcel(params: ExportRefleksiPdfParams): void {
  const {
    studentName,
    className,
    subjectName,
    teacherName,
    missionTitle,
    submittedAt,
    selfAssessment = {
      kemandirian: 4,
      pemahamanKonsep: 4,
      keterampilanAnalisis: 4,
      sikapReflektif: 4,
      totalScorePercentage: 90,
      komitmen: '',
    },
    reflectionAnswers = {},
  } = params;

  const data = [
    ['TI SENANG — LAPORAN REFLEKSI & PENILAIAN DIRI MURID'],
    ['Nama Murid', studentName],
    ['Kelas', className],
    ['Mata Pelajaran', subjectName],
    ['Guru Pengampu', teacherName],
    ['Misi Terkait', missionTitle],
    ['Waktu Pengiriman', new Date(submittedAt || Date.now()).toLocaleString('id-ID')],
    [],
    ['A. PENILAIAN DIRI SENDIRI (SELF-ASSESSMENT)'],
    ['Aspek Penilaian', 'Skor (1-4)', 'Deskripsi'],
    ['Kemandirian & Keaktifan Belajar', selfAssessment.kemandirian || 4, 'Skala 1 - 4'],
    ['Pemahaman Konsep & Penalaran Ilmiah', selfAssessment.pemahamanKonsep || 4, 'Skala 1 - 4'],
    ['Keterampilan Analisis Data & Eksperimen', selfAssessment.keterampilanAnalisis || 4, 'Skala 1 - 4'],
    ['Sikap Kritis, Teliti & Bertanggung Jawab', selfAssessment.sikapReflektif || 4, 'Skala 1 - 4'],
    ['Total Capaian Penilaian Diri', `${selfAssessment.totalScorePercentage || 90}%`],
    ['Komitmen Diri', selfAssessment.komitmen || '-'],
    [],
    ['B. REFLEKSI PEMBELAJARAN'],
    ['Pertanyaan Reflektif', 'Jawaban Murid'],
    [
      '1. Konsep sains yang paling dipahami',
      reflectionAnswers.pemahaman || 'Murid telah memahami konsep materi dengan baik.',
    ],
    [
      '2. Tantangan/kesulitan yang dihadapi & solusinya',
      reflectionAnswers.tantangan || 'Tantangan terselesaikan melalui eksplorasi dan bimbingan guru.',
    ],
    [
      '3. Hal menarik dalam pembelajaran',
      reflectionAnswers.halMenarik || 'Eksperimen sensor dan simulasi mempermudah pemahaman.',
    ],
    [
      '4. Rencana perbaikan untuk topik berikutnya',
      reflectionAnswers.rencanaPerbaikan || 'Terus berlatih dan memperbanyak eksplorasi konsep.',
    ],
  ];

  const worksheet = XLSX.utils.aoa_to_sheet(data);
  worksheet['!cols'] = [{ wch: 45 }, { wch: 60 }, { wch: 20 }];

  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, 'Refleksi Diri');

  const fileName = `Refleksi_${studentName.replace(/\s+/g, '_')}_${className}.xlsx`;
  XLSX.writeFile(workbook, fileName);
}
