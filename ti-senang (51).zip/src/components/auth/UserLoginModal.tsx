import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { Modal } from '../common/Modal';
import {
  BookOpen,
  GraduationCap,
  AlertCircle,
  Eye,
  EyeOff,
} from 'lucide-react';
import { storage } from '../../services/storage';
import { playPersonalAudioGreeting } from '../../services/audioGreeting';

interface UserLoginModalProps {
  isOpen: boolean;
  onClose: () => void;
  defaultRole?: 'guru' | 'murid';
  onSuccess: () => void;
}

export const UserLoginModal: React.FC<UserLoginModalProps> = ({
  isOpen,
  onClose,
  defaultRole = 'murid',
  onSuccess,
}) => {
  const { login } = useAuth();
  const [role, setRole] = useState<'guru' | 'murid'>(defaultRole);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    if (defaultRole) {
      setRole(defaultRole);
      setUsername('');
      setPassword('');
      setShowPassword(false);
      setError(null);
    }
  }, [defaultRole, isOpen]);

  const handleRoleChange = (newRole: 'guru' | 'murid') => {
    setRole(newRole);
    setError(null);
    setUsername('');
    setPassword('');
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setIsSubmitting(true);

    try {
      const res = login(username, password, role);
      if (res.success) {
        const user = storage.getUsers().find((u) => u.username === username);
        if (user) {
          playPersonalAudioGreeting(user);
        }
        onSuccess();
        onClose();
      } else {
        setError(res.error || 'Login gagal. Periksa username dan password.');
      }
    } catch {
      setError('Terjadi kesalahan saat masuk.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const isMurid = role === 'murid';

  const handleQuickFill = (u: string, p: string, r: 'guru' | 'murid') => {
    setRole(r);
    setUsername(u);
    setPassword(p);
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      maxWidth="sm"
    >
      {/* Role Tabs */}
      <div className="flex rounded-xl bg-slate-100 p-1 mb-4 border border-slate-200">
        <button
          type="button"
          onClick={() => handleRoleChange('murid')}
          className={`flex-1 py-2.5 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer min-h-[44px] ${
            isMurid
              ? 'bg-white text-pink-600 shadow-xs'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <GraduationCap className="w-4 h-4" />
          <span>Murid</span>
        </button>
        <button
          type="button"
          onClick={() => handleRoleChange('guru')}
          className={`flex-1 py-2.5 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer min-h-[44px] ${
            !isMurid
              ? 'bg-white text-blue-700 shadow-xs'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <BookOpen className="w-4 h-4" />
          <span>Guru</span>
        </button>
      </div>

      <form onSubmit={handleSubmit} className="space-y-3.5">
        {error && (
          <div className="p-3 rounded-xl bg-red-50 border border-red-200 text-red-700 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        <div>
          <label className="block text-xs font-bold text-slate-800 mb-1">
            Username
          </label>
          <input
            id="user-username-input"
            type="text"
            required
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            placeholder={isMurid ? 'contoh: aisyah' : 'contoh: budi'}
            className="w-full h-11 px-3.5 rounded-xl border border-slate-300 focus:border-blue-600 focus:ring-2 focus:ring-blue-200 text-base font-medium outline-hidden transition-all bg-white text-slate-900 shadow-xs"
          />
        </div>

        <div>
          <label className="block text-xs font-bold text-slate-800 mb-1">
            Password
          </label>
          <div className="relative">
            <input
              id="user-password-input"
              type={showPassword ? 'text' : 'password'}
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Masukkan password"
              className="w-full h-11 pl-3.5 pr-11 rounded-xl border border-slate-300 focus:border-blue-600 focus:ring-2 focus:ring-blue-200 text-base font-medium outline-hidden transition-all bg-white text-slate-900 shadow-xs"
            />
            <button
              type="button"
              id="btn-toggle-user-password"
              onClick={() => setShowPassword(!showPassword)}
              className="absolute right-2 top-2 p-2 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors cursor-pointer"
              title={showPassword ? 'Sembunyikan' : 'Lihat'}
              aria-label={showPassword ? 'Sembunyikan' : 'Lihat'}
            >
              {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
            </button>
          </div>
        </div>

        <div className="pt-2">
          <button
            id="btn-user-submit"
            type="submit"
            disabled={isSubmitting}
            className={`w-full h-11 rounded-xl text-white text-sm font-bold shadow-md hover:shadow-lg transition-all flex items-center justify-center gap-2 active:scale-95 disabled:opacity-50 cursor-pointer ${
              isMurid
                ? 'bg-gradient-to-r from-pink-600 to-pink-500 hover:from-pink-700 hover:to-pink-600'
                : 'bg-gradient-to-r from-blue-700 to-blue-600 hover:from-blue-800 hover:to-blue-700'
            }`}
          >
            <span>{isSubmitting ? 'Memproses...' : 'Masuk'}</span>
          </button>
        </div>

        {/* Demo Fast Account Quick Pick */}
        <div className="pt-2 border-t border-slate-200/80 flex items-center justify-center gap-2 text-xs">
          <span className="text-slate-400 text-[11px]">Akun Cepat:</span>
          {isMurid ? (
            <button
              type="button"
              onClick={() => handleQuickFill('aisyah', '123456', 'murid')}
              className="text-pink-600 hover:text-pink-700 font-semibold underline text-[11px] cursor-pointer"
            >
              aisyah (Murid)
            </button>
          ) : (
            <button
              type="button"
              onClick={() => handleQuickFill('budi', '123456', 'guru')}
              className="text-blue-600 hover:text-blue-700 font-semibold underline text-[11px] cursor-pointer"
            >
              budi (Guru)
            </button>
          )}
        </div>
      </form>
    </Modal>
  );
};
