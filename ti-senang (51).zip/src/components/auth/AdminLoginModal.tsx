import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { Modal } from '../common/Modal';
import { Settings, Lock, AlertCircle, Sparkles, Eye, EyeOff } from 'lucide-react';

interface AdminLoginModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
}

export const AdminLoginModal: React.FC<AdminLoginModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
}) => {
  const { login } = useAuth();
  const [username, setUsername] = useState('inov');
  const [password, setPassword] = useState('ttchm289');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setIsSubmitting(true);

    try {
      const result = login(username, password, 'admin');
      if (result.success) {
        onSuccess();
        onClose();
      } else {
        setError(result.error || 'Autentikasi admin gagal.');
      }
    } catch {
      setError('Terjadi kesalahan saat masuk.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleFillPrototype = () => {
    setUsername('inov');
    setPassword('ttchm289');
    setError(null);
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="Login Administrator"
      subtitle="Akses khusus Admin Center (Pengelolaan Akun & Kelas)"
      maxWidth="sm"
    >
      <form onSubmit={handleSubmit} className="space-y-4">
        {/* Important note from spec */}
        <div className="p-3 rounded-xl bg-amber-100/90 border border-amber-300/80 text-amber-950 text-xs flex items-start gap-2 shadow-xs">
          <Settings className="w-4 h-4 text-amber-800 shrink-0 mt-0.5" />
          <div>
            <p className="font-bold">Akses Terbatas: Admin Center</p>
            <p className="text-[11px] text-amber-900 font-medium">
              Admin hanya mengelola Akun Guru, Akun Murid, dan Daftar Kelas.
            </p>
          </div>
        </div>

        {error && (
          <div className="p-3 rounded-xl bg-red-50 border border-red-200 text-red-700 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        <div>
          <label className="block text-xs font-bold text-slate-900 uppercase tracking-wider mb-1.5">
            Username
          </label>
          <input
            id="admin-username-input"
            type="text"
            required
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            placeholder="Username admin"
            className="w-full h-11 px-3.5 rounded-xl border border-white/80 focus:border-amber-600 focus:ring-2 focus:ring-amber-300 text-sm font-medium outline-hidden transition-all bg-white/95 text-slate-900 shadow-xs"
          />
        </div>

        <div>
          <label className="block text-xs font-bold text-slate-900 uppercase tracking-wider mb-1.5">
            Password
          </label>
          <div className="relative">
            <input
              id="admin-password-input"
              type={showPassword ? 'text' : 'password'}
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
              className="w-full h-11 pl-3.5 pr-11 rounded-xl border border-white/80 focus:border-amber-600 focus:ring-2 focus:ring-amber-300 text-sm font-medium outline-hidden transition-all bg-white/95 text-slate-900 shadow-xs"
            />
            <button
              type="button"
              id="btn-toggle-admin-password"
              onClick={() => setShowPassword(!showPassword)}
              className="absolute right-2.5 top-2.5 p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors cursor-pointer"
              title={showPassword ? 'Sembunyikan password' : 'Lihat password'}
              aria-label={showPassword ? 'Sembunyikan password' : 'Lihat password'}
            >
              {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
            </button>
          </div>
        </div>

        <div className="pt-2">
          <button
            id="btn-admin-submit"
            type="submit"
            disabled={isSubmitting}
            className="w-full h-11 rounded-xl bg-gradient-to-r from-amber-600 to-amber-500 hover:from-amber-700 hover:to-amber-600 text-white text-sm font-bold shadow-md hover:shadow-lg transition-all flex items-center justify-center gap-2 active:scale-98 disabled:opacity-50 cursor-pointer"
          >
            <Settings className="w-4 h-4" />
            <span>Masuk ke Admin Center</span>
          </button>
        </div>

        <div className="pt-2 border-t border-white/40 flex items-center justify-between">
          <span className="text-[11px] text-slate-900 font-semibold">Akun prototype: inov / ttchm289</span>
          <button
            type="button"
            onClick={handleFillPrototype}
            className="inline-flex items-center gap-1 text-[11px] font-bold text-amber-950 bg-white/60 hover:bg-white/90 px-2 py-1 rounded-lg border border-white/70 shadow-xs transition-colors cursor-pointer"
          >
            <Sparkles className="w-3 h-3 text-amber-700" />
            Isi Otomatis
          </button>
        </div>
      </form>
    </Modal>
  );
};
