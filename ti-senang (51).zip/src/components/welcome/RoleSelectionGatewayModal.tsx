/**
 * TI SENANG - Futuristic Welcome Gateway
 * Halaman / Modal Khusus "Pilih Peran Masuk"
 * Menghubungkan pengguna ke ekosistem pendidikan digital masa depan TI SENANG.
 */

import React, { useState, useEffect } from 'react';
import {
  X,
  Sparkles,
  ArrowRight,
  Volume2,
  VolumeX,
  Compass,
  GraduationCap,
  BookOpen,
} from 'lucide-react';
import logoTiSenang from '../../assets/images/logo_ti_senang.png';
import mascotMurid from '../../assets/images/students_learning_group_1789112167834.jpg';
import mascotGuru from '../../assets/images/teachers_meeting_group_1789112749350.jpg';
import { isAudioGreetingEnabled, setAudioGreetingEnabled } from '../../services/audioGreeting';

interface RoleSelectionGatewayModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectRole: (role: 'guru' | 'murid') => void;
  onQuickDemoLogin?: (username: string, pass: string, role: 'guru' | 'murid') => void;
}

export const RoleSelectionGatewayModal: React.FC<RoleSelectionGatewayModalProps> = ({
  isOpen,
  onClose,
  onSelectRole,
}) => {
  const [audioActive, setAudioActive] = useState(() => isAudioGreetingEnabled());

  // Handle ESC key to close
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const toggleAudio = () => {
    const next = !audioActive;
    setAudioActive(next);
    setAudioGreetingEnabled(next);
  };

  return (
    <div
      id="modal-pilih-peran-gateway"
      role="dialog"
      aria-modal="true"
      aria-labelledby="gateway-title"
      className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 overflow-hidden backdrop-blur-xl bg-slate-950/85 transition-opacity duration-300 select-none"
    >
      {/* Container Gateway Futuristik Kompak (Tanpa Scroll Vertikal) */}
      <div className="relative w-full max-w-3xl my-auto rounded-2xl sm:rounded-3xl overflow-hidden bg-gradient-to-b from-[#060b1c] via-[#091129] to-[#040815] border border-blue-500/30 shadow-[0_0_60px_rgba(30,58,138,0.35),0_15px_40px_rgba(0,0,0,0.85)] flex flex-col items-center max-h-[96vh]">
        
        {/* ================= BACKGROUND FUTURISTIK & AMBIENT GLOW ================= */}
        {/* Latar Grid Digital Halus */}
        <div
          className="absolute inset-0 pointer-events-none opacity-15"
          style={{
            backgroundImage: `radial-gradient(circle at 1px 1px, rgba(56, 189, 248, 0.45) 1px, transparent 0)`,
            backgroundSize: '24px 24px',
          }}
        />

        {/* Ambient Radial Lights */}
        <div className="pointer-events-none absolute -top-32 left-1/4 w-80 h-80 bg-blue-600/20 rounded-full blur-3xl animate-pulse" />
        <div className="pointer-events-none absolute -bottom-32 right-1/4 w-80 h-80 bg-purple-600/20 rounded-full blur-3xl" />
        <div className="pointer-events-none absolute top-1/2 -left-20 w-52 h-52 bg-pink-600/15 rounded-full blur-3xl" />
        <div className="pointer-events-none absolute top-1/2 -right-20 w-52 h-52 bg-cyan-500/15 rounded-full blur-3xl" />

        {/* Learning Nodes & Floating Sparkles */}
        <div className="pointer-events-none absolute top-8 left-8 w-2 h-2 rounded-full bg-cyan-400 shadow-[0_0_8px_#38bdf8] opacity-70 animate-ping" />
        <div className="pointer-events-none absolute bottom-12 right-10 w-2 h-2 rounded-full bg-pink-400 shadow-[0_0_8px_#f472b6] opacity-70 animate-pulse" />

        {/* ================= TOP CONTROLS (AUDIO & CLOSE BUTTON) ================= */}
        <div className="w-full flex items-center justify-between px-3 sm:px-5 pt-2.5 sm:pt-3 z-20 shrink-0">
          {/* Audio Greeting Toggle Indicator */}
          <button
            type="button"
            onClick={toggleAudio}
            id="btn-gateway-audio-toggle"
            title={audioActive ? 'Audio sapaan aktif (Klik untuk senyap)' : 'Audio sapaan senyap (Klik untuk aktifkan)'}
            className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[10px] font-medium transition-all bg-slate-900/80 hover:bg-slate-800 border border-slate-700/70 text-slate-300 hover:text-white cursor-pointer shadow-xs"
          >
            {audioActive ? (
              <>
                <Volume2 className="w-3 h-3 text-cyan-400 animate-pulse-subtle" />
                <span className="hidden sm:inline">Audio Sapaan:</span>
                <span className="text-cyan-300 font-bold">Aktif</span>
              </>
            ) : (
              <>
                <VolumeX className="w-3 h-3 text-slate-400" />
                <span className="hidden sm:inline">Audio Sapaan:</span>
                <span className="text-slate-400 font-medium">Senyap</span>
              </>
            )}
          </button>

          {/* Minimalist Close X Button */}
          <button
            type="button"
            onClick={onClose}
            id="btn-close-role-gateway"
            aria-label="Tutup jendela pemilihan peran"
            className="w-7 h-7 rounded-full flex items-center justify-center text-slate-400 hover:text-white bg-slate-900/80 hover:bg-slate-800 border border-slate-700/60 transition-all cursor-pointer shadow-xs hover:scale-105 active:scale-95"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* ================= BRANDING & JUDUL UTAMA (KOMPAK & TANPA SUBTITLE) ================= */}
        <div className="flex flex-col items-center justify-center text-center px-4 pt-0.5 pb-2 z-10">
          {/* Logo TI SENANG Elegan */}
          <div className="relative mb-1 group">
            <div className="absolute -inset-1 bg-gradient-to-r from-cyan-500/30 via-blue-500/30 to-purple-500/30 rounded-xl blur-sm opacity-70 group-hover:opacity-100 transition duration-300" />
            <div className="relative w-9 h-9 sm:w-10 sm:h-10 rounded-xl bg-white p-0.5 border border-white/80 shadow-md shadow-black/40 flex items-center justify-center overflow-hidden">
              <img
                src={logoTiSenang}
                alt="Logo TI SENANG"
                className="w-full h-full object-contain"
                referrerPolicy="no-referrer"
              />
            </div>
          </div>

          {/* Brand Name */}
          <span className="font-display font-black text-[10px] tracking-widest uppercase text-transparent bg-clip-text bg-gradient-to-r from-cyan-300 via-blue-200 to-indigo-200 drop-shadow-[0_1px_3px_rgba(0,0,0,0.6)]">
            TI SENANG
          </span>

          {/* Judul Utama */}
          <h2
            id="gateway-title"
            className="text-lg sm:text-xl md:text-2xl font-black tracking-tight text-white font-display drop-shadow-[0_2px_6px_rgba(0,0,0,0.8)]"
          >
            Pilih Peran Masuk
          </h2>
        </div>

        {/* ================= DUA KARTU ROLE UTAMA (MURID & GURU) ================= */}
        <div className="w-full px-3 sm:px-6 py-2 z-10">
          <div className="grid grid-cols-2 gap-2.5 sm:gap-4 max-w-xl mx-auto items-stretch">
            
            {/* ----------------- ROLE CARD: MURID ----------------- */}
            <div
              id="card-role-murid"
              role="button"
              tabIndex={0}
              onClick={() => onSelectRole('murid')}
              onKeyDown={(e) => {
                if (e.key === 'Enter' || e.key === ' ') {
                  e.preventDefault();
                  onSelectRole('murid');
                }
              }}
              className="group relative flex flex-col justify-between p-2.5 sm:p-4 rounded-2xl transition-all duration-200 cursor-pointer overflow-hidden border border-pink-500/40 bg-gradient-to-b from-slate-900/95 via-[#181126]/95 to-[#120a1f]/95 shadow-lg hover:border-pink-400 hover:shadow-pink-500/20 active:scale-95"
            >
              {/* Neon Accent Glow Aura */}
              <div className="pointer-events-none absolute -top-8 -right-8 w-28 h-28 bg-pink-500/20 rounded-full blur-xl" />

              {/* Tag Role & Badge */}
              <div className="flex items-center justify-between z-10 mb-1">
                <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded-full text-[9px] font-bold bg-pink-500/20 text-pink-300 border border-pink-500/30">
                  <GraduationCap className="w-2.5 h-2.5 text-pink-300" />
                  <span>Murid</span>
                </span>
                <span className="text-[9px] font-mono font-bold text-pink-400/80 hidden sm:inline">
                  Fase F
                </span>
              </div>

              {/* Ilustrasi Karakter Murid */}
              <div className="relative w-full h-24 sm:h-36 rounded-xl overflow-hidden border border-pink-400/30 bg-slate-950/80 my-1">
                <img
                  src={mascotMurid}
                  alt="Murid"
                  className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-300"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950/70 via-transparent to-transparent pointer-events-none" />
              </div>

              {/* Info Teks Murid & Action */}
              <div className="mt-1 z-10">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm sm:text-base font-black font-display text-white tracking-tight group-hover:text-pink-300 transition-colors">
                    MURID
                  </h3>
                  <div className="w-6 h-6 rounded-lg bg-pink-500/20 border border-pink-400/40 text-pink-300 flex items-center justify-center group-hover:bg-pink-500 group-hover:text-white transition-colors">
                    <ArrowRight className="w-3 h-3" />
                  </div>
                </div>
                <p className="text-[10px] sm:text-xs text-slate-300 font-medium mt-0.5 truncate">
                  Ruang Belajar Murid
                </p>
              </div>
            </div>

            {/* ----------------- ROLE CARD: GURU ----------------- */}
            <div
              id="card-role-guru"
              role="button"
              tabIndex={0}
              onClick={() => onSelectRole('guru')}
              onKeyDown={(e) => {
                if (e.key === 'Enter' || e.key === ' ') {
                  e.preventDefault();
                  onSelectRole('guru');
                }
              }}
              className="group relative flex flex-col justify-between p-2.5 sm:p-4 rounded-2xl transition-all duration-200 cursor-pointer overflow-hidden border border-cyan-500/40 bg-gradient-to-b from-slate-900/95 via-[#0c192d]/95 to-[#071120]/95 shadow-lg hover:border-cyan-400 hover:shadow-cyan-500/20 active:scale-95"
            >
              {/* Neon Accent Glow Aura */}
              <div className="pointer-events-none absolute -top-8 -right-8 w-28 h-28 bg-cyan-500/20 rounded-full blur-xl" />

              {/* Tag Role & Badge */}
              <div className="flex items-center justify-between z-10 mb-1">
                <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded-full text-[9px] font-bold bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                  <Compass className="w-2.5 h-2.5 text-cyan-300" />
                  <span>Guru</span>
                </span>
                <span className="text-[9px] font-mono font-bold text-cyan-400/80 hidden sm:inline">
                  Pengampu
                </span>
              </div>

              {/* Ilustrasi Karakter Guru */}
              <div className="relative w-full h-24 sm:h-36 rounded-xl overflow-hidden border border-cyan-400/30 bg-slate-950/80 my-1">
                <img
                  src={mascotGuru}
                  alt="Guru"
                  className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-300"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950/70 via-transparent to-transparent pointer-events-none" />
              </div>

              {/* Info Teks Guru & Action */}
              <div className="mt-1 z-10">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm sm:text-base font-black font-display text-white tracking-tight group-hover:text-cyan-300 transition-colors">
                    GURU
                  </h3>
                  <div className="w-6 h-6 rounded-lg bg-cyan-500/20 border border-cyan-400/40 text-cyan-300 flex items-center justify-center group-hover:bg-cyan-500 group-hover:text-white transition-colors">
                    <ArrowRight className="w-3 h-3" />
                  </div>
                </div>
                <p className="text-[10px] sm:text-xs text-slate-300 font-medium mt-0.5 truncate">
                  Ruang Manajemen Guru
                </p>
              </div>
            </div>

          </div>
        </div>

      </div>
    </div>
  );
};
