import React, { useState } from 'react';
import {
  FlaskConical,
  Flame,
  ArrowRight,
  ArrowLeft,
  RotateCcw,
  Sparkles,
  Info,
  CheckCircle2,
  ChevronRight,
  TrendingUp,
  Activity,
} from 'lucide-react';

export const MateriKimiaTermokimia: React.FC = () => {
  const [hasStartedReading, setHasStartedReading] = useState(false);
  const [activeSection, setActiveSection] = useState<'A' | 'B' | 'C' | 'D'>('A');

  // Interaktif Section B: Perbandingan Eksoterm vs Endoterm
  const [selectedReactionType, setSelectedReactionType] = useState<'eksoterm' | 'endoterm'>('eksoterm');

  // Interaktif Section C: Kalkulator Kalorimeter Kimia sederahana
  // q = m * c * deltaT, deltaH = -q / n
  const [massaLarutan, setMassaLarutan] = useState<number>(100); // gram
  const [deltaTKimia, setDeltaTKimia] = useState<number>(5); // °C kenaikan
  const [molZat, setMolZat] = useState<number>(0.05); // mol

  const qKimiaJoule = massaLarutan * 4.2 * deltaTKimia;
  const deltaHKJ = -(qKimiaJoule / 1000) / molZat;

  const sections: { id: 'A' | 'B' | 'C' | 'D'; label: string; title: string }[] = [
    { id: 'A', label: 'Bagian A', title: 'Sistem & Lingkungan' },
    { id: 'B', label: 'Bagian B', title: 'Eksoterm & Endoterm' },
    { id: 'C', label: 'Bagian C', title: 'Kalorimeter & Entalpi' },
    { id: 'D', label: 'Bagian D', title: 'Faktor Laju Reaksi' },
  ];

  const handleNextSection = () => {
    if (activeSection === 'A') setActiveSection('B');
    else if (activeSection === 'B') setActiveSection('C');
    else if (activeSection === 'C') setActiveSection('D');
  };

  const handlePrevSection = () => {
    if (activeSection === 'D') setActiveSection('C');
    else if (activeSection === 'C') setActiveSection('B');
    else if (activeSection === 'B') setActiveSection('A');
  };

  return (
    <div className="space-y-4 sm:space-y-6">
      {!hasStartedReading ? (
        <div className="relative overflow-hidden rounded-2xl sm:rounded-3xl bg-gradient-to-br from-emerald-950 via-teal-950 to-slate-950 p-6 sm:p-10 text-white shadow-xl border border-emerald-500/30">
          <div className="absolute -top-12 -right-12 w-64 h-64 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none"></div>
          <div className="absolute -bottom-12 -left-12 w-64 h-64 bg-teal-500/10 rounded-full blur-3xl pointer-events-none"></div>

          <div className="relative z-10 max-w-2xl space-y-4">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-400/20 text-emerald-200 border border-emerald-400/30 text-xs font-bold uppercase tracking-wider">
              <FlaskConical className="w-3.5 h-3.5" />
              <span>Modul Kimia Interaktif Fase F</span>
            </div>

            <h1 className="text-2xl sm:text-4xl font-extrabold tracking-tight text-white leading-tight">
              TERMOKIMIA & ENERGI REAKSI
            </h1>

            <p className="text-sm sm:text-base text-emerald-100 font-medium leading-relaxed">
              Memahami Perubahan Entalpi Reaksi, Sistem & Lingkungan, serta Dinamika Eksoterm dan Endoterm
            </p>

            <div className="flex flex-wrap gap-2 pt-2">
              <span className="px-3 py-1 rounded-lg bg-white/10 text-xs font-semibold text-emerald-200 border border-white/10">
                🧪 Sistem & Lingkungan
              </span>
              <span className="px-3 py-1 rounded-lg bg-white/10 text-xs font-semibold text-emerald-200 border border-white/10">
                🔥 Reaksi Eksoterm & Endoterm (ΔH)
              </span>
              <span className="px-3 py-1 rounded-lg bg-white/10 text-xs font-semibold text-emerald-200 border border-white/10">
                ⚡ Kalorimetri Larutan
              </span>
            </div>

            <div className="pt-4">
              <button
                type="button"
                onClick={() => setHasStartedReading(true)}
                className="px-6 py-3 rounded-xl sm:rounded-2xl bg-emerald-400 hover:bg-emerald-300 text-slate-950 font-black text-sm sm:text-base transition-all shadow-lg shadow-emerald-400/25 active:scale-95 flex items-center gap-2 cursor-pointer"
              >
                <span>🚀 MULAI BELAJAR KIMIA</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      ) : (
        <div className="space-y-4 sm:space-y-6 animate-in fade-in">
          {/* Header Navigasi Bagian Materi */}
          <div className="bg-slate-900/90 rounded-2xl p-3 sm:p-4 border border-slate-700/80 shadow-md flex flex-wrap items-center justify-between gap-2">
            <div className="flex flex-wrap items-center gap-1.5 sm:gap-2">
              {sections.map((sec) => (
                <button
                  key={sec.id}
                  type="button"
                  onClick={() => setActiveSection(sec.id)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                    activeSection === sec.id
                      ? 'bg-emerald-400 text-slate-950 shadow-md font-extrabold'
                      : 'text-slate-300 hover:text-white hover:bg-slate-800'
                  }`}
                >
                  {sec.title}
                </button>
              ))}
            </div>

            <button
              type="button"
              onClick={() => setHasStartedReading(false)}
              className="text-xs text-slate-400 hover:text-white flex items-center gap-1 px-2.5 py-1 rounded-lg hover:bg-slate-800 transition-colors"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Cover</span>
            </button>
          </div>

          {/* BAGIAN A: SISTEM & LINGKUNGAN */}
          {activeSection === 'A' && (
            <div className="bg-slate-900/90 rounded-2xl sm:rounded-3xl p-5 sm:p-7 border border-slate-700/80 shadow-md space-y-5">
              <div className="border-b border-slate-800 pb-3 flex items-center justify-between">
                <div>
                  <span className="text-xs font-bold text-emerald-400 uppercase tracking-wider">Bagian A</span>
                  <h2 className="text-lg sm:text-xl font-bold text-white">Sistem dan Lingkungan Termokimia</h2>
                </div>
                <div className="w-9 h-9 rounded-xl bg-emerald-500/20 text-emerald-300 flex items-center justify-center">
                  <FlaskConical className="w-5 h-5" />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs sm:text-sm text-slate-300 leading-relaxed">
                <div className="p-4 rounded-xl bg-slate-800/80 border border-slate-700/70 space-y-2">
                  <h3 className="font-bold text-emerald-300 flex items-center gap-2 text-sm">
                    <span>🧪 Sistem</span>
                  </h3>
                  <p>
                    Bagian dari alam semesta yang menjadi <strong>pusat perhatian pengamatan atau penelitian</strong> kimiawi,
                    misalnya campuran zat pereaksi di dalam tabung reaksi.
                  </p>
                </div>

                <div className="p-4 rounded-xl bg-slate-800/80 border border-slate-700/70 space-y-2">
                  <h3 className="font-bold text-teal-300 flex items-center gap-2 text-sm">
                    <span>🌐 Lingkungan</span>
                  </h3>
                  <p>
                    Segala sesuatu di luar sistem yang <strong>dapat mempengaruhi atau berinteraksi</strong> dengan sistem,
                    seperti dinding tabung reaksi, udara di laboratorium, dan termometer.
                  </p>
                </div>
              </div>

              {/* Tiga Jenis Sistem */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs sm:text-sm pt-2">
                <div className="p-3.5 rounded-xl bg-slate-800/60 border border-slate-700 space-y-1.5">
                  <h4 className="font-bold text-white text-xs">1. Sistem Terbuka</h4>
                  <p className="text-slate-300 text-xs">Terjadi pertukaran <strong>materi</strong> dan <strong>energi</strong> dengan lingkungan.</p>
                  <p className="text-[10px] text-slate-400">Contoh: Kopi panas di gelas terbuka.</p>
                </div>
                <div className="p-3.5 rounded-xl bg-slate-800/60 border border-slate-700 space-y-1.5">
                  <h4 className="font-bold text-white text-xs">2. Sistem Tertutup</h4>
                  <p className="text-slate-300 text-xs">Hanya terjadi pertukaran <strong>energi</strong>, tanpa pertukaran materi.</p>
                  <p className="text-[10px] text-slate-400">Contoh: Minuman kaleng tertutup rapat.</p>
                </div>
                <div className="p-3.5 rounded-xl bg-slate-800/60 border border-slate-700 space-y-1.5">
                  <h4 className="font-bold text-white text-xs">3. Sistem Terisolasi</h4>
                  <p className="text-slate-300 text-xs"><strong>Tidak terjadi</strong> pertukaran materi maupun energi dengan lingkungan.</p>
                  <p className="text-[10px] text-slate-400">Contoh: Termos air panas ideal / Kalorimeter bom.</p>
                </div>
              </div>
            </div>
          )}

          {/* BAGIAN B: EKSOTERM & ENDOTERM */}
          {activeSection === 'B' && (
            <div className="bg-slate-900/90 rounded-2xl sm:rounded-3xl p-5 sm:p-7 border border-slate-700/80 shadow-md space-y-5">
              <div className="border-b border-slate-800 pb-3 flex items-center justify-between">
                <div>
                  <span className="text-xs font-bold text-emerald-400 uppercase tracking-wider">Bagian B</span>
                  <h2 className="text-lg sm:text-xl font-bold text-white">Reaksi Eksoterm dan Endoterm</h2>
                </div>
                <div className="w-9 h-9 rounded-xl bg-emerald-500/20 text-emerald-300 flex items-center justify-center">
                  <Flame className="w-5 h-5" />
                </div>
              </div>

              {/* Selector Tab */}
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => setSelectedReactionType('eksoterm')}
                  className={`flex-1 py-2 px-3 rounded-xl text-xs font-bold transition-all ${
                    selectedReactionType === 'eksoterm'
                      ? 'bg-red-500 text-white shadow-md'
                      : 'bg-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  🔥 Reaksi Eksoterm (ΔH &lt; 0)
                </button>
                <button
                  type="button"
                  onClick={() => setSelectedReactionType('endoterm')}
                  className={`flex-1 py-2 px-3 rounded-xl text-xs font-bold transition-all ${
                    selectedReactionType === 'endoterm'
                      ? 'bg-blue-500 text-white shadow-md'
                      : 'bg-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  ❄️ Reaksi Endoterm (ΔH &gt; 0)
                </button>
              </div>

              {selectedReactionType === 'eksoterm' ? (
                <div className="p-4 sm:p-5 rounded-2xl bg-red-950/40 border border-red-500/40 space-y-3">
                  <h3 className="font-bold text-red-300 text-sm">Ciri-Ciri Reaksi Eksoterm:</h3>
                  <ul className="text-xs sm:text-sm text-slate-300 space-y-1.5 list-disc list-inside">
                    <li>Sistem kimia <strong>melepaskan kalor</strong> ke lingkungan.</li>
                    <li>Suhu lingkungan mengalami <strong>kenaikan</strong> (wadah terasa panas).</li>
                    <li>Entalpi produk lebih kecil dari entalpi reaktan (H_produk &lt; H_reaktan).</li>
                    <li>Perubahan entalpi bertanda negatif: <strong className="text-red-300 font-mono">ΔH = - (negatif)</strong>.</li>
                    <li>Contoh: Reaksi pembakaran gas metana (CH₄), netralisasi asam-basa kuat.</li>
                  </ul>
                </div>
              ) : (
                <div className="p-4 sm:p-5 rounded-2xl bg-blue-950/40 border border-blue-500/40 space-y-3">
                  <h3 className="font-bold text-blue-300 text-sm">Ciri-Ciri Reaksi Endoterm:</h3>
                  <ul className="text-xs sm:text-sm text-slate-300 space-y-1.5 list-disc list-inside">
                    <li>Sistem kimia <strong>menyerap kalor</strong> dari lingkungan.</li>
                    <li>Suhu lingkungan mengalami <strong>penurunan</strong> (wadah terasa dingin).</li>
                    <li>Entalpi produk lebih besar dari entalpi reaktan (H_produk &gt; H_reaktan).</li>
                    <li>Perubahan entalpi bertanda positif: <strong className="text-blue-300 font-mono">ΔH = + (positif)</strong>.</li>
                    <li>Contoh: Pelarutan pupuk urea dalam air, fotosintesis tumbuhan, es mencair.</li>
                  </ul>
                </div>
              )}
            </div>
          )}

          {/* BAGIAN C: KALORIMETER & ENTALPI */}
          {activeSection === 'C' && (
            <div className="bg-slate-900/90 rounded-2xl sm:rounded-3xl p-5 sm:p-7 border border-slate-700/80 shadow-md space-y-5">
              <div className="border-b border-slate-800 pb-3 flex items-center justify-between">
                <div>
                  <span className="text-xs font-bold text-emerald-400 uppercase tracking-wider">Bagian C</span>
                  <h2 className="text-lg sm:text-xl font-bold text-white">Kalorimetri dan Perhitungan Entalpi</h2>
                </div>
                <div className="w-9 h-9 rounded-xl bg-emerald-500/20 text-emerald-300 flex items-center justify-center">
                  <Activity className="w-5 h-5" />
                </div>
              </div>

              <div className="p-4 rounded-xl bg-gradient-to-r from-teal-950 to-emerald-950 border border-emerald-500/30 text-xs sm:text-sm text-slate-300 space-y-2">
                <p>
                  Prinsip kalorimetri menyatakan bahwa kalor yang diserap oleh larutan sebanding dengan massa larutan dan kenaikan suhu:
                </p>
                <div className="p-2.5 bg-black/40 rounded-xl font-mono text-center text-emerald-300 text-sm">
                  q_reaksi = -(m_larutan · c_larutan · ΔT)
                </div>
                <p className="text-[11px] text-slate-400 text-center">
                  Entalpi molar: ΔH = q_reaksi / n (kJ/mol)
                </p>
              </div>

              {/* Kalkulator Kalorimetri */}
              <div className="p-4 rounded-xl bg-slate-800/80 border border-slate-700 space-y-3">
                <h4 className="text-xs font-bold text-emerald-300 uppercase tracking-wide">
                  🧪 Simulasi Perhitungan Kalorimeter Sederhana
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                  <div>
                    <label className="text-slate-400 block mb-1">Massa Larutan: {massaLarutan} gram</label>
                    <input
                      type="range"
                      min={50}
                      max={250}
                      step={10}
                      value={massaLarutan}
                      onChange={(e) => setMassaLarutan(parseFloat(e.target.value))}
                      className="w-full accent-emerald-400"
                    />
                  </div>
                  <div>
                    <label className="text-slate-400 block mb-1">Kenaikan Suhu (ΔT): {deltaTKimia} °C</label>
                    <input
                      type="range"
                      min={1}
                      max={20}
                      step={1}
                      value={deltaTKimia}
                      onChange={(e) => setDeltaTKimia(parseFloat(e.target.value))}
                      className="w-full accent-emerald-400"
                    />
                  </div>
                  <div>
                    <label className="text-slate-400 block mb-1">Jumlah Mol Zat: {molZat} mol</label>
                    <input
                      type="range"
                      min={0.01}
                      max={0.2}
                      step={0.01}
                      value={molZat}
                      onChange={(e) => setMolZat(parseFloat(e.target.value))}
                      className="w-full accent-emerald-400"
                    />
                  </div>
                </div>

                <div className="p-3 rounded-lg bg-emerald-950/60 border border-emerald-500/40 text-center space-y-1">
                  <span className="text-xs text-slate-300 block">Perubahan Entalpi Reaksi (ΔH):</span>
                  <span className="text-xl font-mono font-bold text-emerald-300">
                    ΔH = {deltaHKJ.toFixed(2)} kJ/mol
                  </span>
                  <span className="text-[11px] text-emerald-400 block">
                    (Reaksi Eksoterm melepaskan kalor q = {qKimiaJoule.toLocaleString('id-ID')} Joule)
                  </span>
                </div>
              </div>
            </div>
          )}

          {/* BAGIAN D: FAKTOR LAJU REAKSI */}
          {activeSection === 'D' && (
            <div className="bg-slate-900/90 rounded-2xl sm:rounded-3xl p-5 sm:p-7 border border-slate-700/80 shadow-md space-y-5">
              <div className="border-b border-slate-800 pb-3 flex items-center justify-between">
                <div>
                  <span className="text-xs font-bold text-emerald-400 uppercase tracking-wider">Bagian D</span>
                  <h2 className="text-lg sm:text-xl font-bold text-white">4 Faktor Penentu Laju Reaksi</h2>
                </div>
                <div className="w-9 h-9 rounded-xl bg-emerald-500/20 text-emerald-300 flex items-center justify-center">
                  <TrendingUp className="w-5 h-5" />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs sm:text-sm">
                <div className="p-4 rounded-xl bg-slate-800/80 border border-slate-700/70 space-y-1.5">
                  <h3 className="font-bold text-emerald-300">1. Suhu / Temperatur</h3>
                  <p className="text-slate-300 text-xs leading-relaxed">
                    Kenaikan suhu meningkatkan energi kinetik partikel sehingga frekuensi tumbukan efektif yang melampaui energi aktivasi bertambah pesat.
                  </p>
                </div>
                <div className="p-4 rounded-xl bg-slate-800/80 border border-slate-700/70 space-y-1.5">
                  <h3 className="font-bold text-emerald-300">2. Konsentrasi Pereaksi</h3>
                  <p className="text-slate-300 text-xs leading-relaxed">
                    Semakin tinggi konsentrasi pereaksi, semakin banyak partikel per satuan volume, sehingga kemungkinan terjadinya tumbukan antarpartikel semakin besar.
                  </p>
                </div>
                <div className="p-4 rounded-xl bg-slate-800/80 border border-slate-700/70 space-y-1.5">
                  <h3 className="font-bold text-emerald-300">3. Luas Permukaan Sentuh</h3>
                  <p className="text-slate-300 text-xs leading-relaxed">
                    Semakin halus ukuran partikel padatan, semakin besar bidang sentuh yang terbuka untuk bertumbukan dengan partikel pereaksi lainnya.
                  </p>
                </div>
                <div className="p-4 rounded-xl bg-slate-800/80 border border-slate-700/70 space-y-1.5">
                  <h3 className="font-bold text-emerald-300">4. Penambahan Katalis</h3>
                  <p className="text-slate-300 text-xs leading-relaxed">
                    Katalis menurunkan energi aktivasi reaksi (Ea) dengan menyediakan jalur mekanisme reaksi alternatif yang lebih mudah ditempuh.
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* Tombol Navigasi Bawah */}
          <div className="flex items-center justify-between pt-2">
            <button
              type="button"
              onClick={handlePrevSection}
              disabled={activeSection === 'A'}
              className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 hover:text-white disabled:opacity-30 disabled:cursor-not-allowed text-xs font-bold flex items-center gap-1.5 transition-colors"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Bagian Sebelumnya</span>
            </button>

            <button
              type="button"
              onClick={handleNextSection}
              disabled={activeSection === 'D'}
              className="px-4 py-2 rounded-xl bg-emerald-400 hover:bg-emerald-300 text-slate-950 disabled:opacity-30 disabled:cursor-not-allowed text-xs font-bold flex items-center gap-1.5 transition-colors"
            >
              <span>Bagian Berikutnya</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
