import React, { useState } from 'react';
import {
  Flame,
  Thermometer,
  Snowflake,
  Droplets,
  Wind,
  Sun,
  ArrowRight,
  ArrowLeft,
  RotateCcw,
  Sparkles,
  Info,
  CheckCircle2,
  ChevronRight,
  Zap,
  Activity,
  Layers,
  HelpCircle,
  Shirt,
  Coffee,
  CloudRain,
  GlassWater,
  Waves,
} from 'lucide-react';

export const MateriFisikaKalor: React.FC = () => {
  // State: apakah murid sudah mengklik "🔥 MULAI BELAJAR"
  const [hasStartedReading, setHasStartedReading] = useState(false);

  // Navigasi Section: 1 sampai 8 + Kesimpulan
  type SectionType = '1' | '2' | '3' | '4' | '5' | '6' | '7' | '8' | 'kesimpulan';
  const [activeSection, setActiveSection] = useState<SectionType>('1');

  // Interaktif Section 2: Highlight simbol rumus Q = m * c * deltaT
  const [highlightSymbol, setHighlightSymbol] = useState<'Q' | 'm' | 'c' | 'deltaT' | null>(null);

  // Interaktif Section 2: Simulasi nilai
  const [massaSimulasi, setMassaSimulasi] = useState<number>(2); // kg
  const [cSimulasi, setCSimulasi] = useState<number>(4200); // J/kg°C
  const [t1Simulasi, setT1Simulasi] = useState<number>(25); // °C
  const [t2Simulasi, setT2Simulasi] = useState<number>(75); // °C
  const deltaTSimulasi = t2Simulasi - t1Simulasi;
  const qSimulasi = massaSimulasi * cSimulasi * deltaTSimulasi;

  // Interaktif Section 4: Filter perubahan wujud
  const [selectedPhaseChange, setSelectedPhaseChange] = useState<string | null>(null);

  const navItems: { id: SectionType; label: string }[] = [
    { id: '1', label: '1. Kalor' },
    { id: '2', label: '2. Perubahan Suhu' },
    { id: '3', label: '3. Kalor Jenis' },
    { id: '4', label: '4. Perubahan Wujud' },
    { id: '5', label: '5. Kalor Laten' },
    { id: '6', label: '6. Penguapan' },
    { id: '7', label: '7. Kehidupan Sehari-hari' },
    { id: '8', label: '8. Hal Penting' },
    { id: 'kesimpulan', label: 'Kesimpulan' },
  ];

  const handleNext = () => {
    const currentIndex = navItems.findIndex((item) => item.id === activeSection);
    if (currentIndex < navItems.length - 1) {
      setActiveSection(navItems[currentIndex + 1].id);
    }
  };

  const handlePrev = () => {
    const currentIndex = navItems.findIndex((item) => item.id === activeSection);
    if (currentIndex > 0) {
      setActiveSection(navItems[currentIndex - 1].id);
    }
  };

  return (
    <div className="space-y-4 sm:space-y-6 w-full min-w-0">
      {/* 1. HALAMAN COVER (HANYA COVER YANG TERLIHAT SEBELUM MULAI BELAJAR) */}
      {!hasStartedReading ? (
        <div className="relative overflow-hidden rounded-2xl sm:rounded-3xl bg-gradient-to-br from-red-950 via-red-900 to-amber-950 p-6 sm:p-12 text-white shadow-2xl border-2 border-amber-500/40 animate-in fade-in zoom-in-95">
          {/* Elemen Visual Abstrak & Glow Merah-Kuning */}
          <div className="absolute -top-16 -right-16 w-80 h-80 bg-amber-500/20 rounded-full blur-3xl pointer-events-none"></div>
          <div className="absolute -bottom-16 -left-16 w-80 h-80 bg-red-600/25 rounded-full blur-3xl pointer-events-none"></div>

          <div className="relative z-10 max-w-3xl space-y-6">
            {/* Tag Badge */}
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-amber-400 text-red-950 border border-amber-300 font-extrabold text-xs uppercase tracking-wider shadow-md">
              <Flame className="w-4 h-4 text-red-700 animate-bounce" />
              <span>Fisika SMA • Modul Energi Termal</span>
            </div>

            {/* Judul Besar */}
            <div className="space-y-2">
              <h1 className="text-3xl sm:text-5xl lg:text-6xl font-black tracking-tight text-white leading-tight uppercase drop-shadow-md">
                SUHU DAN KALOR
              </h1>
              <p className="text-base sm:text-xl lg:text-2xl font-bold text-amber-300 drop-shadow-xs">
                Memahami Kalor, Perubahan Suhu, dan Perubahan Wujud
              </p>
            </div>

            {/* Elemen Visual Modern: Termometer, Api, Es, Tetesan Air, Partikel Zat, Perpindahan Energi */}
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 sm:gap-3 py-2">
              <div className="p-3 rounded-xl bg-white/10 backdrop-blur-md border border-white/15 flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-lg bg-red-500/30 text-amber-300 flex items-center justify-center shrink-0 border border-red-400/40">
                  <Thermometer className="w-5 h-5" />
                </div>
                <div className="min-w-0">
                  <span className="text-xs font-bold text-white block">Derajat Panas</span>
                  <span className="text-[10px] text-amber-200">Termometer & Suhu</span>
                </div>
              </div>

              <div className="p-3 rounded-xl bg-white/10 backdrop-blur-md border border-white/15 flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-lg bg-amber-500/30 text-amber-300 flex items-center justify-center shrink-0 border border-amber-400/40">
                  <Flame className="w-5 h-5 text-amber-400" />
                </div>
                <div className="min-w-0">
                  <span className="text-xs font-bold text-white block">Aliran Energi</span>
                  <span className="text-[10px] text-amber-200">Perpindahan Kalor</span>
                </div>
              </div>

              <div className="p-3 rounded-xl bg-white/10 backdrop-blur-md border border-white/15 flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-lg bg-blue-500/30 text-cyan-200 flex items-center justify-center shrink-0 border border-blue-400/40">
                  <Snowflake className="w-5 h-5" />
                </div>
                <div className="min-w-0">
                  <span className="text-xs font-bold text-white block">Fase Zat Padat</span>
                  <span className="text-[10px] text-cyan-100">Es & Pembekuan</span>
                </div>
              </div>

              <div className="p-3 rounded-xl bg-white/10 backdrop-blur-md border border-white/15 flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-lg bg-cyan-500/30 text-cyan-200 flex items-center justify-center shrink-0 border border-cyan-400/40">
                  <Droplets className="w-5 h-5" />
                </div>
                <div className="min-w-0">
                  <span className="text-xs font-bold text-white block">Cairan Fluida</span>
                  <span className="text-[10px] text-cyan-100">Tetesan & Penguapan</span>
                </div>
              </div>

              <div className="p-3 rounded-xl bg-white/10 backdrop-blur-md border border-white/15 flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-lg bg-yellow-500/30 text-yellow-300 flex items-center justify-center shrink-0 border border-yellow-400/40">
                  <Activity className="w-5 h-5" />
                </div>
                <div className="min-w-0">
                  <span className="text-xs font-bold text-white block">Partikel Zat</span>
                  <span className="text-[10px] text-yellow-100">Energi Kinetik Molekul</span>
                </div>
              </div>

              <div className="p-3 rounded-xl bg-white/10 backdrop-blur-md border border-white/15 flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-lg bg-red-600/30 text-amber-200 flex items-center justify-center shrink-0 border border-red-500/40">
                  <Zap className="w-5 h-5" />
                </div>
                <div className="min-w-0">
                  <span className="text-xs font-bold text-white block">Q = mcΔT / mL</span>
                  <span className="text-[10px] text-amber-200">Perhitungan Kalor</span>
                </div>
              </div>
            </div>

            {/* Tombol Utama */}
            <div className="pt-4">
              <button
                type="button"
                id="btn-mulai-belajar-fisika"
                onClick={() => setHasStartedReading(true)}
                className="w-full sm:w-auto px-8 py-4 rounded-xl sm:rounded-2xl bg-gradient-to-r from-amber-400 via-amber-300 to-yellow-400 hover:from-amber-300 hover:to-yellow-300 text-red-950 font-black text-base sm:text-lg transition-all shadow-xl shadow-amber-500/30 active:scale-95 flex items-center justify-center gap-3 cursor-pointer border border-amber-200"
              >
                <span>🔥 MULAI BELAJAR</span>
                <ArrowRight className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>
      ) : (
        /* 2. HALAMAN MATERI (MUNCUL SETELAH TOMBOL DITEKAN) */
        <div className="space-y-4 sm:space-y-6 animate-in fade-in duration-300">
          {/* Header Navigasi Tema Kuning-Merah-Putih */}
          <div className="bg-slate-900/95 rounded-2xl p-2.5 sm:p-4 border border-amber-500/40 shadow-xl space-y-2.5">
            <div className="flex items-center justify-between gap-2 border-b border-slate-800 pb-2">
              <div className="flex items-center gap-2 min-w-0">
                <div className="w-7 h-7 sm:w-8 sm:h-8 rounded-lg bg-amber-400 text-red-950 flex items-center justify-center font-bold text-xs shrink-0 shadow-xs">
                  🔥
                </div>
                <div className="min-w-0">
                  <h2 className="text-xs sm:text-sm font-bold text-white uppercase tracking-wider truncate">
                    SUHU DAN KALOR — FISIKA SMA
                  </h2>
                  <p className="text-[10px] sm:text-xs text-amber-300 truncate">
                    Tema: Kuning – Merah – Putih
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setHasStartedReading(false)}
                className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white text-xs font-semibold flex items-center gap-1 shrink-0 transition-colors"
                title="Kembali ke halaman cover"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Cover</span>
              </button>
            </div>

            {/* Navigasi: 1. Kalor | 2. Perubahan Suhu | 3. Kalor Jenis | 4. Perubahan Wujud | 5. Kalor Laten | 6. Penguapan | 7. Kehidupan Sehari-hari | 8. Hal Penting | Kesimpulan */}
            <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-thin scrollbar-thumb-amber-500/50">
              {navItems.map((item) => {
                const isActive = activeSection === item.id;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => setActiveSection(item.id)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all cursor-pointer ${
                      isActive
                        ? 'bg-gradient-to-r from-amber-400 to-amber-300 text-red-950 shadow-md font-extrabold ring-2 ring-amber-300/60'
                        : 'bg-slate-800/80 text-slate-300 hover:text-white hover:bg-slate-700/80 border border-slate-700'
                    }`}
                  >
                    {item.label}
                  </button>
                );
              })}
            </div>
          </div>

          {/* KONTEN SESUAI DENGAN BAGIAN NAVIGASI */}

          {/* SECTION 1: PENGERTIAN KALOR */}
          {activeSection === '1' && (
            <div className="bg-slate-900/90 rounded-2xl sm:rounded-3xl p-5 sm:p-7 border border-amber-500/40 shadow-xl space-y-6">
              <div className="border-b border-slate-800 pb-3 flex items-center justify-between">
                <div>
                  <span className="text-xs font-bold text-amber-400 uppercase tracking-wider">Bagian 1</span>
                  <h2 className="text-xl sm:text-2xl font-black text-white">1. Pengertian Kalor</h2>
                </div>
                <div className="w-10 h-10 rounded-xl bg-red-600/30 text-amber-300 border border-red-500/40 flex items-center justify-center font-bold">
                  <Flame className="w-6 h-6 text-amber-400" />
                </div>
              </div>

              {/* Teks Definisi */}
              <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-r from-red-950/70 via-slate-900 to-amber-950/70 border border-amber-400/40 text-slate-100 space-y-3 leading-relaxed text-sm sm:text-base">
                <p>
                  <strong>Kalor</strong> adalah energi yang berpindah dari benda yang bersuhu lebih tinggi ke benda
                  yang bersuhu lebih rendah karena adanya perbedaan suhu.
                </p>
                <div className="p-3 bg-red-950/80 rounded-xl border border-red-500/40 text-amber-200 font-semibold text-xs sm:text-sm">
                  💡 <strong>Kalor bukanlah sesuatu yang dimiliki benda, tetapi energi yang berpindah.</strong>
                </div>
              </div>

              {/* Contoh */}
              <div className="space-y-3">
                <h3 className="text-sm font-bold text-amber-300 uppercase tracking-wide">Contoh:</h3>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div className="p-4 rounded-xl bg-slate-800/80 border border-slate-700/80 space-y-2">
                    <div className="w-8 h-8 rounded-lg bg-red-500/20 text-red-400 flex items-center justify-center font-bold">
                      🔥
                    </div>
                    <p className="text-xs sm:text-sm text-slate-200">
                      <strong>Air yang dipanaskan</strong> menerima kalor dari api.
                    </p>
                  </div>

                  <div className="p-4 rounded-xl bg-slate-800/80 border border-slate-700/80 space-y-2">
                    <div className="w-8 h-8 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center font-bold">
                      🥄
                    </div>
                    <p className="text-xs sm:text-sm text-slate-200">
                      <strong>Sendok logam</strong> yang dicelupkan ke dalam teh panas menerima kalor dari teh.
                    </p>
                  </div>

                  <div className="p-4 rounded-xl bg-slate-800/80 border border-slate-700/80 space-y-2">
                    <div className="w-8 h-8 rounded-lg bg-cyan-500/20 text-cyan-400 flex items-center justify-center font-bold">
                      🧊
                    </div>
                    <p className="text-xs sm:text-sm text-slate-200">
                      <strong>Es batu</strong> menerima kalor dari lingkungan sehingga mencair.
                    </p>
                  </div>
                </div>
              </div>

              {/* Satuan Kalor */}
              <div className="p-4 rounded-xl bg-slate-800/60 border border-slate-700 flex items-center justify-between">
                <div className="text-xs sm:text-sm text-slate-300">
                  Satuan kalor dalam SI adalah <strong className="text-amber-300">joule (J)</strong>.
                </div>
                <span className="px-3 py-1 rounded-lg bg-amber-400 text-red-950 font-black text-xs">
                  1 kalori ≈ 4,184 Joule
                </span>
              </div>

              {/* Ilustrasi Perpindahan Kalor */}
              <div className="p-5 rounded-2xl bg-gradient-to-r from-red-950/90 to-blue-950/90 border border-amber-500/40 text-center space-y-3">
                <h4 className="text-xs sm:text-sm font-bold text-amber-300 uppercase tracking-wide">
                  Ilustrasi Arah Perpindahan Kalor
                </h4>
                <div className="flex flex-col sm:flex-row items-center justify-center gap-3 sm:gap-6 py-2">
                  <div className="p-4 rounded-xl bg-red-600/40 border border-red-400 text-white w-44">
                    <span className="text-2xl block">🔥</span>
                    <strong className="text-xs sm:text-sm block text-amber-200">Benda Bersuhu Tinggi</strong>
                    <span className="text-[11px] text-red-200">Suhu T₁ (Panas)</span>
                  </div>

                  <div className="flex flex-col items-center">
                    <div className="flex items-center gap-1 text-amber-400 font-extrabold text-xs">
                      <span>Aliran Kalor (Q)</span>
                      <ArrowRight className="w-5 h-5 text-amber-400 animate-pulse" />
                    </div>
                    <span className="text-[10px] text-slate-300 mt-0.5">Spontan mengalir</span>
                  </div>

                  <div className="p-4 rounded-xl bg-blue-600/40 border border-blue-400 text-white w-44">
                    <span className="text-2xl block">❄️</span>
                    <strong className="text-xs sm:text-sm block text-cyan-200">Benda Bersuhu Rendah</strong>
                    <span className="text-[11px] text-blue-200">Suhu T₂ (Dingin)</span>
                  </div>
                </div>
                <p className="text-xs text-amber-100 font-medium">
                  Kalor berpindah secara spontan dari benda bersuhu tinggi ke benda bersuhu rendah hingga mencapai kesetimbangan termal.
                </p>
              </div>
            </div>
          )}

          {/* SECTION 2: KALOR DAN PERUBAHAN SUHU */}
          {activeSection === '2' && (
            <div className="bg-slate-900/90 rounded-2xl sm:rounded-3xl p-5 sm:p-7 border border-amber-500/40 shadow-xl space-y-6">
              <div className="border-b border-slate-800 pb-3 flex items-center justify-between">
                <div>
                  <span className="text-xs font-bold text-amber-400 uppercase tracking-wider">Bagian 2</span>
                  <h2 className="text-xl sm:text-2xl font-black text-white">2. Kalor dan Perubahan Suhu</h2>
                </div>
                <div className="w-10 h-10 rounded-xl bg-red-600/30 text-amber-300 border border-red-500/40 flex items-center justify-center font-bold">
                  <Thermometer className="w-6 h-6 text-amber-400" />
                </div>
              </div>

              <p className="text-xs sm:text-sm text-slate-200 leading-relaxed">
                Ketika suatu benda menerima atau melepaskan kalor, suhunya dapat berubah tanpa mengubah wujud benda.
              </p>

              {/* Kartu Rumus Visual Besar dengan Highlight Interaktif */}
              <div className="p-6 rounded-2xl bg-gradient-to-br from-red-950 via-slate-900 to-amber-950 border-2 border-amber-400 text-center space-y-4 shadow-xl">
                <span className="text-xs font-bold uppercase tracking-wider text-amber-300 block">
                  Rumus Perubahan Suhu:
                </span>

                <div className="flex flex-wrap items-center justify-center gap-2 sm:gap-4 font-mono font-black text-2xl sm:text-4xl text-white">
                  <button
                    type="button"
                    onClick={() => setHighlightSymbol('Q')}
                    className={`px-3 py-1.5 rounded-xl cursor-pointer transition-all ${
                      highlightSymbol === 'Q'
                        ? 'bg-amber-400 text-red-950 scale-110 shadow-lg ring-2 ring-white'
                        : 'bg-white/10 hover:bg-white/20 text-amber-300'
                    }`}
                  >
                    Q
                  </button>
                  <span>=</span>
                  <button
                    type="button"
                    onClick={() => setHighlightSymbol('m')}
                    className={`px-3 py-1.5 rounded-xl cursor-pointer transition-all ${
                      highlightSymbol === 'm'
                        ? 'bg-amber-400 text-red-950 scale-110 shadow-lg ring-2 ring-white'
                        : 'bg-white/10 hover:bg-white/20 text-white'
                    }`}
                  >
                    m
                  </button>
                  <span>·</span>
                  <button
                    type="button"
                    onClick={() => setHighlightSymbol('c')}
                    className={`px-3 py-1.5 rounded-xl cursor-pointer transition-all ${
                      highlightSymbol === 'c'
                        ? 'bg-amber-400 text-red-950 scale-110 shadow-lg ring-2 ring-white'
                        : 'bg-white/10 hover:bg-white/20 text-white'
                    }`}
                  >
                    c
                  </button>
                  <span>·</span>
                  <button
                    type="button"
                    onClick={() => setHighlightSymbol('deltaT')}
                    className={`px-3 py-1.5 rounded-xl cursor-pointer transition-all ${
                      highlightSymbol === 'deltaT'
                        ? 'bg-amber-400 text-red-950 scale-110 shadow-lg ring-2 ring-white'
                        : 'bg-white/10 hover:bg-white/20 text-amber-300'
                    }`}
                  >
                    ΔT
                  </button>
                </div>

                <p className="text-[11px] text-slate-400">
                  Klik setiap simbol rumus di atas untuk melihat penjelasannya secara langsung.
                </p>

                {/* Rumus Tambahan ΔT = T2 - T1 */}
                <div className="inline-block p-3 rounded-xl bg-black/40 border border-amber-400/30 text-amber-200 text-sm sm:text-base font-mono font-bold">
                  ΔT = T₂ − T₁
                </div>
              </div>

              {/* Keterangan */}
              <div className="space-y-2">
                <h3 className="text-xs font-bold text-amber-300 uppercase tracking-wide">Keterangan:</h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-xs sm:text-sm">
                  <div
                    className={`p-3 rounded-xl border transition-all ${
                      highlightSymbol === 'Q'
                        ? 'bg-amber-400/20 border-amber-400 text-white'
                        : 'bg-slate-800/80 border-slate-700 text-slate-300'
                    }`}
                  >
                    <strong className="text-amber-400">Q</strong> = kalor (joule)
                  </div>
                  <div
                    className={`p-3 rounded-xl border transition-all ${
                      highlightSymbol === 'm'
                        ? 'bg-amber-400/20 border-amber-400 text-white'
                        : 'bg-slate-800/80 border-slate-700 text-slate-300'
                    }`}
                  >
                    <strong className="text-amber-400">m</strong> = massa benda (kg)
                  </div>
                  <div
                    className={`p-3 rounded-xl border transition-all ${
                      highlightSymbol === 'c'
                        ? 'bg-amber-400/20 border-amber-400 text-white'
                        : 'bg-slate-800/80 border-slate-700 text-slate-300'
                    }`}
                  >
                    <strong className="text-amber-400">c</strong> = kalor jenis (J/kg°C)
                  </div>
                  <div
                    className={`p-3 rounded-xl border transition-all ${
                      highlightSymbol === 'deltaT'
                        ? 'bg-amber-400/20 border-amber-400 text-white'
                        : 'bg-slate-800/80 border-slate-700 text-slate-300'
                    }`}
                  >
                    <strong className="text-amber-400">ΔT</strong> = perubahan suhu (°C)
                  </div>
                </div>
              </div>

              {/* Kalkulator Interaktif Q = mcΔT */}
              <div className="p-4 rounded-xl bg-slate-800/80 border border-slate-700 space-y-3">
                <h4 className="text-xs font-bold text-amber-300 uppercase tracking-wide">
                  🧪 Eksplorasi Nilai Q = m · c · ΔT
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                  <div>
                    <label className="text-slate-400 block mb-1">Massa (m): {massaSimulasi} kg</label>
                    <input
                      type="range"
                      min={0.5}
                      max={10}
                      step={0.5}
                      value={massaSimulasi}
                      onChange={(e) => setMassaSimulasi(parseFloat(e.target.value))}
                      className="w-full accent-amber-400"
                    />
                  </div>
                  <div>
                    <label className="text-slate-400 block mb-1">Zat (c):</label>
                    <select
                      value={cSimulasi}
                      onChange={(e) => setCSimulasi(parseInt(e.target.value))}
                      className="w-full p-1.5 rounded-lg bg-slate-900 text-white border border-slate-600 text-xs"
                    >
                      <option value={4200}>Air (4200 J/kg°C)</option>
                      <option value={900}>Aluminium (900 J/kg°C)</option>
                      <option value={450}>Besi (450 J/kg°C)</option>
                      <option value={390}>Tembaga (390 J/kg°C)</option>
                    </select>
                  </div>
                  <div>
                    <label className="text-slate-400 block mb-1">
                      Perubahan Suhu (ΔT): {t1Simulasi}°C → {t2Simulasi}°C ({deltaTSimulasi}°C)
                    </label>
                    <input
                      type="range"
                      min={30}
                      max={100}
                      step={5}
                      value={t2Simulasi}
                      onChange={(e) => setT2Simulasi(parseInt(e.target.value))}
                      className="w-full accent-amber-400"
                    />
                  </div>
                </div>

                <div className="p-3 rounded-lg bg-red-950/80 border border-red-500/40 text-center">
                  <span className="text-xs text-amber-200 block">Hasil Kalor yang Diperlukan (Q):</span>
                  <span className="text-xl sm:text-2xl font-mono font-black text-amber-400">
                    Q = {qSimulasi.toLocaleString('id-ID')} Joule ({(qSimulasi / 1000).toFixed(1)} kJ)
                  </span>
                </div>
              </div>
            </div>
          )}

          {/* SECTION 3: KALOR JENIS */}
          {activeSection === '3' && (
            <div className="bg-slate-900/90 rounded-2xl sm:rounded-3xl p-5 sm:p-7 border border-amber-500/40 shadow-xl space-y-6">
              <div className="border-b border-slate-800 pb-3 flex items-center justify-between">
                <div>
                  <span className="text-xs font-bold text-amber-400 uppercase tracking-wider">Bagian 3</span>
                  <h2 className="text-xl sm:text-2xl font-black text-white">3. Kalor Jenis</h2>
                </div>
                <div className="w-10 h-10 rounded-xl bg-red-600/30 text-amber-300 border border-red-500/40 flex items-center justify-center font-bold">
                  <Zap className="w-6 h-6 text-amber-400" />
                </div>
              </div>

              <div className="p-4 rounded-xl bg-slate-800/80 border border-slate-700/80 text-xs sm:text-sm text-slate-200 leading-relaxed space-y-2">
                <p>
                  <strong>Kalor jenis</strong> adalah banyaknya kalor yang diperlukan untuk menaikkan suhu 1 kg suatu
                  zat sebesar 1°C.
                </p>
                <p className="text-amber-300 font-semibold">Setiap zat memiliki kalor jenis yang berbeda.</p>
              </div>

              {/* Tabel Visual Kalor Jenis */}
              <div className="space-y-3">
                <h3 className="text-xs font-bold text-amber-300 uppercase tracking-wide">
                  Contohnya (Tabel Kalor Jenis):
                </h3>
                <div className="overflow-x-auto rounded-xl border border-amber-500/30 shadow-md">
                  <table className="w-full text-left text-xs sm:text-sm text-slate-200">
                    <thead className="bg-gradient-to-r from-red-950 to-amber-950 text-amber-300 font-bold border-b border-amber-500/40">
                      <tr>
                        <th className="p-3">Zat</th>
                        <th className="p-3 text-right">Kalor Jenis</th>
                        <th className="p-3">Visualisasi Relatif</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800 bg-slate-900/80">
                      <tr>
                        <td className="p-3 font-bold text-cyan-300 flex items-center gap-1.5">
                          <span>💧</span> Air
                        </td>
                        <td className="p-3 text-right font-mono font-bold text-amber-400">4200 J/kg°C</td>
                        <td className="p-3">
                          <div className="w-full bg-slate-800 h-3 rounded-full overflow-hidden max-w-xs">
                            <div className="bg-cyan-400 h-full rounded-full" style={{ width: '100%' }}></div>
                          </div>
                        </td>
                      </tr>
                      <tr>
                        <td className="p-3 font-bold text-slate-200 flex items-center gap-1.5">
                          <span>🔩</span> Aluminium
                        </td>
                        <td className="p-3 text-right font-mono font-bold text-amber-400">900 J/kg°C</td>
                        <td className="p-3">
                          <div className="w-full bg-slate-800 h-3 rounded-full overflow-hidden max-w-xs">
                            <div className="bg-amber-400 h-full rounded-full" style={{ width: '21.4%' }}></div>
                          </div>
                        </td>
                      </tr>
                      <tr>
                        <td className="p-3 font-bold text-slate-200 flex items-center gap-1.5">
                          <span>⚙️</span> Besi
                        </td>
                        <td className="p-3 text-right font-mono font-bold text-amber-400">450 J/kg°C</td>
                        <td className="p-3">
                          <div className="w-full bg-slate-800 h-3 rounded-full overflow-hidden max-w-xs">
                            <div className="bg-orange-500 h-full rounded-full" style={{ width: '10.7%' }}></div>
                          </div>
                        </td>
                      </tr>
                      <tr>
                        <td className="p-3 font-bold text-slate-200 flex items-center gap-1.5">
                          <span>🪙</span> Tembaga
                        </td>
                        <td className="p-3 text-right font-mono font-bold text-amber-400">390 J/kg°C</td>
                        <td className="p-3">
                          <div className="w-full bg-slate-800 h-3 rounded-full overflow-hidden max-w-xs">
                            <div className="bg-red-500 h-full rounded-full" style={{ width: '9.3%' }}></div>
                          </div>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>

                <p className="text-xs text-amber-200 p-3 rounded-xl bg-amber-950/40 border border-amber-500/30">
                  <strong>Air memiliki kalor jenis yang relatif besar.</strong> Artinya, air membutuhkan energi yang
                  cukup besar untuk mengalami kenaikan suhu.
                </p>
              </div>

              {/* Dalam Kehidupan Sehari-hari */}
              <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-br from-red-950/60 to-slate-900 border border-amber-500/30 space-y-3">
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <span>🚗 Dalam kehidupan sehari-hari:</span>
                </h3>
                <p className="text-xs sm:text-sm text-slate-300">
                  Hal ini membantu menjelaskan mengapa air dapat digunakan untuk menyerap panas, misalnya:
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs sm:text-sm text-slate-200">
                  <div className="p-2.5 rounded-lg bg-slate-800/80 border border-slate-700 flex items-center gap-2">
                    <span className="text-amber-400">•</span> pendingin mesin,
                  </div>
                  <div className="p-2.5 rounded-lg bg-slate-800/80 border border-slate-700 flex items-center gap-2">
                    <span className="text-amber-400">•</span> pendingin radiator,
                  </div>
                  <div className="p-2.5 rounded-lg bg-slate-800/80 border border-slate-700 flex items-center gap-2">
                    <span className="text-amber-400">•</span> menyimpan panas,
                  </div>
                  <div className="p-2.5 rounded-lg bg-slate-800/80 border border-slate-700 flex items-center gap-2">
                    <span className="text-amber-400">•</span> dan membantu mengatur suhu lingkungan.
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* SECTION 4: KALOR DAN PERUBAHAN WUJUD */}
          {activeSection === '4' && (
            <div className="bg-slate-900/90 rounded-2xl sm:rounded-3xl p-5 sm:p-7 border border-amber-500/40 shadow-xl space-y-6">
              <div className="border-b border-slate-800 pb-3 flex items-center justify-between">
                <div>
                  <span className="text-xs font-bold text-amber-400 uppercase tracking-wider">Bagian 4</span>
                  <h2 className="text-xl sm:text-2xl font-black text-white">4. Kalor dan Perubahan Wujud</h2>
                </div>
                <div className="w-10 h-10 rounded-xl bg-red-600/30 text-amber-300 border border-red-500/40 flex items-center justify-center font-bold">
                  <Snowflake className="w-6 h-6 text-cyan-300" />
                </div>
              </div>

              <div className="p-4 rounded-xl bg-gradient-to-r from-red-950/60 to-amber-950/60 border border-amber-500/30 text-xs sm:text-sm text-slate-200 leading-relaxed space-y-2">
                <p>
                  <strong>Kalor tidak selalu menyebabkan perubahan suhu.</strong>
                </p>
                <p>
                  Ketika suatu zat mengalami perubahan wujud, kalor dapat digunakan untuk mengubah susunan atau keadaan
                  zat tersebut.
                </p>
              </div>

              {/* Diagram Visual / Siklus Perubahan Wujud */}
              <div className="space-y-3">
                <h3 className="text-xs font-bold text-amber-300 uppercase tracking-wide">
                  Contoh perubahan wujud (Diagram Siklus Perubahan Wujud):
                </h3>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  {/* Padat (Es) */}
                  <div className="p-4 rounded-2xl bg-blue-950/60 border border-blue-400/40 text-center space-y-2">
                    <div className="w-12 h-12 rounded-xl bg-blue-500/20 text-cyan-200 flex items-center justify-center mx-auto text-2xl">
                      🧊
                    </div>
                    <strong className="text-sm text-white block">PADAT (Es)</strong>
                    <span className="text-[11px] text-blue-200">Bentuk & volume tetap</span>
                  </div>

                  {/* Cair (Air) */}
                  <div className="p-4 rounded-2xl bg-cyan-950/60 border border-cyan-400/40 text-center space-y-2">
                    <div className="w-12 h-12 rounded-xl bg-cyan-500/20 text-cyan-200 flex items-center justify-center mx-auto text-2xl">
                      💧
                    </div>
                    <strong className="text-sm text-white block">CAIR (Air)</strong>
                    <span className="text-[11px] text-cyan-200">Volume tetap, bentuk berubah</span>
                  </div>

                  {/* Gas (Uap) */}
                  <div className="p-4 rounded-2xl bg-amber-950/60 border border-amber-400/40 text-center space-y-2">
                    <div className="w-12 h-12 rounded-xl bg-amber-500/20 text-amber-300 flex items-center justify-center mx-auto text-2xl">
                      💨
                    </div>
                    <strong className="text-sm text-white block">GAS (Uap)</strong>
                    <span className="text-[11px] text-amber-200">Bentuk & volume berubah</span>
                  </div>
                </div>

                {/* 6 Proses Perubahan Wujud */}
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5 pt-2">
                  <div className="p-3.5 rounded-xl bg-slate-800/90 border border-amber-500/30 flex items-center justify-between">
                    <div>
                      <span className="text-[10px] text-amber-400 font-bold block">Padat → Cair</span>
                      <strong className="text-xs sm:text-sm text-white">Mencair</strong>
                    </div>
                    <span className="text-xs px-2 py-0.5 rounded-md bg-red-500/20 text-red-300 border border-red-500/30">
                      Menyerap Kalor
                    </span>
                  </div>

                  <div className="p-3.5 rounded-xl bg-slate-800/90 border border-amber-500/30 flex items-center justify-between">
                    <div>
                      <span className="text-[10px] text-amber-400 font-bold block">Cair → Gas</span>
                      <strong className="text-xs sm:text-sm text-white">Menguap</strong>
                    </div>
                    <span className="text-xs px-2 py-0.5 rounded-md bg-red-500/20 text-red-300 border border-red-500/30">
                      Menyerap Kalor
                    </span>
                  </div>

                  <div className="p-3.5 rounded-xl bg-slate-800/90 border border-amber-500/30 flex items-center justify-between">
                    <div>
                      <span className="text-[10px] text-amber-400 font-bold block">Gas → Cair</span>
                      <strong className="text-xs sm:text-sm text-white">Mengembun</strong>
                    </div>
                    <span className="text-xs px-2 py-0.5 rounded-md bg-blue-500/20 text-cyan-300 border border-blue-500/30">
                      Melepas Kalor
                    </span>
                  </div>

                  <div className="p-3.5 rounded-xl bg-slate-800/90 border border-amber-500/30 flex items-center justify-between">
                    <div>
                      <span className="text-[10px] text-amber-400 font-bold block">Cair → Padat</span>
                      <strong className="text-xs sm:text-sm text-white">Membeku</strong>
                    </div>
                    <span className="text-xs px-2 py-0.5 rounded-md bg-blue-500/20 text-cyan-300 border border-blue-500/30">
                      Melepas Kalor
                    </span>
                  </div>

                  <div className="p-3.5 rounded-xl bg-slate-800/90 border border-amber-500/30 flex items-center justify-between">
                    <div>
                      <span className="text-[10px] text-amber-400 font-bold block">Padat → Gas</span>
                      <strong className="text-xs sm:text-sm text-white">Menyublim</strong>
                    </div>
                    <span className="text-xs px-2 py-0.5 rounded-md bg-red-500/20 text-red-300 border border-red-500/30">
                      Menyerap Kalor
                    </span>
                  </div>

                  <div className="p-3.5 rounded-xl bg-slate-800/90 border border-amber-500/30 flex items-center justify-between">
                    <div>
                      <span className="text-[10px] text-amber-400 font-bold block">Gas → Padat</span>
                      <strong className="text-xs sm:text-sm text-white">Mengkristal/deposisi</strong>
                    </div>
                    <span className="text-xs px-2 py-0.5 rounded-md bg-blue-500/20 text-cyan-300 border border-blue-500/30">
                      Melepas Kalor
                    </span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* SECTION 5: KALOR LATEN */}
          {activeSection === '5' && (
            <div className="bg-slate-900/90 rounded-2xl sm:rounded-3xl p-5 sm:p-7 border border-amber-500/40 shadow-xl space-y-6">
              <div className="border-b border-slate-800 pb-3 flex items-center justify-between">
                <div>
                  <span className="text-xs font-bold text-amber-400 uppercase tracking-wider">Bagian 5</span>
                  <h2 className="text-xl sm:text-2xl font-black text-white">5. Kalor Laten</h2>
                </div>
                <div className="w-10 h-10 rounded-xl bg-red-600/30 text-amber-300 border border-red-500/40 flex items-center justify-center font-bold">
                  <Activity className="w-6 h-6 text-amber-400" />
                </div>
              </div>

              <div className="p-4 rounded-xl bg-slate-800/80 border border-slate-700/80 text-xs sm:text-sm text-slate-200 leading-relaxed">
                <p>
                  Kalor yang digunakan untuk mengubah wujud zat tanpa mengubah suhunya disebut{' '}
                  <strong className="text-amber-400">kalor laten</strong>.
                </p>
              </div>

              {/* Rumus Kalor Laten */}
              <div className="p-6 rounded-2xl bg-gradient-to-br from-red-950 via-slate-900 to-amber-950 border-2 border-amber-400 text-center space-y-3 shadow-xl">
                <span className="text-xs font-bold uppercase tracking-wider text-amber-300 block">
                  Rumus Kalor Laten:
                </span>
                <div className="font-mono font-black text-3xl sm:text-5xl text-white">Q = mL</div>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 pt-2 text-xs text-slate-300">
                  <div>• <strong>Q</strong> = kalor (J)</div>
                  <div>• <strong>m</strong> = massa zat (kg)</div>
                  <div>• <strong>L</strong> = kalor laten (J/kg)</div>
                </div>
              </div>

              {/* Contoh */}
              <div className="p-5 rounded-2xl bg-slate-800/80 border border-slate-700 space-y-3">
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <span>🧊 Contoh:</span>
                </h3>
                <p className="text-xs sm:text-sm text-slate-200 leading-relaxed">
                  Ketika es pada suhu 0°C dipanaskan, es dapat berubah menjadi air pada suhu 0°C. Suhu tetap 0°C selama
                  proses mencair, meskipun es terus menerima kalor.
                </p>
                <div className="p-3 rounded-xl bg-amber-400/10 border border-amber-400/30 text-amber-300 text-xs font-bold">
                  ⚡ Kalor yang diterima digunakan untuk mengubah wujud, bukan menaikkan suhu.
                </div>
              </div>

              {/* Ilustrasi Visual Es 0°C -> Menerima Kalor -> Air 0°C */}
              <div className="p-5 rounded-2xl bg-gradient-to-r from-blue-950/80 via-slate-900 to-cyan-950/80 border border-cyan-400/40 text-center space-y-3">
                <h4 className="text-xs sm:text-sm font-bold text-cyan-300 uppercase tracking-wide">
                  Ilustrasi Perubahan Wujud pada Suhu Tetap:
                </h4>

                <div className="flex flex-col sm:flex-row items-center justify-center gap-3 sm:gap-6 py-2">
                  <div className="p-4 rounded-xl bg-blue-600/30 border border-blue-400 text-white w-40">
                    <span className="text-3xl block">🧊</span>
                    <strong className="text-xs sm:text-sm block text-white mt-1">Es Padat</strong>
                    <span className="text-xs font-bold text-cyan-300 font-mono">Suhu: 0°C</span>
                  </div>

                  <div className="flex flex-col items-center">
                    <div className="px-3 py-1 rounded-full bg-red-500/20 text-red-300 border border-red-500/40 text-xs font-bold flex items-center gap-1">
                      <span>Menerima Kalor (Q = mL)</span>
                      <ArrowRight className="w-4 h-4 text-amber-400" />
                    </div>
                    <span className="text-[10px] text-amber-300 font-bold mt-1">Suhu Tetap Konstan 0°C</span>
                  </div>

                  <div className="p-4 rounded-xl bg-cyan-600/30 border border-cyan-400 text-white w-40">
                    <span className="text-3xl block">💧</span>
                    <strong className="text-xs sm:text-sm block text-white mt-1">Air Cair</strong>
                    <span className="text-xs font-bold text-cyan-300 font-mono">Suhu: 0°C</span>
                  </div>
                </div>

                <div className="p-2.5 rounded-lg bg-black/40 text-xs text-amber-200">
                  Selama fase peleburan es berlangsung, seluruh energi kalor dipakai memutus ikatan kisi kristal es,
                  sehingga termometer tetap membaca <strong>0°C</strong> tanpa kenaikan suhu.
                </div>
              </div>
            </div>
          )}

          {/* SECTION 6: MENGAPA AIR MENGUAP KETIKA DIPANASKAN? */}
          {activeSection === '6' && (
            <div className="bg-slate-900/90 rounded-2xl sm:rounded-3xl p-5 sm:p-7 border border-amber-500/40 shadow-xl space-y-6">
              <div className="border-b border-slate-800 pb-3 flex items-center justify-between">
                <div>
                  <span className="text-xs font-bold text-amber-400 uppercase tracking-wider">Bagian 6</span>
                  <h2 className="text-xl sm:text-2xl font-black text-white">
                    6. Mengapa Air Menguap Ketika Dipanaskan?
                  </h2>
                </div>
                <div className="w-10 h-10 rounded-xl bg-red-600/30 text-amber-300 border border-red-500/40 flex items-center justify-center font-bold">
                  <Droplets className="w-6 h-6 text-cyan-300" />
                </div>
              </div>

              <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-r from-red-950/60 to-slate-900 border border-amber-500/30 text-xs sm:text-sm text-slate-200 leading-relaxed space-y-3">
                <p>
                  Ketika air menerima kalor, energi partikel-partikel air meningkat.
                </p>
                <p>
                  Semakin banyak energi yang diterima, semakin mudah sebagian partikel air meninggalkan permukaan dan
                  berubah menjadi uap air.
                </p>
                <div className="p-3 rounded-xl bg-amber-400/10 border border-amber-400/30 text-amber-300 font-bold">
                  Proses ini disebut <strong>penguapan</strong>. Penguapan dapat terjadi bahkan sebelum air mencapai titik didih.
                </div>
              </div>

              {/* Visualisasi Partikel Air yang Meninggalkan Permukaan */}
              <div className="p-5 rounded-2xl bg-slate-800/80 border border-slate-700 space-y-3 text-center">
                <h4 className="text-xs sm:text-sm font-bold text-amber-300 uppercase tracking-wide">
                  Visualisasi Partikel Air Memperoleh Energi & Lepas Menjadi Uap
                </h4>

                <div className="relative h-44 rounded-xl bg-gradient-to-b from-slate-950 via-slate-900 to-cyan-950 border border-cyan-500/30 overflow-hidden flex flex-col justify-end p-4">
                  {/* Partikel Uap Air Terbang */}
                  <div className="absolute top-4 left-1/4 animate-bounce text-cyan-300 text-xs font-mono font-bold">
                    💨 Partikel Uap Air (Energi Tinggi)
                  </div>
                  <div className="absolute top-10 right-1/4 text-cyan-200 text-sm animate-pulse">
                    💨 💨
                  </div>

                  {/* Permukaan Air */}
                  <div className="border-t-2 border-dashed border-cyan-400/60 pt-3 flex items-center justify-around">
                    <span className="text-xs text-amber-300 font-bold">↑ Molekul lepas dari permukaan</span>
                  </div>

                  {/* Lapisan Cairan Air & Sumber Kalor */}
                  <div className="p-3 rounded-lg bg-cyan-600/30 border border-cyan-400/40 flex items-center justify-between text-xs text-cyan-100">
                    <span>💧 Partikel Cairan Air Menyerap Energi Panas</span>
                    <span className="text-amber-400 font-bold">🔥 Sumber Kalor</span>
                  </div>
                </div>

                <p className="text-xs text-slate-400">
                  Partikel air di permukaan yang memperoleh energi kinetik melampaui gaya tarik antarmolekul akan lepas
                  menuju udara bebas sebagai uap air.
                </p>
              </div>

              {/* Contoh dalam Kehidupan Sehari-hari */}
              <div className="space-y-2">
                <h3 className="text-xs font-bold text-amber-300 uppercase tracking-wide">
                  Contoh dalam kehidupan sehari-hari:
                </h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-xs sm:text-sm">
                  <div className="p-3 rounded-xl bg-slate-800/80 border border-slate-700 text-slate-200 flex items-center gap-2">
                    <span className="text-amber-400">•</span> pakaian basah menjadi kering,
                  </div>
                  <div className="p-3 rounded-xl bg-slate-800/80 border border-slate-700 text-slate-200 flex items-center gap-2">
                    <span className="text-amber-400">•</span> genangan air berkurang,
                  </div>
                  <div className="p-3 rounded-xl bg-slate-800/80 border border-slate-700 text-slate-200 flex items-center gap-2">
                    <span className="text-amber-400">•</span> keringat menguap dari kulit,
                  </div>
                  <div className="p-3 rounded-xl bg-slate-800/80 border border-slate-700 text-slate-200 flex items-center gap-2">
                    <span className="text-amber-400">•</span> air dalam wadah berkurang ketika terkena panas.
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* SECTION 7: KALOR DALAM KEHIDUPAN SEHARI-HARI */}
          {activeSection === '7' && (
            <div className="bg-slate-900/90 rounded-2xl sm:rounded-3xl p-5 sm:p-7 border border-amber-500/40 shadow-xl space-y-6">
              <div className="border-b border-slate-800 pb-3 flex items-center justify-between">
                <div>
                  <span className="text-xs font-bold text-amber-400 uppercase tracking-wider">Bagian 7</span>
                  <h2 className="text-xl sm:text-2xl font-black text-white">7. Kalor dalam Kehidupan Sehari-hari</h2>
                </div>
                <div className="w-10 h-10 rounded-xl bg-red-600/30 text-amber-300 border border-red-500/40 flex items-center justify-center font-bold">
                  <Sun className="w-6 h-6 text-amber-400" />
                </div>
              </div>

              <p className="text-xs sm:text-sm text-slate-300">
                Berikut adalah kartu-kartu contoh peristiwa kalor dalam kehidupan sehari-hari:
              </p>

              {/* Kartu-Kartu Contoh Kehidupan Sehari-hari */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                {/* 1. Air dipanaskan */}
                <div className="p-4 rounded-2xl bg-slate-800/80 border border-amber-500/30 space-y-2 hover:border-amber-400 transition-colors shadow-sm">
                  <div className="w-9 h-9 rounded-xl bg-red-500/20 text-red-400 flex items-center justify-center font-bold text-lg">
                    🫖
                  </div>
                  <strong className="text-sm text-white block">Air dipanaskan</strong>
                  <p className="text-xs text-slate-300 leading-relaxed">
                    Kalor menyebabkan suhu air meningkat.
                  </p>
                </div>

                {/* 2. Es mencair */}
                <div className="p-4 rounded-2xl bg-slate-800/80 border border-amber-500/30 space-y-2 hover:border-amber-400 transition-colors shadow-sm">
                  <div className="w-9 h-9 rounded-xl bg-blue-500/20 text-cyan-300 flex items-center justify-center font-bold text-lg">
                    🧊
                  </div>
                  <strong className="text-sm text-white block">Es mencair</strong>
                  <p className="text-xs text-slate-300 leading-relaxed">
                    Kalor menyebabkan perubahan wujud.
                  </p>
                </div>

                {/* 3. Pakaian dijemur */}
                <div className="p-4 rounded-2xl bg-slate-800/80 border border-amber-500/30 space-y-2 hover:border-amber-400 transition-colors shadow-sm">
                  <div className="w-9 h-9 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center font-bold text-lg">
                    👕
                  </div>
                  <strong className="text-sm text-white block">Pakaian dijemur</strong>
                  <p className="text-xs text-slate-300 leading-relaxed">
                    Air menerima kalor dan menguap.
                  </p>
                </div>

                {/* 4. Keringat menguap */}
                <div className="p-4 rounded-2xl bg-slate-800/80 border border-amber-500/30 space-y-2 hover:border-amber-400 transition-colors shadow-sm">
                  <div className="w-9 h-9 rounded-xl bg-teal-500/20 text-teal-300 flex items-center justify-center font-bold text-lg">
                    🏃
                  </div>
                  <strong className="text-sm text-white block">Keringat menguap</strong>
                  <p className="text-xs text-slate-300 leading-relaxed">
                    Air pada kulit menyerap kalor untuk menguap.
                  </p>
                </div>

                {/* 5. Air mendidih */}
                <div className="p-4 rounded-2xl bg-slate-800/80 border border-amber-500/30 space-y-2 hover:border-amber-400 transition-colors shadow-sm">
                  <div className="w-9 h-9 rounded-xl bg-red-600/20 text-amber-400 flex items-center justify-center font-bold text-lg">
                    ♨️
                  </div>
                  <strong className="text-sm text-white block">Air mendidih</strong>
                  <p className="text-xs text-slate-300 leading-relaxed">
                    Kalor menyebabkan perubahan wujud cair → gas.
                  </p>
                </div>

                {/* 6. Air menjadi es */}
                <div className="p-4 rounded-2xl bg-slate-800/80 border border-amber-500/30 space-y-2 hover:border-amber-400 transition-colors shadow-sm">
                  <div className="w-9 h-9 rounded-xl bg-indigo-500/20 text-indigo-300 flex items-center justify-center font-bold text-lg">
                    ❄️
                  </div>
                  <strong className="text-sm text-white block">Air menjadi es</strong>
                  <p className="text-xs text-slate-300 leading-relaxed">
                    Air melepaskan kalor dan membeku.
                  </p>
                </div>

                {/* 7. Tutup gelas menjadi berembun */}
                <div className="p-4 rounded-2xl bg-slate-800/80 border border-amber-500/30 space-y-2 hover:border-amber-400 transition-colors shadow-sm sm:col-span-2 lg:col-span-1">
                  <div className="w-9 h-9 rounded-xl bg-cyan-500/20 text-cyan-300 flex items-center justify-center font-bold text-lg">
                    🍵
                  </div>
                  <strong className="text-sm text-white block">Tutup gelas menjadi berembun</strong>
                  <p className="text-xs text-slate-300 leading-relaxed">
                    Uap air melepaskan kalor dan mengembun.
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* SECTION 8: HAL PENTING YANG HARUS DIPAHAMI */}
          {activeSection === '8' && (
            <div className="bg-slate-900/90 rounded-2xl sm:rounded-3xl p-5 sm:p-7 border border-amber-500/40 shadow-xl space-y-6">
              <div className="border-b border-slate-800 pb-3 flex items-center justify-between">
                <div>
                  <span className="text-xs font-bold text-amber-400 uppercase tracking-wider">Bagian 8</span>
                  <h2 className="text-xl sm:text-2xl font-black text-white">8. Hal Penting yang Harus Dipahami</h2>
                </div>
                <div className="w-10 h-10 rounded-xl bg-red-600/30 text-amber-300 border border-red-500/40 flex items-center justify-center font-bold">
                  <Info className="w-6 h-6 text-amber-400" />
                </div>
              </div>

              <p className="text-xs sm:text-sm text-slate-300">
                Perbandingan visual dua kondisi mendasar pengaruh kalor pada materi:
              </p>

              {/* Dua Kartu Berdampingan */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Kondisi 1 */}
                <div className="p-5 rounded-2xl bg-gradient-to-br from-red-950/80 to-slate-900 border-2 border-red-500/60 space-y-3 shadow-lg">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-black uppercase tracking-wider text-red-400">Kondisi 1</span>
                    <span className="text-xl">🌡️</span>
                  </div>
                  <h3 className="text-base font-black text-white">
                    Ketika kalor menyebabkan perubahan suhu
                  </h3>
                  <div className="p-3 rounded-xl bg-black/50 border border-red-400/30 text-center font-mono font-black text-2xl text-amber-300">
                    Q = m · c · ΔT
                  </div>
                  <div className="p-3 rounded-lg bg-red-500/10 border border-red-500/30 text-red-200 text-xs font-bold text-center">
                    Suhu berubah, wujud tetap.
                  </div>
                  <div className="pt-2 border-t border-slate-800 text-xs text-slate-300">
                    <strong>Contoh:</strong> Air 25°C → 40°C
                  </div>
                </div>

                {/* Kondisi 2 */}
                <div className="p-5 rounded-2xl bg-gradient-to-br from-cyan-950/80 to-slate-900 border-2 border-cyan-500/60 space-y-3 shadow-lg">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-black uppercase tracking-wider text-cyan-400">Kondisi 2</span>
                    <span className="text-xl">🧊</span>
                  </div>
                  <h3 className="text-base font-black text-white">
                    Ketika kalor menyebabkan perubahan wujud
                  </h3>
                  <div className="p-3 rounded-xl bg-black/50 border border-cyan-400/30 text-center font-mono font-black text-2xl text-cyan-300">
                    Q = mL
                  </div>
                  <div className="p-3 rounded-lg bg-cyan-500/10 border border-cyan-500/30 text-cyan-200 text-xs font-bold text-center">
                    Wujud berubah, suhu tetap selama perubahan wujud berlangsung.
                  </div>
                  <div className="pt-2 border-t border-slate-800 text-xs text-slate-300">
                    <strong>Contoh:</strong> Es 0°C → air 0°C
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* KESIMPULAN */}
          {activeSection === 'kesimpulan' && (
            <div className="bg-slate-900/90 rounded-2xl sm:rounded-3xl p-5 sm:p-7 border-2 border-amber-400 shadow-2xl space-y-6">
              <div className="border-b border-slate-800 pb-3 flex items-center justify-between">
                <div>
                  <span className="text-xs font-bold text-amber-400 uppercase tracking-wider">Rangkuman Akhir</span>
                  <h2 className="text-2xl sm:text-3xl font-black text-white">Kesimpulan</h2>
                </div>
                <div className="w-10 h-10 rounded-xl bg-amber-400 text-red-950 flex items-center justify-center font-bold text-xl">
                  ✨
                </div>
              </div>

              {/* Teks Kesimpulan */}
              <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-r from-red-950 via-slate-900 to-amber-950 border border-amber-500/40 text-slate-100 space-y-2 text-sm sm:text-base leading-relaxed">
                <p>
                  <strong>Kalor</strong> adalah energi yang berpindah akibat perbedaan suhu. Kalor dapat menyebabkan
                  perubahan suhu atau perubahan wujud suatu zat.
                </p>
              </div>

              {/* Kartu Penutup / Highlight dengan Visual Sederhana */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="p-5 rounded-2xl bg-slate-800/90 border border-amber-400/50 space-y-2 text-center shadow-md">
                  <span className="text-xs font-bold text-amber-300 uppercase tracking-wide block">
                    Jika kalor menyebabkan perubahan suhu:
                  </span>
                  <div className="p-3 rounded-xl bg-black/40 text-2xl font-mono font-black text-white border border-amber-400/30">
                    Q = mcΔT
                  </div>
                  <p className="text-xs text-slate-300">
                    Terjadi pertambahan/pengurangan suhu molekul benda tanpa merombak fasa materi.
                  </p>
                </div>

                <div className="p-5 rounded-2xl bg-slate-800/90 border border-cyan-400/50 space-y-2 text-center shadow-md">
                  <span className="text-xs font-bold text-cyan-300 uppercase tracking-wide block">
                    Jika kalor menyebabkan perubahan wujud:
                  </span>
                  <div className="p-3 rounded-xl bg-black/40 text-2xl font-mono font-black text-white border border-cyan-400/30">
                    Q = mL
                  </div>
                  <p className="text-xs text-slate-300">
                    Energi kalor dipakai untuk merombak susunan partikel fasa materi pada suhu konstan.
                  </p>
                </div>
              </div>

              <div className="p-4 rounded-xl bg-amber-400/20 border border-amber-400/40 text-center text-xs sm:text-sm text-amber-200 font-semibold">
                🎉 Anda telah menyelesaikan seluruh rangkaian materi pembelajaran Suhu dan Kalor! Silakan catat poin penting Anda pada kolom refleksi di bawah.
              </div>
            </div>
          )}

          {/* Tombol Navigasi Bawah */}
          <div className="flex items-center justify-between pt-2">
            <button
              type="button"
              onClick={handlePrev}
              disabled={activeSection === '1'}
              className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white disabled:opacity-30 disabled:cursor-not-allowed text-xs sm:text-sm font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Sebelumnya</span>
            </button>

            <button
              type="button"
              onClick={handleNext}
              disabled={activeSection === 'kesimpulan'}
              className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-amber-400 to-amber-300 hover:from-amber-300 hover:to-amber-200 text-red-950 disabled:opacity-30 disabled:cursor-not-allowed text-xs sm:text-sm font-black flex items-center gap-1.5 transition-colors cursor-pointer shadow-md"
            >
              <span>Selanjutnya</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
