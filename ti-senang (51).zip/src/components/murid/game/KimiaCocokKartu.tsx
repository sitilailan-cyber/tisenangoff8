import React, { useState, useEffect } from 'react';
import {
  Trophy,
  RotateCcw,
  ArrowRight,
  CheckCircle2,
  Atom,
  X,
} from 'lucide-react';
import { joyfulGameMusic } from '../../../services/audio/joyfulGameMusic';

interface KimiaCocokKartuProps {
  onFinishGame: (score: number) => void;
  onBackToGameList?: () => void;
  onClose?: () => void;
}

interface CardItem {
  id: number;
  pairId: number;
  label: string;
  icon: string;
  isFlipped: boolean;
  isMatched: boolean;
}

const RAW_PAIRS = [
  { pairId: 1, textA: 'Proton (p⁺)', textB: 'Muatan +1 di dalam inti', icon: '🔴' },
  { pairId: 2, textA: 'Elektron (e⁻)', textB: 'Muatan -1 di kulit atom', icon: '⚡' },
  { pairId: 3, textA: 'Neutron (n⁰)', textB: 'Partikel netral tanpa muatan', icon: '⚪' },
  { pairId: 4, textA: 'Nomor Atom (Z)', textB: 'Jumlah proton inti atom', icon: '🔢' },
  { pairId: 5, textA: 'Nomor Massa (A)', textB: 'Total proton + neutron', icon: '⚖️' },
  { pairId: 6, textA: 'Isotop', textB: 'Z sama, A berbeda', icon: '🧬' },
  { pairId: 7, textA: 'Kulit Bohr', textB: 'Lintasan kuota 2n²', icon: '🪐' },
  { pairId: 8, textA: 'Elektron Valensi', textB: 'Elektron kulit terluar', icon: '⚛️' },
];

export const KimiaCocokKartu: React.FC<KimiaCocokKartuProps> = ({
  onFinishGame,
  onBackToGameList,
  onClose,
}) => {
  const [cards, setCards] = useState<CardItem[]>([]);
  const [flippedIds, setFlippedIds] = useState<number[]>([]);
  const [matchesCount, setMatchesCount] = useState<number>(0);
  const [turns, setTurns] = useState<number>(0);
  const [isFinished, setIsFinished] = useState<boolean>(false);

  const initDeck = () => {
    const deck: CardItem[] = [];
    let idCounter = 0;

    RAW_PAIRS.forEach((p) => {
      deck.push({
        id: idCounter++,
        pairId: p.pairId,
        label: p.textA,
        icon: p.icon,
        isFlipped: false,
        isMatched: false,
      });
      deck.push({
        id: idCounter++,
        pairId: p.pairId,
        label: p.textB,
        icon: '💡',
        isFlipped: false,
        isMatched: false,
      });
    });

    const shuffled = deck.sort(() => Math.random() - 0.5);
    setCards(shuffled);
    setFlippedIds([]);
    setMatchesCount(0);
    setTurns(0);
    setIsFinished(false);
  };

  useEffect(() => {
    initDeck();
  }, []);

  const handleCardClick = (id: number) => {
    if (flippedIds.length >= 2) return;
    const clickedCard = cards.find((c) => c.id === id);
    if (!clickedCard || clickedCard.isFlipped || clickedCard.isMatched) return;

    const newCards = cards.map((c) => (c.id === id ? { ...c, isFlipped: true } : c));
    setCards(newCards);

    const newFlipped = [...flippedIds, id];
    setFlippedIds(newFlipped);

    if (newFlipped.length === 2) {
      setTurns((t) => t + 1);
      const card1 = cards.find((c) => c.id === newFlipped[0])!;
      const card2 = clickedCard;

      if (card1.pairId === card2.pairId) {
        joyfulGameMusic.playCorrect();
        setTimeout(() => {
          setCards((prev) =>
            prev.map((c) =>
              c.pairId === card1.pairId ? { ...c, isMatched: true, isFlipped: true } : c
            )
          );
          setFlippedIds([]);
          const nextMatches = matchesCount + 1;
          setMatchesCount(nextMatches);
          if (nextMatches === RAW_PAIRS.length) {
            setIsFinished(true);
            joyfulGameMusic.playVictory();
          }
        }, 400);
      } else {
        joyfulGameMusic.playWrong();
        setTimeout(() => {
          setCards((prev) =>
            prev.map((c) => (newFlipped.includes(c.id) ? { ...c, isFlipped: false } : c))
          );
          setFlippedIds([]);
        }, 700);
      }
    }
  };

  return (
    <div className="w-full max-w-xl mx-auto rounded-2xl overflow-hidden shadow-xl border border-cyan-500/40 bg-slate-950 text-white font-sans text-xs">
      {/* Top Header Kompak */}
      <div className="px-2.5 py-1.5 bg-slate-900/90 border-b border-cyan-900/50 flex items-center justify-between gap-2">
        <div className="flex items-center gap-1.5 min-w-0">
          {onBackToGameList && (
            <button
              type="button"
              onClick={onBackToGameList}
              className="px-2 py-0.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-[10px] sm:text-[11px] font-bold transition-all flex items-center gap-1 border border-slate-700 cursor-pointer shrink-0"
            >
              ← <span>Game</span>
            </button>
          )}

          <div className="flex items-center gap-1 px-1.5 py-0.5 rounded-lg bg-cyan-500/20 border border-cyan-400/40 text-cyan-300 font-extrabold text-[10px] sm:text-[11px] truncate">
            <Atom className="w-3 h-3 text-cyan-400" />
            <span className="truncate">Cocok Kartu Atom</span>
          </div>
        </div>

        <div className="flex items-center gap-1.5 shrink-0 text-[10px] sm:text-[11px]">
          <div className="px-1.5 py-0.5 rounded-lg bg-slate-900 border border-cyan-800/60 text-cyan-300 font-bold">
            Cocok: <span className="font-mono font-black text-white">{matchesCount}/8</span>
          </div>
          <div className="px-1.5 py-0.5 rounded-lg bg-slate-900 border border-slate-800 text-slate-300 font-bold">
            Langkah: <span className="font-mono text-white">{turns}</span>
          </div>
          {(onClose || onBackToGameList) && (
            <button
              type="button"
              onClick={onClose || onBackToGameList}
              className="p-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700 transition-colors flex items-center justify-center cursor-pointer shrink-0"
              title="Tutup Game & Kembali ke Halaman Misi 4 Game Sains"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>

      {/* Content Area - 4x4 Grid Pas 1 Layar Tanpa Scroll */}
      {isFinished ? (
        <div className="p-3 sm:p-4 text-center space-y-2 animate-in fade-in zoom-in-95 duration-200">
          <div className="w-11 h-11 mx-auto rounded-xl bg-gradient-to-tr from-cyan-400 via-indigo-500 to-rose-400 p-0.5 shadow-md">
            <div className="w-full h-full bg-slate-950 rounded-[10px] flex items-center justify-center">
              <Trophy className="w-5 h-5 text-cyan-300" />
            </div>
          </div>

          <div className="space-y-0.5">
            <h2 className="text-sm sm:text-base font-black text-white">
              Semua Kartu Cocok! ⚛️🎉
            </h2>
            <p className="text-slate-300 text-[10px] sm:text-[11px] max-w-sm mx-auto">
              Kamu berhasil mencocokkan seluruh 8 pasang konsep Struktur Atom dalam {turns} langkah!
            </p>
          </div>

          <div className="flex items-center justify-center gap-2 pt-0.5">
            <button
              type="button"
              onClick={initDeck}
              className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-[11px] transition-all border border-slate-700 flex items-center justify-center gap-1 cursor-pointer"
            >
              <RotateCcw className="w-3 h-3" />
              <span>Acak Ulang</span>
            </button>
            <button
              type="button"
              onClick={() => onFinishGame(100)}
              className="px-3.5 py-1.5 rounded-lg bg-gradient-to-r from-cyan-500 via-blue-600 to-indigo-600 hover:from-cyan-600 hover:to-indigo-700 text-white font-black text-[11px] shadow-md flex items-center justify-center gap-1 transition-all active:scale-95 cursor-pointer"
            >
              <Trophy className="w-3 h-3 text-cyan-200" />
              <span>Selesaikan Misi & Buka Misi 5 dan Misi 6</span>
              <ArrowRight className="w-3 h-3" />
            </button>
          </div>
        </div>
      ) : (
        <div className="p-1.5 sm:p-2.5">
          {/* Grid 4x4 Muat 1 Layar Penuh Tanpa Scroll */}
          <div className="grid grid-cols-4 gap-1 sm:gap-1.5">
            {cards.map((card) => {
              const isOpen = card.isFlipped || card.isMatched;

              return (
                <div
                  key={card.id}
                  onClick={() => handleCardClick(card.id)}
                  className={`h-11 sm:h-13 md:h-15 rounded-lg sm:rounded-xl border transition-all duration-200 p-0.5 sm:p-1 flex flex-col justify-between cursor-pointer select-none text-center ${
                    card.isMatched
                      ? 'bg-emerald-950/80 border-emerald-400 text-emerald-200 shadow-xs opacity-90'
                      : isOpen
                      ? 'bg-gradient-to-br from-indigo-950 via-slate-900 to-cyan-950 border-cyan-400 text-white shadow-sm'
                      : 'bg-slate-900/90 hover:bg-slate-800 border-slate-700/80 hover:border-cyan-500/60 text-slate-400'
                  }`}
                >
                  {isOpen ? (
                    <div className="w-full h-full flex flex-col items-center justify-center gap-0.5 px-0.5">
                      <span className="text-[9px] sm:text-[11px] leading-none">{card.icon}</span>
                      <p className="text-[7.5px] sm:text-[9px] font-bold leading-tight line-clamp-2">
                        {card.label}
                      </p>
                      {card.isMatched && (
                        <CheckCircle2 className="w-2.5 h-2.5 text-emerald-400 shrink-0" />
                      )}
                    </div>
                  ) : (
                    <div className="w-full h-full flex flex-col items-center justify-center gap-0.5 opacity-60">
                      <Atom className="w-3.5 h-3.5 text-cyan-400" />
                      <span className="text-[7px] sm:text-[8px] font-mono font-bold tracking-wider text-slate-400">
                        ATOM
                      </span>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};
