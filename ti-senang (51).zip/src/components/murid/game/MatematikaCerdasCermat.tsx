import React, { useState } from 'react';
import {
  Trophy,
  RotateCcw,
  ArrowRight,
  CheckCircle2,
  XCircle,
  Zap,
  X,
} from 'lucide-react';
import { joyfulGameMusic } from '../../../services/audio/joyfulGameMusic';

interface MatematikaCerdasCermatProps {
  onFinishGame: (score: number) => void;
  onBackToGameList?: () => void;
  onClose?: () => void;
}

interface TriviaQuestion {
  id: number;
  question: string;
  context: string;
  options: string[];
  correct: number;
  explanation: string;
}

// 10 Soal disesuaikan persis dengan Materi Regresi Linear pada Misi 1 Pahami Konsep
// (Bagian A: Diagram Pencar, Bagian B: Regresi Linear, Bagian C: Arah Hubungan, Bagian D: Line of Best Fit, Bagian E: Persamaan y = a + bx)
const QUESTIONS: TriviaQuestion[] = [
  {
    id: 1,
    context: 'Bagian A: Diagram Pencar',
    question: 'Sumbu mendatar (X) pada diagram pencar data bivariat merepresentasikan...',
    options: ['Variabel Bebas (Independen)', 'Variabel Terikat (Dependen)', 'Variabel Acak Tak Berpola', 'Variabel Pengontrol Statis'],
    correct: 0,
    explanation: 'Variabel bebas diletakkan pada sumbu mendatar (X) yang memengaruhi variabel respons.',
  },
  {
    id: 2,
    context: 'Bagian A: Diagram Pencar',
    question: 'Sumbu tegak (Y) pada diagram pencar data bivariat merepresentasikan...',
    options: ['Variabel Terikat (Dependen)', 'Variabel Bebas (Independen)', 'Konstanta Skala Nol', 'Variabel Bebas Acak'],
    correct: 0,
    explanation: 'Variabel terikat diletakkan pada sumbu tegak (Y) yang nilainya dipengaruhi oleh variabel X.',
  },
  {
    id: 3,
    context: 'Bagian B: Regresi Linear',
    question: 'Diagram yang menampilkan sebaran pasangan data kuantitatif (x, y) dinamakan...',
    options: ['Diagram Pencar (Scatter Plot)', 'Diagram Batang Frekuensi', 'Diagram Lingkaran Pie', 'Piktogram Sebaran Relatif'],
    correct: 0,
    explanation: 'Diagram pencar memetakan hubungan dua variabel numerik dalam pasangan koordinat (x, y).',
  },
  {
    id: 4,
    context: 'Bagian B: Regresi Linear',
    question: 'Bentuk umum model persamaan regresi linear sederhana data bivariat adalah...',
    options: ['ŷ = a + bx', 'y = a · x²', 'y = a / (x + b)', 'y = a · bˣ'],
    correct: 0,
    explanation: 'Persamaan regresi linear dimodelkan dalam hubungan garis lurus ŷ = a + bx.',
  },
  {
    id: 5,
    context: 'Bagian C: Arah Hubungan Variabel',
    question: 'Jika jam belajar (X) bertambah dan nilai ujian (Y) meningkat searah tren ↗️, ini adalah...',
    options: ['Hubungan (Korelasi) Positif', 'Hubungan (Korelasi) Negatif', 'Tidak Ada Korelasi', 'Korelasi Berbalik Arah'],
    correct: 0,
    explanation: 'Korelasi positif terjadi saat nilai X bertambah, nilai Y juga ikut bertambah searah.',
  },
  {
    id: 6,
    context: 'Bagian C: Arah Hubungan Variabel',
    question: 'Jika durasi gadget (X) bertambah dan nilai (Y) justru menurun searah tren ↘️, ini adalah...',
    options: ['Hubungan (Korelasi) Negatif', 'Hubungan (Korelasi) Positif', 'Korelasi Searah Kuat', 'Hubungan Tak Terhingga'],
    correct: 0,
    explanation: 'Korelasi negatif terjadi saat nilai X bertambah, namun nilai Y justru mengalami penurunan.',
  },
  {
    id: 7,
    context: 'Bagian D: Line of Best Fit',
    question: 'Garis lurus terbaik yang meminimalkan total kuadrat galat titik-titik data disebut...',
    options: ['Line of Best Fit (Garis Terbaik)', 'Garis Asimtot Lengkung', 'Garis Batas Median', 'Garis Singgung Tangen'],
    correct: 0,
    explanation: 'Line of best fit adalah garis lurus yang meminimalkan jumlah kuadrat galat titik data (metode kuadrat terkecil).',
  },
  {
    id: 8,
    context: 'Bagian D: Line of Best Fit',
    question: 'Menaksir nilai ŷ untuk nilai x yang berada di dalam rentang data observasi disebut...',
    options: ['Interpolasi', 'Ekstrapolasi', 'Randomisasi Sampel', 'Normalisasi Skala'],
    correct: 0,
    explanation: 'Interpolasi adalah estimasi nilai di dalam rentang rentang data sampel yang telah diobservasi.',
  },
  {
    id: 9,
    context: 'Bagian E: Persamaan ŷ = a + bx',
    question: 'Pada persamaan regresi ŷ = a + bx, nilai konstanta "a" merepresentasikan...',
    options: ['Nilai taksiran ŷ saat nilai x = 0 (Intersep)', 'Kemiringan garis regresi', 'Jumlah sampel pengamatan', 'Rata-rata galat residu'],
    correct: 0,
    explanation: 'Konstanta a adalah titik potong sumbu Y (intersep), yaitu nilai taksiran ŷ saat variabel bebas x = 0.',
  },
  {
    id: 10,
    context: 'Bagian E: Persamaan ŷ = a + bx',
    question: 'Pada persamaan regresi ŷ = a + bx, nilai koefisien regresi "b" merepresentasikan...',
    options: ['Kemiringan garis (Gradien / Slope)', 'Titik potong garis pada sumbu Y', 'Selisih rentang nilai x', 'Nilai maksimum data y'],
    correct: 0,
    explanation: 'Koefisien b adalah gradien kemiringan garis yang menyatakan laju perubahan nilai ŷ per satuan nilai x.',
  },
];

export const MatematikaCerdasCermat: React.FC<MatematikaCerdasCermatProps> = ({
  onFinishGame,
  onBackToGameList,
  onClose,
}) => {
  const [currentIdx, setCurrentIdx] = useState<number>(0);
  const [score, setScore] = useState<number>(0);
  const [streak, setStreak] = useState<number>(0);
  const [selectedOpt, setSelectedOpt] = useState<number | null>(null);
  const [isAnswered, setIsAnswered] = useState<boolean>(false);
  const [isFinished, setIsFinished] = useState<boolean>(false);

  const currentQ = QUESTIONS[currentIdx];

  const handleAnswer = (idx: number) => {
    if (isAnswered || isFinished) return;
    setSelectedOpt(idx);
    setIsAnswered(true);

    const isCorrect = idx === currentQ.correct;
    if (isCorrect) {
      joyfulGameMusic.playCorrect();
      const bonus = streak * 5;
      setScore((prev) => prev + 10 + bonus);
      setStreak((prev) => prev + 1);
    } else {
      joyfulGameMusic.playWrong();
      setStreak(0);
    }
  };

  const handleNext = () => {
    if (currentIdx + 1 < QUESTIONS.length) {
      setCurrentIdx((prev) => prev + 1);
      setSelectedOpt(null);
      setIsAnswered(false);
    } else {
      setIsFinished(true);
      joyfulGameMusic.playVictory();
    }
  };

  const handleRestart = () => {
    setCurrentIdx(0);
    setScore(0);
    setStreak(0);
    setSelectedOpt(null);
    setIsAnswered(false);
    setIsFinished(false);
  };

  return (
    <div className="w-full max-w-xl mx-auto rounded-2xl overflow-hidden shadow-xl border border-indigo-500/40 bg-slate-950 text-white font-sans text-xs">
      {/* Top Header - Sangat Ringkas, Ikon Suara / Gambar Suara Dihapus */}
      <div className="px-2.5 py-1.5 bg-slate-900/90 border-b border-indigo-900/50 flex items-center justify-between gap-2">
        <div className="flex items-center gap-1.5 min-w-0">
          {onBackToGameList && (
            <button
              type="button"
              onClick={onBackToGameList}
              className="px-2 py-0.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-[10px] sm:text-[11px] font-bold transition-all flex items-center gap-1 border border-slate-700 cursor-pointer shrink-0"
            >
              ← <span>Game</span>
            </button>
          )}

          <div className="flex items-center gap-1 px-1.5 py-0.5 rounded-lg bg-indigo-500/20 border border-indigo-400/40 text-indigo-300 font-extrabold text-[10px] sm:text-[11px] truncate">
            <span>📐</span>
            <span className="truncate">Cerdas Cermat Regresi</span>
          </div>
        </div>

        {/* Skor Bersih & Tombol Tutup Game (Kembali ke Halaman Misi 4 Game Sains) */}
        <div className="flex items-center gap-1.5 shrink-0">
          <div className="px-2 py-0.5 rounded-lg bg-slate-900 border border-indigo-800/60 text-amber-300 font-bold text-[10px] sm:text-[11px]">
            Skor: <span className="font-mono font-black text-white">{score}</span>
          </div>
          {(onClose || onBackToGameList) && (
            <button
              type="button"
              onClick={onClose || onBackToGameList}
              className="p-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700 transition-colors flex items-center justify-center cursor-pointer shrink-0"
              title="Tutup Game & Kembali ke Halaman Misi 4 Game Sains"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>

      {/* Progress Bar Tipis */}
      <div className="w-full bg-slate-900 h-1 relative">
        <div
          className="h-full bg-gradient-to-r from-indigo-500 to-cyan-400 transition-all duration-300"
          style={{ width: `${((currentIdx + 1) / QUESTIONS.length) * 100}%` }}
        />
      </div>

      {/* Game Content - Ukuran Kotak & Tulisan Diperkecil Agar Tanpa Scroll di Handphone, Tab & Laptop */}
      {isFinished ? (
        <div className="p-3 sm:p-4 text-center space-y-2 animate-in fade-in zoom-in-95 duration-200">
          <div className="w-11 h-11 mx-auto rounded-xl bg-gradient-to-tr from-indigo-500 via-cyan-400 to-amber-400 p-0.5 shadow-md">
            <div className="w-full h-full bg-slate-950 rounded-[10px] flex items-center justify-center">
              <Trophy className="w-5 h-5 text-amber-400" />
            </div>
          </div>

          <div className="space-y-0.5">
            <h2 className="text-sm sm:text-base font-black text-white">
              Cerdas Cermat Selesai! 🎉
            </h2>
            <p className="text-slate-300 text-[10px] sm:text-[11px] max-w-sm mx-auto">
              Kamu telah menuntaskan 10 soal konsep materi Regresi Linear!
            </p>
          </div>

          <div className="max-w-xs mx-auto p-2 rounded-xl bg-slate-900/80 border border-indigo-800/60 flex items-center justify-around text-center">
            <div>
              <p className="text-[8.5px] font-bold text-slate-400 uppercase">Total Skor</p>
              <p className="text-base font-black text-amber-300 font-mono">{score}</p>
            </div>
            <div className="h-5 w-px bg-slate-700" />
            <div>
              <p className="text-[8.5px] font-bold text-slate-400 uppercase">Soal Selesai</p>
              <p className="text-base font-black text-emerald-400 font-mono">10/10</p>
            </div>
          </div>

          <div className="flex items-center justify-center gap-2 pt-0.5">
            <button
              type="button"
              onClick={handleRestart}
              className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-[11px] transition-all border border-slate-700 flex items-center justify-center gap-1 cursor-pointer"
            >
              <RotateCcw className="w-3 h-3" />
              <span>Ulangi</span>
            </button>
            <button
              type="button"
              onClick={() => onFinishGame(100)}
              className="px-3.5 py-1.5 rounded-lg bg-gradient-to-r from-indigo-500 via-indigo-600 to-cyan-500 hover:from-indigo-600 hover:to-cyan-600 text-white font-black text-[11px] shadow-md flex items-center justify-center gap-1 transition-all active:scale-95 cursor-pointer"
            >
              <Trophy className="w-3 h-3 text-amber-300" />
              <span>Selesaikan Misi & Buka Misi 5 dan Misi 6</span>
              <ArrowRight className="w-3 h-3" />
            </button>
          </div>
        </div>
      ) : (
        <div className="p-2 sm:p-2.5 space-y-1.5 sm:space-y-2">
          {/* Baris Status Soal */}
          <div className="flex items-center justify-between text-[9px] sm:text-[10px] text-slate-400">
            <span className="font-extrabold text-indigo-400 uppercase tracking-wider truncate">
              {currentQ.context}
            </span>
            <span className="px-1.5 py-0.5 rounded-md bg-slate-900 border border-slate-800 font-mono font-bold text-slate-300 shrink-0">
              {currentIdx + 1}/10
            </span>
          </div>

          {/* Kotak Pertanyaan Kompak */}
          <div className="p-2 sm:p-2.5 rounded-xl bg-slate-900/90 border border-indigo-900/60 shadow-xs">
            <h3 className="text-[11px] sm:text-xs font-bold text-white leading-snug">
              {currentQ.question}
            </h3>
          </div>

          {/* 4 Pilihan Jawaban Kompak & Fleksibel */}
          <div className="grid grid-cols-1 gap-1">
            {currentQ.options.map((opt, i) => {
              const isSelected = selectedOpt === i;
              const isCorrectOpt = i === currentQ.correct;

              let btnStyle = 'bg-slate-900/80 hover:bg-slate-800 border-slate-800 text-slate-200';
              if (isAnswered) {
                if (isCorrectOpt) {
                  btnStyle = 'bg-emerald-600/90 border-emerald-400 text-white font-bold ring-1 ring-emerald-400/50';
                } else if (isSelected) {
                  btnStyle = 'bg-rose-600/90 border-rose-400 text-white font-bold ring-1 ring-rose-400/50';
                } else {
                  btnStyle = 'bg-slate-900/30 border-slate-800/60 text-slate-500';
                }
              }

              return (
                <button
                  key={i}
                  type="button"
                  disabled={isAnswered}
                  onClick={() => handleAnswer(i)}
                  className={`w-full py-1 sm:py-1.5 px-2 sm:px-2.5 rounded-lg sm:rounded-xl border transition-all flex items-center gap-1.5 sm:gap-2 text-left cursor-pointer active:scale-98 ${btnStyle}`}
                >
                  <span className="w-4 h-4 rounded bg-black/40 border border-white/10 flex items-center justify-center text-[9px] font-black shrink-0">
                    {String.fromCharCode(65 + i)}
                  </span>
                  <span className="text-[10px] sm:text-[11px] font-medium flex-1 leading-tight">
                    {opt}
                  </span>
                  {isAnswered && isCorrectOpt && (
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-300 shrink-0" />
                  )}
                  {isAnswered && isSelected && !isCorrectOpt && (
                    <XCircle className="w-3.5 h-3.5 text-rose-300 shrink-0" />
                  )}
                </button>
              );
            })}
          </div>

          {/* Penjelasan Singkat & Tombol Lanjut */}
          {isAnswered && (
            <div className="p-1.5 sm:p-2 rounded-lg sm:rounded-xl bg-slate-900/90 border border-indigo-900/80 flex items-center justify-between gap-1.5 animate-in fade-in duration-150">
              <p className="text-[9.5px] sm:text-[10.5px] text-slate-300 leading-tight flex-1 line-clamp-2">
                <span className="font-bold text-cyan-400">💡 Info: </span>
                {currentQ.explanation}
              </p>
              <button
                type="button"
                onClick={handleNext}
                className="px-2.5 py-1 rounded-md bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-[10px] sm:text-[11px] shadow-xs transition-all flex items-center gap-1 cursor-pointer shrink-0 active:scale-95"
              >
                <span>{currentIdx + 1 === QUESTIONS.length ? 'Selesai' : 'Lanjut'}</span>
                <ArrowRight className="w-3 h-3" />
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
