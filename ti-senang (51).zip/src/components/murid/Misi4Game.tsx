import React, { useState, useEffect } from 'react';
import {
  Gamepad2,
  Trophy,
  CheckCircle2,
  ExternalLink,
  ArrowRight,
  Volume2,
  VolumeX,
  ChevronDown,
  ChevronUp,
  Check,
  X,
} from 'lucide-react';
import { Mission } from '../../types';
import { storage } from '../../services/storage';
import { joyfulGameMusic } from '../../services/audio/joyfulGameMusic';
import { MatematikaCerdasCermat } from './game/MatematikaCerdasCermat';
import { MatematikaCocokKartu } from './game/MatematikaCocokKartu';
import { FisikaLabirinKalor } from './game/FisikaLabirinKalor';
import { KimiaCocokKartu } from './game/KimiaCocokKartu';
import { BiologiBalapanPewarisan } from './game/BiologiBalapanPewarisan';

interface Misi4GameProps {
  studentId: string;
  studentName?: string;
  missionId: string;
  mission?: Mission;
  activeGameId?: string | null;
  onActiveGameChange?: (gameId: string | null) => void;
  onCompleted?: () => void;
  onNextMission?: (nextMissionNumber: number) => void;
  onClose?: () => void;
}

export type SubjectOption = 'semua' | 'matematika' | 'fisika' | 'kimia' | 'biologi';

export interface SubjectItem {
  id: SubjectOption;
  name: string;
  icon: string;
}

export const SUBJECT_OPTIONS: SubjectItem[] = [
  { id: 'semua', name: 'Semua', icon: '🌟' },
  { id: 'matematika', name: 'Matematika', icon: '📐' },
  { id: 'fisika', name: 'Fisika', icon: '⚡' },
  { id: 'kimia', name: 'Kimia', icon: '⚗️' },
  { id: 'biologi', name: 'Biologi', icon: '🌿' },
];

export interface GameCoverItem {
  id: string;
  subject: SubjectOption;
  title: string;
  subtitle: string;
  badge: string;
  icon: string;
  tag: string;
  accentColor: string;
}

export const Misi4Game: React.FC<Misi4GameProps> = ({
  studentId,
  missionId,
  mission,
  activeGameId: controlledActiveGameId,
  onActiveGameChange,
  onCompleted,
  onNextMission,
  onClose,
}) => {
  const hasTeacherLink = !!(mission?.gameUrl && mission.gameUrl.trim().length > 0);

  // Default saat masuk: tampilkan semua game ('semua')
  const [selectedSubject, setSelectedSubject] = useState<SubjectOption>('semua');
  const [isSubjectDropdownOpen, setIsSubjectDropdownOpen] = useState<boolean>(false);
  const [internalActiveGameId, setInternalActiveGameId] = useState<string | null>(null);

  const activeGameId = controlledActiveGameId !== undefined ? controlledActiveGameId : internalActiveGameId;

  const setActiveGameId = (gameId: string | null) => {
    setInternalActiveGameId(gameId);
    if (onActiveGameChange) {
      onActiveGameChange(gameId);
    }
  };

  // Completion State
  const [hasPlayed, setHasPlayed] = useState<boolean>(false);
  const [gameScore, setGameScore] = useState<number>(0);
  const [isMissionFinished, setIsMissionFinished] = useState<boolean>(false);
  const [isMuted, setIsMuted] = useState<boolean>(joyfulGameMusic.getIsMuted());

  // Musik latar belakang saat masuk ke misi game
  useEffect(() => {
    joyfulGameMusic.start();
    const unsub = joyfulGameMusic.subscribe((_, muted) => {
      setIsMuted(muted);
    });

    return () => {
      joyfulGameMusic.stop();
      unsub();
    };
  }, []);

  const handleToggleMusic = () => {
    const nextMuted = joyfulGameMusic.toggleMute();
    setIsMuted(nextMuted);
  };

  // Selesai bermain game -> otomatis buka Misi 5 dan Misi 6
  const handleFinishMissionGame = (overrideScore?: number) => {
    const finalScore = overrideScore || (gameScore > 0 ? gameScore : 100);
    setGameScore(finalScore);
    setHasPlayed(true);
    setIsMissionFinished(true);

    storage.completeMission(studentId, missionId, finalScore, mission?.xpReward || 100);

    // Kirim event agar MuridDashboard dan MissionJourney langsung membuka Misi 5 dan Misi 6
    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent('tisenang_missions_updated'));
    }

    if (onCompleted) {
      onCompleted();
    }
  };

  // =========================================================================
  // JIKA SEDANG MEMILIH GAME AKTIF: TAMPILKAN LANGSUNG 1 LAYAR TANPA SCROLL
  // =========================================================================
  if (activeGameId === 'matematika_cerdas_cermat') {
    return (
      <div className="w-full max-w-xl mx-auto py-0.5 sm:py-1 px-0 sm:px-1">
        <MatematikaCerdasCermat
          onFinishGame={(score) => {
            handleFinishMissionGame(score);
            if (onNextMission) {
              joyfulGameMusic.stop();
              onNextMission(5);
            }
          }}
          onBackToGameList={() => setActiveGameId(null)}
          onClose={() => setActiveGameId(null)}
        />
      </div>
    );
  }

  if (activeGameId === 'matematika_cocok_kartu') {
    return (
      <div className="w-full max-w-xl mx-auto py-0.5 sm:py-1 px-0 sm:px-1">
        <MatematikaCocokKartu
          onFinishGame={(score) => {
            handleFinishMissionGame(score);
            if (onNextMission) {
              joyfulGameMusic.stop();
              onNextMission(5);
            }
          }}
          onBackToGameList={() => setActiveGameId(null)}
          onClose={() => setActiveGameId(null)}
        />
      </div>
    );
  }

  if (activeGameId === 'fisika_kalor') {
    return (
      <div className="w-full max-w-xl mx-auto py-0.5 sm:py-1 px-0 sm:px-1">
        <FisikaLabirinKalor
          onFinishGame={(score) => {
            handleFinishMissionGame(score);
            if (onNextMission) {
              joyfulGameMusic.stop();
              onNextMission(5);
            }
          }}
          onBackToGameList={() => setActiveGameId(null)}
          onClose={() => setActiveGameId(null)}
        />
      </div>
    );
  }

  if (activeGameId === 'kimia_ikatan') {
    return (
      <div className="w-full max-w-xl mx-auto py-0.5 sm:py-1 px-0 sm:px-1">
        <KimiaCocokKartu
          onFinishGame={(score) => {
            handleFinishMissionGame(score);
            if (onNextMission) {
              joyfulGameMusic.stop();
              onNextMission(5);
            }
          }}
          onBackToGameList={() => setActiveGameId(null)}
          onClose={() => setActiveGameId(null)}
        />
      </div>
    );
  }

  if (activeGameId === 'biologi_sel') {
    return (
      <div className="w-full max-w-xl mx-auto py-0.5 sm:py-1 px-0 sm:px-1">
        <BiologiBalapanPewarisan
          onFinishGame={(score) => {
            handleFinishMissionGame(score);
            if (onNextMission) {
              joyfulGameMusic.stop();
              onNextMission(5);
            }
          }}
          onBackToGameList={() => setActiveGameId(null)}
          onClose={() => setActiveGameId(null)}
        />
      </div>
    );
  }

  if (activeGameId === 'teacher_link' && mission?.gameUrl) {
    return (
      <div className="w-full max-w-xl mx-auto p-5 bg-slate-900 rounded-2xl border border-slate-700 text-center space-y-4 text-white relative">
        <button
          type="button"
          onClick={() => setActiveGameId(null)}
          className="absolute top-3 right-3 p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700 transition-colors cursor-pointer"
          title="Tutup Game & Kembali ke Halaman Misi 4 Game Sains"
        >
          <X className="w-4 h-4" />
        </button>
        <h3 className="text-base font-bold text-white">Tautan Game Guru</h3>
        <p className="text-xs text-slate-300">
          Guru menyediakan tautan permainan edukatif eksternal untuk materi ini:
        </p>
        <div className="flex items-center justify-center gap-3">
          <a
            href={mission.gameUrl}
            target="_blank"
            rel="noopener noreferrer"
            onClick={() => handleFinishMissionGame(100)}
            className="px-5 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs flex items-center gap-2 shadow-lg"
          >
            <span>Buka Game</span>
            <ExternalLink className="w-4 h-4" />
          </a>
          <button
            type="button"
            onClick={() => setActiveGameId(null)}
            className="px-4 py-2.5 rounded-xl bg-slate-800 text-slate-300 font-bold text-xs cursor-pointer"
          >
            Kembali
          </button>
        </div>
      </div>
    );
  }

  const currentSubjectObj =
    SUBJECT_OPTIONS.find((s) => s.id === selectedSubject) || SUBJECT_OPTIONS[0];

  // Daftar Cover-Cover Game Edukasi Berdasarkan Mata Pelajaran
  const allGameCovers: GameCoverItem[] = [
    {
      id: 'matematika_cerdas_cermat',
      subject: 'matematika',
      title: 'Regresi Linear : Cerdas Cermat',
      subtitle: 'Tantangan 10 soal cerdas cermat regresi linear, scatter plot, dan korelasi.',
      badge: 'Matematika SMA',
      icon: '📐',
      tag: 'Cerdas Cermat',
      accentColor: 'from-indigo-950 via-slate-900 to-indigo-900 border-indigo-500/60',
    },
    {
      id: 'matematika_cocok_kartu',
      subject: 'matematika',
      title: 'Regresi Linear : Mencocokkan Kartu',
      subtitle: 'Permainan mencocokkan pasangan konsep variabel, diagram pencar, dan garis regresi.',
      badge: 'Matematika SMA',
      icon: '📊',
      tag: 'Cocok Kartu',
      accentColor: 'from-indigo-950 via-blue-950 to-slate-950 border-indigo-500/60',
    },
    {
      id: 'fisika_kalor',
      subject: 'fisika',
      title: 'Suhu dan Kalor : Labirin 10 Soal Dikejar Emot Api',
      subtitle: 'Tantangan 10 pos labirin konsep kalor dan Asas Black sambil menghindar dari kejaran emot api 🔥.',
      badge: 'Fisika SMA',
      icon: '🔥',
      tag: 'Labirin Api',
      accentColor: 'from-orange-950 via-red-950 to-slate-950 border-orange-500/60',
    },
    {
      id: 'kimia_ikatan',
      subject: 'kimia',
      title: 'Struktur Atom : Mencocokkan Kartu',
      subtitle: 'Permainan membalik dan mencocokkan kartu partikel atom, proton, elektron, dan nomor atom.',
      badge: 'Kimia SMA',
      icon: '⚛️',
      tag: 'Cocok Kartu',
      accentColor: 'from-cyan-950 via-blue-950 to-slate-950 border-cyan-500/60',
    },
    {
      id: 'biologi_sel',
      subject: 'biologi',
      title: 'Pewarisan Sifat : Balapan Menjawab 2 Pemain',
      subtitle: 'Adu cepat dan tepat menjawab konsep genetika Mendel dalam balapan DNA 2 pemain.',
      badge: 'Biologi SMA',
      icon: '🧬',
      tag: 'Balapan 2 Pemain',
      accentColor: 'from-emerald-950 via-teal-950 to-slate-950 border-emerald-500/60',
    },
    ...(hasTeacherLink
      ? [
          {
            id: 'teacher_link',
            subject: 'fisika' as SubjectOption,
            title: 'Tautan Game Edukasi Guru',
            subtitle: mission?.title ? `Game materi: ${mission.title}` : 'Game pilihan langsung dari guru pengampu.',
            badge: 'Tautan Guru',
            icon: '🔗',
            tag: 'Web Game',
            accentColor: 'from-purple-950 via-pink-950 to-slate-950 border-purple-500/60',
          },
        ]
      : []),
  ];

  const displayedGames =
    selectedSubject === 'semua'
      ? allGameCovers
      : allGameCovers.filter((g) => g.subject === selectedSubject);

  return (
    <div className="max-w-4xl mx-auto space-y-4 sm:space-y-6">
      {/* Header Banner - Responsive & Tidak Terpotong di Handphone */}
      <div className="bg-gradient-to-r from-pink-600 via-rose-600 to-amber-600 rounded-3xl p-4 sm:p-5 text-white shadow-lg relative overflow-hidden">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 sm:gap-4">
          <div className="flex flex-wrap items-center gap-2 min-w-0">
            <div className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white/20 text-xs font-bold uppercase tracking-wider shrink-0 whitespace-nowrap">
              <Gamepad2 className="w-3.5 h-3.5" />
              <span>Misi 4 • Game Edukasi</span>
            </div>

            {/* Background Music Toggle */}
            <button
              type="button"
              onClick={handleToggleMusic}
              title={isMuted ? 'Nyalakan Musik' : 'Senyapkan Musik'}
              className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-white/25 hover:bg-white/35 backdrop-blur border border-white/40 text-xs font-bold transition-all cursor-pointer shadow-xs active:scale-95 shrink-0 whitespace-nowrap"
            >
              {isMuted ? (
                <>
                  <VolumeX className="w-3.5 h-3.5 text-amber-200" />
                  <span className="text-amber-100">Musik: Senyap</span>
                </>
              ) : (
                <>
                  <Volume2 className="w-3.5 h-3.5 text-emerald-300 animate-pulse" />
                  <span className="text-emerald-100 flex items-center gap-1">
                    <span>Musik</span>
                    <span className="flex items-end gap-0.5 h-2.5">
                      <span className="w-0.5 h-1.5 bg-emerald-300 rounded animate-bounce" />
                      <span className="w-0.5 h-2.5 bg-emerald-300 rounded animate-bounce delay-100" />
                      <span className="w-0.5 h-1.5 bg-emerald-300 rounded animate-bounce delay-200" />
                    </span>
                  </span>
                </>
              )}
            </button>
          </div>

          <div className="self-start sm:self-auto shrink-0">
            <span className="px-3.5 py-1.5 rounded-full text-xs font-bold bg-white/20 backdrop-blur border border-white/30 text-white shadow-xs shrink-0 whitespace-nowrap inline-block">
              +{mission?.xpReward || 100} XP Reward
            </span>
          </div>
        </div>
      </div>

      {/* 1. KOTAK PILIH MATA PELAJARAN (Dropdown tanda panah: Semua, Matematika, Fisika, Kimia, Biologi) */}
      <div className="relative">
        <div className="w-full bg-sky-100 text-sky-950 rounded-2xl p-3 sm:p-4 border-2 border-yellow-400 shadow-md flex items-center justify-between gap-3">
          <div className="flex items-center gap-2.5 sm:gap-3 min-w-0">
            <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-xl bg-white border border-yellow-400/80 flex items-center justify-center text-lg sm:text-xl shrink-0 shadow-xs">
              {currentSubjectObj.icon}
            </div>
            <div className="min-w-0">
              <h4 className="text-sm sm:text-base font-extrabold text-sky-950 leading-snug">
                Pilih Mata Pelajaran
              </h4>
            </div>
          </div>

          {/* Tombol Panah untuk membuka dropdown tulisan saja */}
          <div className="relative">
            <button
              type="button"
              id="btn-dropdown-pilih-mapel-game"
              onClick={() => setIsSubjectDropdownOpen((prev) => !prev)}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-white hover:bg-yellow-100 border border-yellow-400 text-xs sm:text-sm font-bold text-sky-950 shadow-xs transition-colors cursor-pointer"
            >
              <span>{currentSubjectObj.name}</span>
              {isSubjectDropdownOpen ? (
                <ChevronUp className="w-4 h-4 text-sky-950 shrink-0" />
              ) : (
                <ChevronDown className="w-4 h-4 text-sky-950 shrink-0" />
              )}
            </button>

            {/* Dropdown Menu TULISAN SAJA muncul dari arah panah yang diklik */}
            {isSubjectDropdownOpen && (
              <div className="absolute right-0 top-full mt-1.5 w-48 sm:w-56 bg-white border-2 border-yellow-400 rounded-xl shadow-2xl z-30 py-1 overflow-hidden animate-in fade-in slide-in-from-top-2 duration-150">
                {SUBJECT_OPTIONS.map((subj) => {
                  const isSelected = selectedSubject === subj.id;
                  return (
                    <button
                      key={subj.id}
                      type="button"
                      onClick={() => {
                        setSelectedSubject(subj.id);
                        setActiveGameId(null);
                        setIsSubjectDropdownOpen(false);
                      }}
                      className={`w-full text-left px-3.5 py-2.5 text-xs sm:text-sm transition-colors flex items-center justify-between cursor-pointer ${
                        isSelected
                          ? 'bg-yellow-200 text-sky-950 font-black'
                          : 'text-slate-800 hover:bg-sky-50 font-semibold'
                      }`}
                    >
                      <span className="flex items-center gap-2">
                        <span>{subj.icon}</span>
                        <span>{subj.name}</span>
                      </span>
                      {isSelected && <Check className="w-4 h-4 text-sky-950 shrink-0" />}
                    </button>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* 2. GALERI COVER-COVER GAME (Ukuran kotak proporsional & tidak terlalu besar) */}
      <div className="bg-slate-900/90 rounded-2xl sm:rounded-3xl p-4 sm:p-5 border border-slate-700/80 shadow-xl space-y-4">
        <div className="border-b border-slate-800 pb-3 flex items-center justify-between gap-3">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-xl bg-gradient-to-br from-pink-500 to-rose-600 text-white flex items-center justify-center font-black shadow-md text-lg sm:text-xl shrink-0">
              🎮
            </div>
            <div className="min-w-0">
              <h3 className="text-sm sm:text-base font-black text-white">
                {selectedSubject === 'semua' ? 'Semua Game' : `Game ${currentSubjectObj.name}`}
              </h3>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-2.5 sm:gap-3.5">
          {displayedGames.map((g) => (
            <div
              key={g.id}
              onClick={() => {
                if (g.id === 'teacher_link' && mission?.gameUrl) {
                  window.open(mission.gameUrl, '_blank');
                  handleFinishMissionGame(100);
                } else {
                  setActiveGameId(g.id);
                }
              }}
              className="group bg-slate-900 rounded-2xl border border-slate-700/80 hover:border-yellow-400 p-2.5 sm:p-3 flex flex-col justify-between transition-all cursor-pointer hover:shadow-xl hover:-translate-y-1 shadow-md"
            >
              {/* Visual Cover Bergambar */}
              <div className={`w-full h-28 sm:h-32 rounded-xl relative overflow-hidden bg-gradient-to-b ${g.accentColor} p-2.5 flex flex-col justify-between border shadow-inner`}>
                {g.id === 'matematika_cerdas_cermat' ? (
                  <svg className="absolute inset-0 w-full h-full opacity-40" preserveAspectRatio="none" viewBox="0 0 100 100">
                    <line x1="10" y1="90" x2="90" y2="90" stroke="#818cf8" strokeWidth="1" />
                    <line x1="10" y1="90" x2="10" y2="10" stroke="#818cf8" strokeWidth="1" />
                    <line x1="10" y1="80" x2="90" y2="20" stroke="#facc15" strokeWidth="2.5" />
                    <circle cx="25" cy="70" r="3" fill="#60a5fa" />
                    <circle cx="45" cy="52" r="3" fill="#38bdf8" />
                    <circle cx="65" cy="38" r="3" fill="#60a5fa" />
                    <circle cx="80" cy="26" r="3" fill="#facc15" />
                  </svg>
                ) : g.id === 'matematika_cocok_kartu' ? (
                  <svg className="absolute inset-0 w-full h-full opacity-40" preserveAspectRatio="none" viewBox="0 0 100 100">
                    <rect x="15" y="20" width="30" height="40" rx="4" fill="none" stroke="#818cf8" strokeWidth="1.5" />
                    <rect x="55" y="40" width="30" height="40" rx="4" fill="none" stroke="#60a5fa" strokeWidth="1.5" />
                    <path d="M 25,40 L 35,40" stroke="#facc15" strokeWidth="2" />
                    <path d="M 65,60 L 75,60" stroke="#38bdf8" strokeWidth="2" />
                  </svg>
                ) : g.id === 'fisika_kalor' ? (
                  <svg className="absolute inset-0 w-full h-full opacity-45" preserveAspectRatio="none" viewBox="0 0 100 100">
                    <rect x="15" y="15" width="70" height="70" rx="8" fill="none" stroke="#ea580c" strokeWidth="1.5" strokeDasharray="4,2" />
                    <path d="M 25,25 L 75,25 L 75,75 L 45,75" fill="none" stroke="#f97316" strokeWidth="2" />
                    <circle cx="35" cy="35" r="5" fill="#38bdf8" />
                    <path d="M 65,65 Q 70,55 65,50 Q 60,55 65,65 Z" fill="#ef4444" />
                  </svg>
                ) : g.id === 'kimia_ikatan' ? (
                  <svg className="absolute inset-0 w-full h-full opacity-40" preserveAspectRatio="none" viewBox="0 0 100 100">
                    <ellipse cx="50" cy="50" rx="35" ry="12" fill="none" stroke="#06b6d4" strokeWidth="1.5" transform="rotate(-30 50 50)" />
                    <ellipse cx="50" cy="50" rx="35" ry="12" fill="none" stroke="#3b82f6" strokeWidth="1.5" transform="rotate(30 50 50)" />
                    <circle cx="50" cy="50" r="6" fill="#06b6d4" />
                    <circle cx="20" cy="35" r="2.5" fill="#e0f2fe" />
                    <circle cx="80" cy="65" r="2.5" fill="#e0f2fe" />
                  </svg>
                ) : g.id === 'biologi_sel' ? (
                  <svg className="absolute inset-0 w-full h-full opacity-40" preserveAspectRatio="none" viewBox="0 0 100 100">
                    <path d="M 20,20 Q 50,50 80,20" fill="none" stroke="#10b981" strokeWidth="2" />
                    <path d="M 20,80 Q 50,50 80,80" fill="none" stroke="#06b6d4" strokeWidth="2" />
                    <line x1="30" y1="30" x2="30" y2="70" stroke="#facc15" strokeWidth="1.5" />
                    <line x1="50" y1="50" x2="50" y2="50" stroke="#facc15" strokeWidth="2" />
                    <line x1="70" y1="30" x2="70" y2="70" stroke="#facc15" strokeWidth="1.5" />
                  </svg>
                ) : (
                  <svg className="absolute inset-0 w-full h-full opacity-35" preserveAspectRatio="none" viewBox="0 0 100 100">
                    <circle cx="50" cy="50" r="30" fill="none" stroke="#a855f7" strokeWidth="2" />
                    <path d="M 40,35 L 65,50 L 40,65 Z" fill="#d8b4fe" />
                  </svg>
                )}

                <div className="relative z-10 flex items-center justify-between">
                  <span className="px-2 py-0.5 rounded-md bg-white/20 backdrop-blur text-white font-black text-[9px] uppercase tracking-wider">
                    {g.badge}
                  </span>
                  <span className="text-base">{g.icon}</span>
                </div>

                <div className="relative z-10">
                  <h4 className="text-xs sm:text-sm font-black text-white leading-tight group-hover:text-yellow-300 transition-colors">
                    {g.title}
                  </h4>
                </div>
              </div>

              <div className="pt-2 space-y-2 flex-1 flex flex-col justify-between">
                <p className="text-[11px] text-slate-300 line-clamp-2 leading-snug">
                  {g.subtitle}
                </p>
                <div className="flex items-center justify-between pt-1 border-t border-slate-800">
                  <span className="text-[10px] font-bold text-amber-300 bg-amber-400/10 px-2 py-0.5 rounded-full border border-amber-400/30">
                    {g.tag}
                  </span>
                  <button
                    type="button"
                    className="px-2.5 py-1 rounded-lg bg-pink-600 hover:bg-pink-500 text-white text-[11px] font-black flex items-center gap-1 transition-all group-hover:scale-105"
                  >
                    <span>Main</span>
                    <ArrowRight className="w-3 h-3" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* FOOTER: SELESAIKAN GAME -> BUKA MISI 5 DAN MISI 6 */}
      <div className="bg-white rounded-3xl p-4 sm:p-5 border border-slate-200 shadow-xs flex justify-end">
        <div className="flex items-center gap-2.5 w-full sm:w-auto justify-end">
          {isMissionFinished && onNextMission ? (
            <button
              id="btn-lanjut-misi-5"
              type="button"
              onClick={() => {
                joyfulGameMusic.stop();
                onNextMission(5);
              }}
              className="w-full sm:w-auto px-6 py-3 rounded-2xl font-bold text-xs sm:text-sm shadow-md flex items-center justify-center gap-2 cursor-pointer transition-all active:scale-95 bg-blue-600 hover:bg-blue-700 text-white"
            >
              <span>Lanjut ke Misi 5 & Misi 6</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          ) : (
            <button
              id="btn-selesai-game-m4"
              type="button"
              onClick={() => {
                if (isMissionFinished) {
                  joyfulGameMusic.stop();
                  if (onNextMission) {
                    onNextMission(5);
                  }
                } else {
                  handleFinishMissionGame();
                  if (onNextMission) {
                    joyfulGameMusic.stop();
                    onNextMission(5);
                  }
                }
              }}
              className={`w-full sm:w-auto px-6 py-3 rounded-2xl font-bold text-xs sm:text-sm shadow-md flex items-center justify-center gap-2 cursor-pointer transition-all active:scale-95 ${
                isMissionFinished
                  ? 'bg-emerald-600 hover:bg-emerald-700 text-white'
                  : hasPlayed
                  ? 'bg-gradient-to-r from-pink-600 via-rose-600 to-amber-600 hover:from-pink-700 hover:to-amber-700 text-white'
                  : 'bg-rose-600 hover:bg-rose-700 text-white'
              }`}
            >
              {isMissionFinished ? (
                <>
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Selesai Misi (Buka Misi 5 & Misi 6)</span>
                  <ArrowRight className="w-4 h-4" />
                </>
              ) : (
                <>
                  <span>Selesai Misi & Buka Misi 5 dan Misi 6</span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
