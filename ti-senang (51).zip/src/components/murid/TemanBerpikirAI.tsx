import React, { useState, useRef, useEffect } from 'react';
import {
  Bot,
  Send,
  Sparkles,
  X,
  HelpCircle,
  Lightbulb,
  Compass,
  ArrowRight,
  RotateCcw,
  Copy,
  Check,
  Calculator,
  ChevronDown,
  ChevronUp,
  Brain,
  BookOpen,
} from 'lucide-react';
import { MathMarkdownRenderer } from '../common/MathMarkdownRenderer';
import { generateOfflineTemanBerpikirResponse } from '../../services/ai/offlineFallback';

interface TemanBerpikirAIProps {
  currentContext?: string;
  isFloating?: boolean;
  onClose?: () => void;
}

interface ChatMessage {
  id: string;
  sender: 'ai' | 'user';
  text: string;
  timestamp: string;
  source?: 'gemini' | 'offline_engine' | 'system';
  model?: string;
}

export const TemanBerpikirAI: React.FC<TemanBerpikirAIProps> = ({
  currentContext = 'Pembelajaran Sains dan Matematika',
  isFloating = false,
  onClose,
}) => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'msg-1',
      sender: 'ai',
      text: `Halo! Saya **Teman Berpikir AI** TI SENANG. 🌿

Saya siap mendampingimu belajar sains dan matematika secara menyenangkan dan mendalam:
- **Tanya Definisi / Konsep / Fakta:** Saya berikan definisi akurat, penjelasan sederhana, contoh, konsep penting, dan sumber rujukan resmi (tanpa memaksa menebak).
- **Pemecahan Soal & Hitungan:** Saya dampingi langkah demi langkah menggunakan pendekatan bertahap agar kamu menemukan pemahamannya sendiri.
- **Rangkuman Materi Lengkap:** Cukup ketik *"Buatkan saya materi [topik]"*, saya susun materi terstruktur dari tujuan hingga kesimpulan.
- **Notasi & Rumus KaTeX:** Seluruh simbol dan rumus matematika ditampilkan dengan format LaTeX KaTeX yang rapi ($$f(x) = ax^2 + bx + c$$).

Ada konsep, definisi, atau soal yang ingin kita pelajari bersama?`,
      timestamp: new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' }),
      source: 'gemini',
    },
  ]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [showMathBar, setShowMathBar] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isTyping]);

  const quickPrompts = [
    { label: 'Rumus Suhu Fahrenheit', query: 'Apa rumus konversi suhu Celcius ke Fahrenheit dan sebaliknya?', icon: '🌡️' },
    { label: 'Apa itu Fungsi Kuadrat?', query: 'Apa itu fungsi kuadrat?', icon: '💡' },
    { label: 'Apa itu Bunga Majemuk?', query: 'Apa itu bunga majemuk?', icon: '📈' },
    { label: 'Apa itu Regresi Linear?', query: 'Apa yang dimaksud dengan regresi linear?', icon: '📊' },
    { label: '2x + 5 = 15', query: 'Bagaimana cara menyelesaikan 2x + 5 = 15?', icon: '📐' },
    { label: '1 + 1 = ?', query: '1 + 1 = ?', icon: '🍎' },
    { label: 'Pecahan 2/3 + 1/3', query: 'Hitung \\frac{2}{3} + \\frac{1}{3}', icon: '➗' },
    { label: 'Buat Materi Kuadrat', query: 'Buatkan saya materi fungsi kuadrat lengkap.', icon: '📚' },
    { label: 'Kurikulum Terbaru', query: 'Kurikulum terbaru apa yang resmi berlaku di Indonesia?', icon: '🏛️' },
    { label: 'Saya tidak tahu', query: 'Saya tidak tahu', icon: '🤔' },
  ];

  const mathShortcuts = [
    { label: '°F', insert: ' ^\\circ\\text{F}', title: 'Derajat Fahrenheit' },
    { label: '°C', insert: ' ^\\circ\\text{C}', title: 'Derajat Celcius' },
    { label: '°', insert: '^\\circ', title: 'Derajat' },
    { label: 'a/b', insert: '\\frac{a}{b}', title: 'Pecahan' },
    { label: 'x²', insert: 'x^2', title: 'Kuadrat' },
    { label: 'xⁿ', insert: 'x^n', title: 'Pangkat n' },
    { label: '√x', insert: '\\sqrt{x}', title: 'Akar kuadrat' },
    { label: '±', insert: '\\pm ', title: 'Plus-minus' },
    { label: '×', insert: '\\times ', title: 'Perkalian' },
    { label: '÷', insert: '\\div ', title: 'Pembagian' },
    { label: '≠', insert: '\\neq ', title: 'Tidak sama dengan' },
    { label: '≤', insert: '\\leq ', title: 'Kurang dari sama dengan' },
    { label: '≥', insert: '\\geq ', title: 'Lebih dari sama dengan' },
    { label: '≈', insert: '\\approx ', title: 'Mendekati / kira-kira' },
    { label: '∈', insert: '\\in ', title: 'Anggota himpunan' },
    { label: 'ℝ', insert: '\\mathbb{R}', title: 'Himpunan bilangan real' },
    { label: 'π', insert: '\\pi ', title: 'Pi' },
    { label: '∑', insert: '\\sum ', title: 'Sigma / Penjumlahan' },
    { label: '∫', insert: '\\int ', title: 'Integral' },
    { label: 'Δ', insert: '\\Delta ', title: 'Delta / Selisih' },
    { label: '∞', insert: '\\infty ', title: 'Tak hingga' },
    { label: '⟹', insert: '\\implies ', title: 'Implikasi / Maka' },
    { label: 'f(x)', insert: 'f(x) = ax^2 + bx + c', title: 'Template Fungsi Kuadrat' },
  ];

  const handleInsertMath = (snippet: string) => {
    setInput((prev) => prev + snippet);
    if (inputRef.current) {
      inputRef.current.focus();
    }
  };

  const handleCopy = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleResetChat = () => {
    setMessages([
      {
        id: `msg-${Date.now()}`,
        sender: 'ai',
        text: `Percakapan telah diatur ulang. 🌱\n\nSilakan tanyakan materi baru, soal matematika, atau konsep sains yang ingin kamu pelajari!`,
        timestamp: new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' }),
      },
    ]);
  };

  const handleSend = async (textToSend?: string) => {
    const text = (textToSend || input).trim();
    if (!text || isTyping) return;

    const userMsg: ChatMessage = {
      id: `msg-${Date.now()}`,
      sender: 'user',
      text,
      timestamp: new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' }),
    };

    const updatedMessages = [...messages, userMsg];
    setMessages(updatedMessages);
    if (!textToSend) setInput('');
    setIsTyping(true);

    try {
      // Call server API route /api/ai/chat
      const res = await fetch('/api/ai/chat', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          message: text,
          history: updatedMessages.map((m) => ({
            sender: m.sender,
            text: m.text,
          })),
          currentContext,
        }),
      });

      if (!res.ok) {
        throw new Error(`Server returned ${res.status}`);
      }

      const data = await res.json();
      const replyText = data.reply || generateOfflineTemanBerpikirResponse(text, updatedMessages);

      const aiMsg: ChatMessage = {
        id: `msg-ai-${Date.now()}`,
        sender: 'ai',
        text: replyText,
        timestamp: new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' }),
        source: data.source || 'gemini',
        model: data.model || 'gemini-3.8-flash',
      };

      setMessages((prev) => [...prev, aiMsg]);
    } catch (err) {
      console.warn('Network or API failure, switching to intelligent local fallback:', err);
      // Fallback seamlessly to Socratic offline logic
      const fallbackText = generateOfflineTemanBerpikirResponse(text, updatedMessages);
      const aiMsg: ChatMessage = {
        id: `msg-ai-${Date.now()}`,
        sender: 'ai',
        text: fallbackText,
        timestamp: new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' }),
        source: 'offline_engine',
        model: 'teman-berpikir-core',
      };
      setMessages((prev) => [...prev, aiMsg]);
    } finally {
      setIsTyping(false);
    }
  };

  return (
    <div
      className={`flex flex-col bg-slate-900 border border-slate-700/80 rounded-3xl shadow-2xl overflow-hidden ${
        isFloating ? 'w-[360px] sm:w-[440px] h-[560px]' : 'w-full h-full min-h-[500px]'
      }`}
    >
      {/* Header */}
      <div className="p-3.5 sm:p-4 bg-gradient-to-r from-blue-950 via-indigo-950 to-slate-900 border-b border-slate-800 flex items-center justify-between shrink-0">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-xl bg-gradient-to-tr from-blue-600 via-indigo-500 to-emerald-400 text-white flex items-center justify-center shadow-lg shadow-indigo-900/40">
            <Brain className="w-5 h-5 text-white" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-display font-black text-sm sm:text-base text-white">Teman Berpikir AI</span>
              <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 text-[10px] font-mono font-bold tracking-wider flex items-center gap-1">
                <Sparkles className="w-2.5 h-2.5" />
                ADAPTIF & SOKRATIK
              </span>
            </div>
            <p className="text-[11px] text-slate-400 truncate max-w-[220px] sm:max-w-[280px]">
              {currentContext}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-1">
          <button
            onClick={handleResetChat}
            title="Mulai percakapan baru"
            className="w-8 h-8 rounded-lg bg-slate-800/80 hover:bg-slate-700 text-slate-300 hover:text-white flex items-center justify-center transition-colors cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </button>

          {isFloating && onClose && (
            <button
              onClick={onClose}
              title="Tutup"
              className="w-8 h-8 rounded-lg bg-slate-800/80 hover:bg-slate-700 text-slate-300 hover:text-white flex items-center justify-center transition-colors cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      {/* Messages Scroll Area */}
      <div className="flex-1 p-3.5 sm:p-4 overflow-y-auto space-y-3.5 bg-slate-950/70 scrollbar-thin">
        {messages.map((m) => {
          const isUser = m.sender === 'user';
          return (
            <div key={m.id} className={`flex flex-col ${isUser ? 'items-end' : 'items-start'}`}>
              <div
                className={`max-w-[92%] sm:max-w-[85%] rounded-2xl p-3 sm:p-3.5 text-xs sm:text-sm leading-relaxed shadow-md transition-all ${
                  isUser
                    ? 'bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-br-none'
                    : 'bg-slate-900 border border-slate-800 text-slate-100 rounded-bl-none'
                }`}
              >
                {isUser ? (
                  <div className="text-white select-text">
                    <MathMarkdownRenderer content={m.text} />
                  </div>
                ) : (
                  <div className="relative group">
                    <MathMarkdownRenderer content={m.text} />
                    <button
                      onClick={() => handleCopy(m.id, m.text)}
                      title="Salin teks/rumus"
                      className="absolute -top-1 -right-1 opacity-0 group-hover:opacity-100 transition-opacity p-1 rounded-md bg-slate-800/90 text-slate-400 hover:text-white text-[10px] flex items-center gap-1 border border-slate-700 shadow"
                    >
                      {copiedId === m.id ? (
                        <>
                          <Check className="w-3 h-3 text-emerald-400" />
                          <span className="text-emerald-400">Tersalin</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3 h-3" />
                          <span>Salin</span>
                        </>
                      )}
                    </button>
                  </div>
                )}
              </div>

              <div className="flex items-center gap-2 mt-1 px-1 text-[10px] text-slate-500 font-mono">
                <span>{m.timestamp}</span>
                {!isUser && (
                  <span className="text-indigo-400/80">
                    {m.source === 'gemini'
                      ? (m.model ? m.model.replace(/-/g, ' ').replace(/\b\w/g, (l) => l.toUpperCase()) : 'Gemini AI')
                      : 'Sokratik AI Engine'}
                  </span>
                )}
              </div>
            </div>
          );
        })}

        {isTyping && (
          <div className="flex items-center gap-2.5 text-xs text-slate-300 bg-slate-900/90 border border-slate-800/80 rounded-2xl p-3 max-w-[280px]">
            <div className="flex items-center gap-1">
              <div className="w-2 h-2 rounded-full bg-blue-500 animate-bounce" />
              <div className="w-2 h-2 rounded-full bg-indigo-500 animate-bounce delay-100" />
              <div className="w-2 h-2 rounded-full bg-emerald-400 animate-bounce delay-200" />
            </div>
            <span className="text-slate-400 font-sans">Teman Berpikir sedang merumuskan...</span>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Quick Prompts Carousel */}
      <div className="px-3 py-2 bg-slate-900/95 border-t border-slate-800 overflow-x-auto scrollbar-none flex items-center gap-1.5 shrink-0">
        <span className="text-[10px] text-slate-500 font-medium whitespace-nowrap pl-1 pr-0.5">
          Coba tanyakan:
        </span>
        {quickPrompts.map((p, idx) => (
          <button
            key={idx}
            onClick={() => handleSend(p.query)}
            disabled={isTyping}
            className="px-2.5 py-1 rounded-lg bg-slate-800/90 hover:bg-slate-700 text-[11px] text-slate-300 hover:text-white border border-slate-700/80 whitespace-nowrap transition-colors cursor-pointer shrink-0 flex items-center gap-1.5 disabled:opacity-50"
          >
            <span>{p.icon}</span>
            <span>{p.label}</span>
          </button>
        ))}
      </div>

      {/* Math LaTeX Shortcuts Drawer */}
      {showMathBar && (
        <div className="px-3 py-2 bg-slate-950 border-t border-slate-800 flex flex-wrap gap-1.5 shrink-0 items-center">
          <span className="text-[10px] text-indigo-400 font-mono font-bold mr-1">Simbol & Rumus:</span>
          {mathShortcuts.map((s, idx) => (
            <button
              key={idx}
              type="button"
              onClick={() => handleInsertMath(s.insert)}
              title={s.title}
              className="px-2 py-0.5 rounded bg-slate-800 hover:bg-indigo-900/70 text-slate-200 hover:text-indigo-200 text-xs font-mono border border-slate-700 transition-colors cursor-pointer"
            >
              {s.label}
            </button>
          ))}
        </div>
      )}

      {/* Live Math Detection & Formula Preview */}
      {input.trim().length > 1 &&
        /(\\[a-zA-Z]+|\^|_|[²³⁴ⁿ½⅓¼√±×÷≠≤≥≈π∑∫Δ∞∈ℝ]|\b(akar|kuadrat|pangkat|integral|delta)\b)/i.test(input) && (
          <div className="px-3.5 py-1.5 bg-indigo-950/90 border-t border-indigo-800/60 flex items-center gap-2 text-xs text-indigo-200 shrink-0">
            <span className="text-[10px] font-mono uppercase bg-indigo-500/30 text-indigo-300 px-2 py-0.5 rounded font-bold shrink-0 flex items-center gap-1">
              <span>📐</span>
              <span>Rumus Terbaca AI</span>
            </span>
            <div className="overflow-x-auto scrollbar-none text-white py-0.5 max-w-[280px] sm:max-w-md">
              <MathMarkdownRenderer content={input} />
            </div>
          </div>
        )}

      {/* Input Form */}
      <form
        onSubmit={(e) => {
          e.preventDefault();
          handleSend();
        }}
        className="p-3 bg-slate-900 border-t border-slate-800 flex items-center gap-2 shrink-0"
      >
        <button
          type="button"
          onClick={() => setShowMathBar((prev) => !prev)}
          title="Tampilkan Simbol & Rumus Matematika"
          className={`w-9 h-9 rounded-xl flex items-center justify-center transition-colors cursor-pointer shrink-0 border ${
            showMathBar
              ? 'bg-indigo-600 border-indigo-500 text-white'
              : 'bg-slate-800 border-slate-700 text-slate-400 hover:text-slate-200 hover:bg-slate-700'
          }`}
        >
          <Calculator className="w-4 h-4" />
        </button>

        <input
          ref={inputRef}
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Tanyakan soal, konsep, atau 'Buatkan saya materi...'"
          className="flex-1 bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2.5 text-xs sm:text-sm text-white placeholder:text-slate-500 focus:outline-none focus:border-indigo-500 transition-colors"
        />

        <button
          type="submit"
          disabled={!input.trim() || isTyping}
          className="w-10 h-10 rounded-xl bg-indigo-600 hover:bg-indigo-500 disabled:opacity-40 disabled:cursor-not-allowed text-white flex items-center justify-center transition-colors shrink-0 cursor-pointer shadow-md shadow-indigo-900/40"
        >
          <Send className="w-4 h-4" />
        </button>
      </form>
    </div>
  );
};
