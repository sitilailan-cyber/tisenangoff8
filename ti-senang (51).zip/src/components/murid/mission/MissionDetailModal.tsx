import React from 'react';
import {
  X,
  Play,
  CheckCircle2,
  Lock,
  Sparkles,
  Star,
  Clock,
  Target,
  Award,
  BookOpen,
  ArrowRight,
  ShieldAlert,
  ShieldCheck,
  Zap,
} from 'lucide-react';
import { GameMissionItem } from './MissionTypes';

interface MissionDetailModalProps {
  mission: GameMissionItem | null;
  onClose: () => void;
  onStartMission: (mission: GameMissionItem) => void;
}

export const MissionDetailModal: React.FC<MissionDetailModalProps> = ({
  mission,
  onClose,
  onStartMission,
}) => {
  if (!mission) return null;

  const isCompleted = mission.status === 'completed';
  const isAvailable = mission.status === 'available';
  const isLocked = mission.status === 'locked';
  const isRecommended = mission.isRecommended;
  const isBoss = mission.isBoss;

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
      <div className="relative w-full max-w-2xl bg-slate-900 border border-slate-700 rounded-3xl p-6 sm:p-8 text-white shadow-2xl space-y-6 my-auto animate-in fade-in zoom-in-95">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 w-9 h-9 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-300 flex items-center justify-center transition-colors cursor-pointer"
          title="Tutup Modal"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="space-y-3">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="px-3 py-1 rounded-full bg-blue-500/20 text-blue-300 border border-blue-400/30 text-xs font-mono font-bold">
              {mission.missionCode} • {mission.subjectName}
            </span>

            {isRecommended && (
              <span className="px-3 py-1 rounded-full bg-amber-400/20 text-amber-300 border border-amber-400/40 text-xs font-mono font-bold flex items-center gap-1.5 animate-pulse">
                <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                RECOMMENDED FOR YOU
              </span>
            )}

            {isBoss && (
              <span className="px-3 py-1 rounded-full bg-amber-500/20 text-amber-300 border border-amber-400/40 text-xs font-mono font-bold">
                🏆 BOSS MISSION
              </span>
            )}

            {isCompleted && (
              <span className="px-3 py-1 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-400/40 text-xs font-mono font-bold flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5" />
                COMPLETED {mission.score ? `(${mission.score}/100)` : ''}
              </span>
            )}
          </div>

          <div className="text-xs font-mono font-bold uppercase tracking-wider text-slate-400">
            {mission.themeTitle}
          </div>

          <h2 className="text-xl sm:text-2xl lg:text-3xl font-display font-extrabold text-white tracking-tight">
            {mission.title}
          </h2>
        </div>

        {/* Overview Badges Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          <div className="bg-slate-800/80 p-3 rounded-2xl border border-slate-700">
            <div className="text-[10px] text-slate-400 uppercase font-mono font-bold">Tingkat Kesulitan</div>
            <div className="text-sm font-bold text-slate-200 mt-1">{mission.difficulty}</div>
          </div>
          <div className="bg-slate-800/80 p-3 rounded-2xl border border-slate-700">
            <div className="text-[10px] text-slate-400 uppercase font-mono font-bold">Estimasi Waktu</div>
            <div className="text-sm font-bold text-slate-200 mt-1 flex items-center gap-1">
              <Clock className="w-3.5 h-3.5 text-slate-400" />
              {mission.estimatedTime}
            </div>
          </div>
          <div className="bg-slate-800/80 p-3 rounded-2xl border border-slate-700">
            <div className="text-[10px] text-slate-400 uppercase font-mono font-bold">Hadiah Capaian</div>
            <div className="text-sm font-mono font-bold text-amber-300 mt-1 flex items-center gap-1">
              <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
              +{mission.xpReward} XP
            </div>
          </div>
          <div className="bg-slate-800/80 p-3 rounded-2xl border border-slate-700">
            <div className="text-[10px] text-slate-400 uppercase font-mono font-bold">Status Misi</div>
            <div
              className={`text-sm font-mono font-bold mt-1 uppercase ${
                isCompleted
                  ? 'text-emerald-400'
                  : isAvailable || isRecommended
                  ? 'text-blue-400'
                  : 'text-slate-500'
              }`}
            >
              {mission.status}
            </div>
          </div>
        </div>

        {/* Mission Description & Objectives */}
        <div className="space-y-3 p-4 sm:p-5 rounded-2xl bg-slate-800/50 border border-slate-700/80">
          <div className="text-xs font-mono font-bold uppercase tracking-wider text-slate-300 flex items-center gap-2">
            <Target className="w-4 h-4 text-blue-400" />
            Tujuan Pembelajaran & Ruang Lingkup:
          </div>
          <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
            {mission.description}
          </p>
        </div>

        {/* ALME Diagnostic Reason if recommended */}
        {isRecommended && mission.recommendationReason && (
          <div className="p-4 rounded-2xl bg-amber-400/10 border border-amber-400/30 text-xs text-amber-200 leading-relaxed">
            <div className="font-mono font-bold text-amber-300 uppercase tracking-wide flex items-center gap-2 mb-1">
              <Sparkles className="w-4 h-4" />
              Mengapa ALME Merekomendasikan Misi Ini:
            </div>
            <p className="text-slate-200">
              "{mission.recommendationReason}"
            </p>
            <p className="text-[11px] text-slate-400 mt-1 italic">
              * ALME mengarahkan fokus belajar adaptif tanpa membocorkan kunci jawaban tes.
            </p>
          </div>
        )}

        {/* Locked Prerequisite Banner if locked */}
        {isLocked && (
          <div className="p-4 rounded-2xl bg-rose-500/10 border border-rose-500/30 text-xs text-rose-200 flex items-start gap-3">
            <ShieldAlert className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
            <div>
              <div className="font-mono font-bold text-rose-300 uppercase">
                Akses Misi Belum Terbuka
              </div>
              <p className="text-slate-300 mt-1">
                Syarat Pembukaan: <span className="text-rose-200 font-bold">{mission.requiredMissionText}</span>.
              </p>
              <p className="text-[11px] text-slate-400 mt-1">
                Selesaikan tahapan eksplorasi sebelumnya untuk memicu pembukaan modul ini secara otomatis.
              </p>
            </div>
          </div>
        )}

        {/* Completed Mastered Banner */}
        {isCompleted && mission.isMastered && (
          <div className="p-4 rounded-2xl bg-cyan-500/10 border border-cyan-500/30 text-xs text-cyan-200 flex items-center gap-3">
            <Award className="w-6 h-6 text-amber-400 shrink-0" />
            <div>
              <div className="font-mono font-bold text-cyan-300 uppercase">
                Badge Pencapaian: MASTERED
              </div>
              <p className="text-slate-300 mt-0.5">
                Kamu menyelesaikan misi ini dengan skor istimewa {mission.score}/100.
              </p>
            </div>
          </div>
        )}

        {/* Modal Action Buttons */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-end gap-3 pt-3 border-t border-slate-800">
          <button
            onClick={onClose}
            className="min-h-[44px] px-5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs transition-colors cursor-pointer"
          >
            Tutup
          </button>

          <button
            onClick={() => {
              if (mission.isUnlocked) {
                onClose();
                onStartMission(mission);
              }
            }}
            disabled={!mission.isUnlocked}
            className={`min-h-[46px] px-7 py-2.5 rounded-xl font-display font-extrabold text-xs sm:text-sm tracking-wide transition-all flex items-center justify-center gap-2 cursor-pointer ${
              isCompleted
                ? 'bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700 text-white shadow-lg shadow-cyan-500/30 active:scale-95'
                : isRecommended
                ? 'bg-gradient-to-r from-amber-500 to-pink-500 hover:from-amber-600 hover:to-pink-600 text-slate-950 shadow-lg shadow-amber-500/30 active:scale-95'
                : isAvailable
                ? 'bg-blue-600 hover:bg-blue-700 text-white shadow-lg shadow-blue-600/30 active:scale-95'
                : 'bg-slate-800 text-slate-500 border border-slate-700 cursor-not-allowed'
            }`}
          >
            {isCompleted ? (
              <>
                <CheckCircle2 className="w-4 h-4" />
                <span>BUKA ULANG (REVIEW MODE)</span>
              </>
            ) : isAvailable || isRecommended ? (
              <>
                <Play className="w-4 h-4 fill-current" />
                <span>MULAI MISI SEKARANG</span>
              </>
            ) : (
              <>
                <Lock className="w-4 h-4" />
                <span>SYARAT BELUM TERPENUHI</span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
