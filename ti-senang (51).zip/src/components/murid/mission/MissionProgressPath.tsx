import React from 'react';
import { Check, Play, Lock, Sparkles, Trophy } from 'lucide-react';
import { GameMissionItem } from './MissionTypes';

interface MissionProgressPathProps {
  missions: GameMissionItem[];
  selectedIndex: number;
  onSelectMission: (index: number) => void;
}

export const MissionProgressPath: React.FC<MissionProgressPathProps> = ({
  missions,
  selectedIndex,
  onSelectMission,
}) => {
  return (
    <div className="w-full bg-slate-900/90 backdrop-blur-md rounded-3xl p-4 sm:p-5 border border-slate-800 shadow-lg">
      <div className="flex items-center justify-between gap-2 mb-3 px-1">
        <span className="text-xs font-mono font-bold uppercase tracking-wider text-slate-400">
          JALUR PERJALANAN (MISSION PROGRESS PATH)
        </span>
        <div className="flex items-center gap-3 text-[11px] font-mono text-slate-400">
          <span className="flex items-center gap-1 text-emerald-400">
            <span className="w-2 h-2 rounded-full bg-emerald-500" /> Selesai
          </span>
          <span className="flex items-center gap-1 text-blue-400">
            <span className="w-2 h-2 rounded-full bg-blue-500 animate-pulse" /> Aktif
          </span>
          <span className="flex items-center gap-1 text-slate-500">
            <span className="w-2 h-2 rounded-full bg-slate-600" /> Terkunci
          </span>
        </div>
      </div>

      {/* Horizontal Connected Node Track */}
      <div className="relative py-2 overflow-x-auto scrollbar-none">
        {/* Background Connecting Pipe */}
        <div className="absolute top-1/2 left-6 right-6 -translate-y-1/2 h-1.5 bg-slate-800 rounded-full z-0" />

        {/* Dynamic Connected Node Line (filling across missions) */}
        <div className="relative z-10 flex items-center justify-between min-w-[560px] px-2 sm:px-6">
          {missions.map((m, idx) => {
            const isSelected = selectedIndex === idx;
            let nodeBg = 'bg-slate-800 text-slate-400 border-slate-700';
            let iconElement = <span className="font-mono font-bold text-xs">{m.missionNumber}</span>;

            if (m.status === 'completed') {
              nodeBg = 'bg-emerald-600 text-white border-emerald-400 shadow-md shadow-emerald-600/30';
              iconElement = <Check className="w-4 h-4 stroke-[3]" />;
            } else if (m.isRecommended) {
              nodeBg = 'bg-gradient-to-tr from-amber-400 to-pink-500 text-slate-950 border-amber-300 shadow-lg shadow-pink-500/20 animate-pulse';
              iconElement = <Sparkles className="w-4 h-4 fill-slate-950" />;
            } else if (m.status === 'available') {
              nodeBg = 'bg-blue-600 text-white border-blue-400 shadow-lg shadow-blue-600/40 ring-4 ring-blue-500/20 animate-pulse';
              iconElement = <Play className="w-3.5 h-3.5 fill-white" />;
            } else if (m.isBoss) {
              nodeBg = 'bg-slate-800 text-amber-400 border-amber-500/40';
              iconElement = <Trophy className="w-3.5 h-3.5 text-amber-400" />;
            } else {
              nodeBg = 'bg-slate-800/90 text-slate-500 border-slate-700';
              iconElement = <Lock className="w-3 h-3 text-slate-500" />;
            }

            return (
              <button
                key={m.id}
                id={`btn-path-node-${m.missionNumber}`}
                onClick={() => onSelectMission(idx)}
                className={`flex flex-col items-center gap-1.5 group transition-transform ${
                  isSelected ? 'scale-110' : 'hover:scale-105'
                }`}
                title={`${m.missionCode}: ${m.themeTitle}`}
              >
                {/* Milestone Node */}
                <div
                  className={`w-9 h-9 sm:w-10 sm:h-10 rounded-2xl flex items-center justify-center border-2 transition-all cursor-pointer ${nodeBg} ${
                    isSelected ? 'ring-4 ring-white/30 scale-105' : ''
                  }`}
                >
                  {iconElement}
                </div>

                {/* Node Label */}
                <div className="text-center">
                  <span
                    className={`block text-[10px] font-mono font-bold ${
                      isSelected
                        ? 'text-white'
                        : m.status === 'completed'
                        ? 'text-emerald-400'
                        : m.status === 'available'
                        ? 'text-blue-400'
                        : 'text-slate-500'
                    }`}
                  >
                    M{m.missionNumber}
                  </span>
                </div>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};
