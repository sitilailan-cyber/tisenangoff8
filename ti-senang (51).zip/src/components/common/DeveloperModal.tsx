import React from 'react';
import { Modal } from './Modal';
import devSitiLailan from '../../assets/images/dev_siti_lailan.jpg';
import devNoverTiara from '../../assets/images/dev_nover_tiara.png';

interface DeveloperModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const NOVER_TIARA_PHOTO_URL =
  'https://raw.githubusercontent.com/sitilailan-cyber/ilan/b75e09496343efec2fa55f59865f0457036c1575/ChatGPT%20Image%2016%20Sep%202026%2C%2008.44.29.png';

const SITI_LAILAN_PHOTO_URL =
  'https://raw.githubusercontent.com/sitilailan-cyber/ILANFOT/4daa1e1adcd5eb2ac13e7bf5521bfb82819052ac/619259661_18108624238590423_8394037585421209083_n%20(1).jpg';

export const DeveloperModal: React.FC<DeveloperModalProps> = ({ isOpen, onClose }) => {
  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="Tim Pengembang"
      subtitle="Inovator Media Pembelajaran TI SENANG"
      maxWidth="2xl"
    >
      <div className="py-2">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 sm:gap-8">
          {/* Developer 1: Siti Lailan Koem, S.Pd - Matematika */}
          <div className="flex flex-col items-center text-center p-5 sm:p-6 rounded-2xl bg-gradient-to-b from-blue-50/80 to-indigo-50/60 border border-blue-200/90 shadow-xs transition-all hover:shadow-md">
            <div className="w-40 h-40 sm:w-44 sm:h-44 rounded-2xl overflow-hidden shadow-md border-2 border-blue-400/50 mb-3.5 bg-slate-100 flex items-center justify-center">
              <img
                src={devSitiLailan || SITI_LAILAN_PHOTO_URL}
                onError={(e) => {
                  (e.currentTarget as HTMLImageElement).src = SITI_LAILAN_PHOTO_URL;
                }}
                referrerPolicy="no-referrer"
                alt="Siti Lailan Koem, S.Pd"
                className="w-full h-full object-cover"
              />
            </div>
            <h4 className="text-sm sm:text-base md:text-lg font-bold text-slate-900 font-display whitespace-nowrap tracking-tight">
              Siti Lailan Koem, S.Pd
            </h4>
            <p className="text-xs sm:text-sm md:text-base text-blue-700 font-semibold mt-1">
              Matematika
            </p>
          </div>

          {/* Developer 2: Nover Tiara Jelita, S.Pd - Fisika */}
          <div className="flex flex-col items-center text-center p-5 sm:p-6 rounded-2xl bg-gradient-to-b from-cyan-50/80 to-blue-50/60 border border-cyan-200/90 shadow-xs transition-all hover:shadow-md">
            <div className="w-40 h-40 sm:w-44 sm:h-44 rounded-2xl overflow-hidden shadow-md border-2 border-cyan-400/50 mb-3.5 bg-slate-100 flex items-center justify-center">
              <img
                src={devNoverTiara || NOVER_TIARA_PHOTO_URL}
                onError={(e) => {
                  (e.currentTarget as HTMLImageElement).src = NOVER_TIARA_PHOTO_URL;
                }}
                referrerPolicy="no-referrer"
                alt="Nover Tiara Jelita, S.Pd"
                className="w-full h-full object-cover"
              />
            </div>
            <h4 className="text-sm sm:text-base md:text-lg font-bold text-slate-900 font-display whitespace-nowrap tracking-tight">
              Nover Tiara Jelita, S.Pd
            </h4>
            <p className="text-xs sm:text-sm md:text-base text-cyan-700 font-semibold mt-1">
              Fisika
            </p>
          </div>
        </div>
      </div>
    </Modal>
  );
};
