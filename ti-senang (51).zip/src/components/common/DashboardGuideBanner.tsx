import React from 'react';
import { X, ArrowRight } from 'lucide-react';

interface GuideStep {
  number: number;
  badgeBg: string;
  cardBg?: string;
  cardBorder?: string;
  title: string;
  description: string;
}

interface DashboardGuideBannerProps {
  role: 'murid' | 'guru';
  userName: string;
  onClose: () => void;
}

export const DashboardGuideBanner: React.FC<DashboardGuideBannerProps> = ({
  role,
  userName,
  onClose,
}) => {
  const isMurid = role === 'murid';

  const muridSteps: GuideStep[] = [
    {
      number: 1,
      badgeBg: 'bg-sky-600 text-white',
      cardBg: 'bg-sky-50/95',
      cardBorder: 'border-sky-200/80',
      title: 'Pilih Mapel & Semester',
      description: 'Pastikan Mapel MIPA & Semester aktif telah sesuai di menu atas.',
    },
    {
      number: 2,
      badgeBg: 'bg-indigo-600 text-white',
      cardBg: 'bg-indigo-50/95',
      cardBorder: 'border-indigo-200/80',
      title: 'Misi 1: Pahami Konsep',
      description: 'Pelajari modul/video, catat poin, & kuis AI untuk membuka Misi 2.',
    },
    {
      number: 3,
      badgeBg: 'bg-purple-600 text-white',
      cardBg: 'bg-purple-50/95',
      cardBorder: 'border-purple-200/80',
      title: 'Misi 2: Studi Masalah Nyata',
      description: 'Kaji studi kasus kontekstual & simpan karya ke portofolio Drive.',
    },
    {
      number: 4,
      badgeBg: 'bg-teal-600 text-white',
      cardBg: 'bg-teal-50/95',
      cardBorder: 'border-teal-200/80',
      title: 'Misi 3: Eksperimen / Simulasi',
      description: 'Uji sensor Kit IoT atau virtual lab, lalu klik "Selesai Eksperimen".',
    },
    {
      number: 5,
      badgeBg: 'bg-amber-600 text-white',
      cardBg: 'bg-amber-50/95',
      cardBorder: 'border-amber-200/80',
      title: 'Misi 4: Game Edukasi',
      description: 'Asah pemahaman konsep lewat tantangan mini game interaktif sains.',
    },
    {
      number: 6,
      badgeBg: 'bg-emerald-600 text-white',
      cardBg: 'bg-emerald-50/95',
      cardBorder: 'border-emerald-200/80',
      title: 'Misi 5 & 6: Refleksi & Asesmen',
      description: 'Isi penilaian diri lalu selesaikan asesmen sumatif akhir kompetensi.',
    },
  ];

  const guruSteps: GuideStep[] = [
    {
      number: 1,
      badgeBg: 'bg-sky-600 text-white',
      cardBg: 'bg-sky-50/95',
      cardBorder: 'border-sky-200/80',
      title: 'Pilih Mapel, Kelas & Semester',
      description: 'Pastikan Mapel MIPA, rombel Kelas, dan Semester aktif telah sesuai di menu atas.',
    },
    {
      number: 2,
      badgeBg: 'bg-indigo-600 text-white',
      cardBg: 'bg-indigo-50/95',
      cardBorder: 'border-indigo-200/80',
      title: 'Atur Capaian & TP',
      description: 'Susun Tujuan Pembelajaran (TP) Fase F atau gunakan preset kurikulum otomatis.',
    },
    {
      number: 3,
      badgeBg: 'bg-purple-600 text-white',
      cardBg: 'bg-purple-50/95',
      cardBorder: 'border-purple-200/80',
      title: 'Asesmen Awal & Kelompok',
      description: 'Input data asesmen diagnostik dan bagikan kelompok belajar adaptif (ALME).',
    },
    {
      number: 4,
      badgeBg: 'bg-teal-600 text-white',
      cardBg: 'bg-teal-50/95',
      cardBorder: 'border-teal-200/80',
      title: 'Kelola Misi & Lab Sains',
      description: 'Pantau Misi 1–6, bahan tayang modul/video, dan aktivitas eksperimen sensor IoT.',
    },
    {
      number: 5,
      badgeBg: 'bg-amber-600 text-white',
      cardBg: 'bg-amber-50/95',
      cardBorder: 'border-amber-200/80',
      title: 'Review Tugas & Portofolio',
      description: 'Periksa karya penyelidikan kontekstual siswa di Drive dan beri umpan balik.',
    },
    {
      number: 6,
      badgeBg: 'bg-emerald-600 text-white',
      cardBg: 'bg-emerald-50/95',
      cardBorder: 'border-emerald-200/80',
      title: 'Evaluasi & Asesmen Akhir',
      description: 'Pantau ketercapaian TP, rekap asesmen sumatif, dan ekspor laporan nilai.',
    },
  ];

  const steps = isMurid ? muridSteps : guruSteps;

  return (
    <div className="relative overflow-hidden rounded-xl sm:rounded-2xl bg-gradient-to-r from-blue-600 via-blue-600 to-indigo-600 p-2.5 sm:p-4 lg:p-6 text-white shadow-2xl border border-blue-400/40 animate-beranda-enter w-full box-border">
      {/* Top Header Row with Title and Close Button */}
      <div className="flex items-start justify-between gap-2 sm:gap-4">
        <div className="min-w-0 flex-1">
          <h2 className="text-xs sm:text-base lg:text-xl font-bold tracking-tight text-white drop-shadow-xs truncate sm:whitespace-normal">
            {isMurid ? 'Petunjuk Langkah Belajar Murid' : 'Petunjuk Langkah Mengajar Guru'}
          </h2>
          <p className="text-[10px] sm:text-xs lg:text-sm text-blue-100 mt-0.5 sm:mt-1 font-normal truncate sm:whitespace-normal">
            Selamat datang, <span className="font-semibold">{userName}</span>! Berikut panduan ringkas alur kerja Anda:
          </p>
        </div>

        <button
          type="button"
          onClick={onClose}
          aria-label="Tutup petunjuk"
          className="text-white/80 hover:text-white p-1 sm:p-1.5 rounded-lg hover:bg-white/20 transition-colors cursor-pointer shrink-0"
        >
          <X className="w-4 h-4 sm:w-5 sm:h-5" />
        </button>
      </div>

      {/* 6 Step Cards: Bersusun ke bawah di handphone & tab (grid-cols-1), 3 kolom di laptop (lg:grid-cols-3) */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-1 sm:gap-1.5 lg:gap-3 mt-2 sm:mt-2.5 lg:mt-4">
        {steps.map((step) => (
          <div
            key={step.number}
            className={`rounded-lg sm:rounded-xl p-1.5 sm:p-2 lg:p-3 shadow-xs border flex items-center lg:items-start gap-2 sm:gap-2.5 transition-transform hover:-translate-y-0.5 min-w-0 ${
              step.cardBg ? step.cardBg : 'bg-white'
            } ${step.cardBorder ? step.cardBorder : 'border-blue-100'}`}
          >
            <div
              className={`w-5 h-5 sm:w-6 sm:h-6 lg:w-7 lg:h-7 rounded-md sm:rounded-lg flex items-center justify-center font-bold text-[10px] sm:text-xs shrink-0 shadow-2xs ${step.badgeBg}`}
            >
              {step.number}
            </div>
            <div className="min-w-0 flex-1 overflow-hidden">
              <div className="flex flex-col sm:flex-row sm:items-baseline sm:gap-1.5 lg:flex-col lg:gap-0">
                <h3 className="text-[10px] sm:text-xs lg:text-sm font-bold text-slate-900 leading-tight truncate">
                  {step.title}
                </h3>
                <p className="text-[9px] sm:text-[11px] lg:text-xs text-slate-600 leading-tight line-clamp-1 sm:line-clamp-2">
                  {step.description}
                </p>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Action Button */}
      <div className="flex justify-end mt-2 sm:mt-2.5 lg:mt-4">
        <button
          type="button"
          onClick={onClose}
          className="w-full sm:w-auto px-4 sm:px-6 py-1.5 sm:py-2.5 rounded-lg sm:rounded-xl font-bold text-white bg-pink-600 hover:bg-pink-700 active:scale-95 transition-all shadow-md hover:shadow-lg flex items-center justify-center gap-1.5 sm:gap-2 text-[11px] sm:text-xs lg:text-sm cursor-pointer"
        >
          <span>{isMurid ? 'Saya mengerti, mulai belajar' : 'Saya mengerti, mulai'}</span>
          <ArrowRight className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
        </button>
      </div>
    </div>
  );
};
