import React, { createContext, useContext, useState, useEffect } from 'react';
import { User, UserRole } from '../types';
import { storage } from '../services/storage';
import { clearGreetingSession } from '../services/audioGreeting';

interface AuthContextType {
  currentUser: User | null;
  currentRole: UserRole | null;
  login: (username: string, password: string, role?: UserRole) => { success: boolean; error?: string };
  logout: () => void;
  updateCurrentUser: (userData: Partial<User>) => void;
  isAuthenticated: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const CURRENT_USER_STORAGE_KEY = 'ti_senang_auth_user';

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<User | null>(() => {
    if (typeof window === 'undefined') return null;
    try {
      const saved = localStorage.getItem(CURRENT_USER_STORAGE_KEY);
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  });

  const currentRole = currentUser?.role || null;

  const login = (
    username: string,
    password: string,
    role?: UserRole,
  ): { success: boolean; error?: string } => {
    const res = storage.authenticate(username, password, role);
    if (res.success && res.user) {
      setCurrentUser(res.user);
      try {
        localStorage.setItem(CURRENT_USER_STORAGE_KEY, JSON.stringify(res.user));
      } catch (e) {
        console.error('Error saving user session:', e);
      }
      return { success: true };
    }
    return { success: false, error: res.error || 'Login gagal. Periksa username dan password Anda.' };
  };

  const logout = () => {
    setCurrentUser(null);
    clearGreetingSession();
    try {
      localStorage.removeItem(CURRENT_USER_STORAGE_KEY);
    } catch (e) {
      console.error('Error clearing session:', e);
    }
  };

  const updateCurrentUser = (userData: Partial<User>) => {
    if (!currentUser) return;
    const updated = storage.updateUser(currentUser.id, userData);
    if (updated) {
      setCurrentUser(updated);
      try {
        localStorage.setItem(CURRENT_USER_STORAGE_KEY, JSON.stringify(updated));
      } catch (e) {
        console.error('Error updating user session:', e);
      }
    }
  };

  return (
    <AuthContext.Provider
      value={{
        currentUser,
        currentRole,
        login,
        logout,
        updateCurrentUser,
        isAuthenticated: !!currentUser,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
